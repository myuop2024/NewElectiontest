// src/Routes.jsx
import React from "react";
import { BrowserRouter, Routes as RouterRoutes, Route } from "react-router-dom";
import ScrollToTop from "components/ScrollToTop";
import ErrorBoundary from "components/ErrorBoundary";

// Page imports
import LoginRegistration from "pages/login-registration";
import ObserverDashboard from "pages/observer-dashboard";
import PollingStationCheckIn from "pages/polling-station-check-in";
import PollingStationCheckInErrorResolution from "pages/polling-station-check-in-error-resolution";
import DocumentUploadOcrProcessing from "pages/document-upload-ocr-processing";
import LiveCommunicationHub from "pages/live-communication-hub";
import AdminControlCenter from "pages/admin-control-center";
import NotFound from "pages/NotFound";

const Routes = () => {
  return (
    <BrowserRouter>
      <ErrorBoundary>
        <ScrollToTop />
        <RouterRoutes>
          <Route path="/login-registration" element={<LoginRegistration />} />
          <Route path="/observer-dashboard" element={<ObserverDashboard />} />
          <Route path="/polling-station-check-in" element={<PollingStationCheckIn />} />
          <Route path="/polling-station-check-in-error-resolution" element={<PollingStationCheckInErrorResolution />} />
          <Route path="/document-upload-ocr-processing" element={<DocumentUploadOcrProcessing />} />
          <Route path="/live-communication-hub" element={<LiveCommunicationHub />} />
          <Route path="/admin-control-center" element={<AdminControlCenter />} />
          <Route path="/" element={<LoginRegistration />} />
          <Route path="*" element={<NotFound />} />
        </RouterRoutes>
      </ErrorBoundary>
    </BrowserRouter>
  );
};

export default Routes;