import React, { useState } from 'react';
import Icon from '../AppIcon';

const Header = () => {
  const [isProfileOpen, setIsProfileOpen] = useState(false);
  const [connectionStatus, setConnectionStatus] = useState('connected'); // connected, disconnected, syncing

  const getConnectionStatusColor = () => {
    switch (connectionStatus) {
      case 'connected':
        return 'text-success';
      case 'syncing':
        return 'text-warning';
      case 'disconnected':
        return 'text-error';
      default:
        return 'text-text-secondary';
    }
  };

  const getConnectionStatusText = () => {
    switch (connectionStatus) {
      case 'connected':
        return 'Online';
      case 'syncing':
        return 'Syncing';
      case 'disconnected':
        return 'Offline';
      default:
        return 'Unknown';
    }
  };

  const handleEmergencyContact = () => {
    // Emergency contact functionality
    console.log('Emergency contact activated');
  };

  const handleProfileToggle = () => {
    setIsProfileOpen(!isProfileOpen);
  };

  const handleLogout = () => {
    // Logout functionality
    console.log('User logged out');
  };

  return (
    <header className="fixed top-0 left-0 right-0 z-100 bg-surface border-b border-border shadow-elevation-2">
      <div className="flex items-center justify-between px-4 py-3 lg:px-6">
        {/* Logo and Brand */}
        <div className="flex items-center space-x-3">
          <div className="flex items-center space-x-2">
            <div className="w-8 h-8 bg-primary rounded-md flex items-center justify-center">
              <svg
                viewBox="0 0 24 24"
                className="w-5 h-5 text-white"
                fill="currentColor"
              >
                <path d="M12 2L2 7v10c0 5.55 3.84 9.74 9 11 5.16-1.26 9-5.45 9-11V7l-10-5z" />
                <path d="M9 12l2 2 4-4" stroke="white" strokeWidth="2" fill="none" />
              </svg>
            </div>
            <div>
              <h1 className="text-lg font-semibold text-text-primary">CAFFE</h1>
              <p className="text-xs text-text-secondary font-mono">Electoral Observer Platform</p>
            </div>
          </div>
        </div>

        {/* Center Status Indicators */}
        <div className="hidden md:flex items-center space-x-6">
          {/* Connection Status */}
          <div className="flex items-center space-x-2">
            <div className={`w-2 h-2 rounded-full ${connectionStatus === 'connected' ? 'bg-success' : connectionStatus === 'syncing' ? 'bg-warning animate-pulse' : 'bg-error'}`} />
            <span className={`text-sm font-medium ${getConnectionStatusColor()}`}>
              {getConnectionStatusText()}
            </span>
          </div>

          {/* Data Sync Status */}
          <div className="flex items-center space-x-2 text-text-secondary">
            <Icon name="RefreshCw" size={16} className={connectionStatus === 'syncing' ? 'animate-spin' : ''} />
            <span className="text-sm">Last sync: 2 min ago</span>
          </div>
        </div>

        {/* Right Actions */}
        <div className="flex items-center space-x-3">
          {/* Emergency Contact Button */}
          <button
            onClick={handleEmergencyContact}
            className="flex items-center space-x-2 px-3 py-2 bg-accent text-white rounded-md hover:bg-accent-700 transition-colors duration-150 ease-out min-h-touch"
            title="Emergency Contact"
          >
            <Icon name="Phone" size={16} />
            <span className="hidden sm:inline text-sm font-medium">Emergency</span>
          </button>

          {/* Mobile Connection Status */}
          <div className="md:hidden flex items-center">
            <div className={`w-3 h-3 rounded-full ${connectionStatus === 'connected' ? 'bg-success' : connectionStatus === 'syncing' ? 'bg-warning animate-pulse' : 'bg-error'}`} />
          </div>

          {/* Profile Dropdown */}
          <div className="relative">
            <button
              onClick={handleProfileToggle}
              className="flex items-center space-x-2 p-2 rounded-md hover:bg-surface-secondary transition-colors duration-150 ease-out min-h-touch min-w-touch"
              title="User Profile"
            >
              <div className="w-8 h-8 bg-primary-100 rounded-full flex items-center justify-center">
                <Icon name="User" size={16} className="text-primary-600" />
              </div>
              <div className="hidden lg:block text-left">
                <p className="text-sm font-medium text-text-primary">Observer ID: OBS-2024-001</p>
                <p className="text-xs text-text-secondary">Indoor Agent</p>
              </div>
              <Icon name="ChevronDown" size={16} className="text-text-secondary" />
            </button>

            {/* Profile Dropdown Menu */}
            {isProfileOpen && (
              <div className="absolute right-0 mt-2 w-64 bg-surface border border-border rounded-lg shadow-elevation-3 z-200">
                <div className="p-4 border-b border-border">
                  <p className="font-medium text-text-primary">Observer Profile</p>
                  <p className="text-sm text-text-secondary font-mono">ID: OBS-2024-001</p>
                  <p className="text-sm text-text-secondary">Role: Indoor Agent</p>
                  <p className="text-sm text-text-secondary">Station: PS-001-A</p>
                </div>
                <div className="p-2">
                  <button className="w-full flex items-center space-x-2 px-3 py-2 text-left hover:bg-surface-secondary rounded-md transition-colors duration-150 ease-out">
                    <Icon name="Settings" size={16} />
                    <span className="text-sm">Settings</span>
                  </button>
                  <button className="w-full flex items-center space-x-2 px-3 py-2 text-left hover:bg-surface-secondary rounded-md transition-colors duration-150 ease-out">
                    <Icon name="HelpCircle" size={16} />
                    <span className="text-sm">Help & Support</span>
                  </button>
                  <button className="w-full flex items-center space-x-2 px-3 py-2 text-left hover:bg-surface-secondary rounded-md transition-colors duration-150 ease-out">
                    <Icon name="Shield" size={16} />
                    <span className="text-sm">Security</span>
                  </button>
                  <hr className="my-2 border-border" />
                  <button
                    onClick={handleLogout}
                    className="w-full flex items-center space-x-2 px-3 py-2 text-left text-error hover:bg-error-50 rounded-md transition-colors duration-150 ease-out"
                  >
                    <Icon name="LogOut" size={16} />
                    <span className="text-sm">Sign Out</span>
                  </button>
                </div>
              </div>
            )}
          </div>
        </div>
      </div>
    </header>
  );
};

export default Header;