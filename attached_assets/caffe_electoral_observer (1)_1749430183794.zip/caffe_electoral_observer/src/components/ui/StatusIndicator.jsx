import React, { useState, useEffect } from 'react';
import Icon from '../AppIcon';

const StatusIndicator = () => {
  const [connectionStatus, setConnectionStatus] = useState('connected');
  const [syncStatus, setSyncStatus] = useState('synced');
  const [lastSyncTime, setLastSyncTime] = useState(new Date());
  const [batteryLevel, setBatteryLevel] = useState(85);
  const [isLowBattery, setIsLowBattery] = useState(false);

  useEffect(() => {
    // Simulate real-time status updates
    const statusInterval = setInterval(() => {
      // Simulate connection status changes
      const statuses = ['connected', 'syncing', 'disconnected'];
      const randomStatus = statuses[Math.floor(Math.random() * statuses.length)];
      setConnectionStatus(randomStatus);

      // Update sync status based on connection
      if (randomStatus === 'connected') {
        setSyncStatus('synced');
        setLastSyncTime(new Date());
      } else if (randomStatus === 'syncing') {
        setSyncStatus('syncing');
      } else {
        setSyncStatus('pending');
      }

      // Simulate battery level changes
      setBatteryLevel(prev => {
        const newLevel = Math.max(0, prev - Math.random() * 2);
        setIsLowBattery(newLevel < 20);
        return newLevel;
      });
    }, 10000); // Update every 10 seconds

    return () => clearInterval(statusInterval);
  }, []);

  const getConnectionIcon = () => {
    switch (connectionStatus) {
      case 'connected':
        return 'Wifi';
      case 'syncing':
        return 'RefreshCw';
      case 'disconnected':
        return 'WifiOff';
      default:
        return 'Wifi';
    }
  };

  const getConnectionColor = () => {
    switch (connectionStatus) {
      case 'connected':
        return 'text-success';
      case 'syncing':
        return 'text-warning';
      case 'disconnected':
        return 'text-error';
      default:
        return 'text-text-secondary';
    }
  };

  const getSyncIcon = () => {
    switch (syncStatus) {
      case 'synced':
        return 'Check';
      case 'syncing':
        return 'RefreshCw';
      case 'pending':
        return 'Clock';
      default:
        return 'Check';
    }
  };

  const getSyncColor = () => {
    switch (syncStatus) {
      case 'synced':
        return 'text-success';
      case 'syncing':
        return 'text-warning';
      case 'pending':
        return 'text-error';
      default:
        return 'text-text-secondary';
    }
  };

  const formatLastSync = () => {
    const now = new Date();
    const diffMs = now - lastSyncTime;
    const diffMins = Math.floor(diffMs / 60000);
    
    if (diffMins < 1) return 'Just now';
    if (diffMins < 60) return `${diffMins}m ago`;
    const diffHours = Math.floor(diffMins / 60);
    return `${diffHours}h ago`;
  };

  const getBatteryIcon = () => {
    if (batteryLevel > 75) return 'Battery';
    if (batteryLevel > 50) return 'Battery';
    if (batteryLevel > 25) return 'Battery';
    return 'BatteryLow';
  };

  const getBatteryColor = () => {
    if (isLowBattery) return 'text-error';
    if (batteryLevel < 50) return 'text-warning';
    return 'text-success';
  };

  return (
    <div className="fixed top-20 right-4 z-200 bg-surface border border-border rounded-lg shadow-elevation-3 p-3 min-w-[200px]">
      {/* Header */}
      <div className="flex items-center space-x-2 mb-3">
        <Icon name="Activity" size={16} className="text-primary" />
        <span className="text-sm font-medium text-text-primary">System Status</span>
      </div>

      {/* Status Items */}
      <div className="space-y-3">
        {/* Connection Status */}
        <div className="flex items-center justify-between">
          <div className="flex items-center space-x-2">
            <Icon
              name={getConnectionIcon()}
              size={16}
              className={`${getConnectionColor()} ${connectionStatus === 'syncing' ? 'animate-spin' : ''}`}
            />
            <span className="text-sm text-text-primary">Connection</span>
          </div>
          <span className={`text-xs font-medium ${getConnectionColor()}`}>
            {connectionStatus.charAt(0).toUpperCase() + connectionStatus.slice(1)}
          </span>
        </div>

        {/* Sync Status */}
        <div className="flex items-center justify-between">
          <div className="flex items-center space-x-2">
            <Icon
              name={getSyncIcon()}
              size={16}
              className={`${getSyncColor()} ${syncStatus === 'syncing' ? 'animate-spin' : ''}`}
            />
            <span className="text-sm text-text-primary">Data Sync</span>
          </div>
          <span className={`text-xs font-medium ${getSyncColor()}`}>
            {syncStatus.charAt(0).toUpperCase() + syncStatus.slice(1)}
          </span>
        </div>

        {/* Last Sync Time */}
        <div className="flex items-center justify-between">
          <div className="flex items-center space-x-2">
            <Icon name="Clock" size={16} className="text-text-secondary" />
            <span className="text-sm text-text-primary">Last Sync</span>
          </div>
          <span className="text-xs text-text-secondary font-mono">
            {formatLastSync()}
          </span>
        </div>

        {/* Battery Status */}
        <div className="flex items-center justify-between">
          <div className="flex items-center space-x-2">
            <Icon
              name={getBatteryIcon()}
              size={16}
              className={getBatteryColor()}
            />
            <span className="text-sm text-text-primary">Battery</span>
          </div>
          <span className={`text-xs font-medium ${getBatteryColor()}`}>
            {Math.round(batteryLevel)}%
          </span>
        </div>

        {/* GPS Status */}
        <div className="flex items-center justify-between">
          <div className="flex items-center space-x-2">
            <Icon name="MapPin" size={16} className="text-success" />
            <span className="text-sm text-text-primary">GPS</span>
          </div>
          <span className="text-xs font-medium text-success">Active</span>
        </div>
      </div>

      {/* Emergency Mode Toggle */}
      <div className="mt-4 pt-3 border-t border-border">
        <button className="w-full flex items-center justify-between p-2 hover:bg-surface-secondary rounded-md transition-colors duration-150 ease-out">
          <div className="flex items-center space-x-2">
            <Icon name="Shield" size={16} className="text-accent" />
            <span className="text-sm text-text-primary">Emergency Mode</span>
          </div>
          <div className="w-8 h-4 bg-border rounded-full">
            <div className="w-3 h-3 bg-white rounded-full mt-0.5 ml-0.5 transition-transform duration-200" />
          </div>
        </button>
      </div>

      {/* Low Battery Warning */}
      {isLowBattery && (
        <div className="mt-3 p-2 bg-error-50 border border-error-200 rounded-md">
          <div className="flex items-center space-x-2">
            <Icon name="AlertTriangle" size={14} className="text-error" />
            <span className="text-xs text-error font-medium">Low Battery Warning</span>
          </div>
          <p className="text-xs text-error mt-1">
            Please charge your device to ensure continuous operation.
          </p>
        </div>
      )}
    </div>
  );
};

export default StatusIndicator;