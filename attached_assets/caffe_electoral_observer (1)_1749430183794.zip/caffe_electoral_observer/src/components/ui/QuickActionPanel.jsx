import React, { useState } from 'react';
import Icon from '../AppIcon';

const QuickActionPanel = () => {
  const [isExpanded, setIsExpanded] = useState(false);
  const [isOfflineMode, setIsOfflineMode] = useState(false);

  const quickActions = [
    {
      id: 'check-in',
      label: 'Quick Check-in',
      icon: 'MapPin',
      color: 'bg-primary',
      hoverColor: 'hover:bg-primary-700',
      action: () => console.log('Quick check-in initiated')
    },
    {
      id: 'document-capture',
      label: 'Document Capture',
      icon: 'Camera',
      color: 'bg-secondary',
      hoverColor: 'hover:bg-secondary-700',
      action: () => console.log('Document capture initiated')
    },
    {
      id: 'emergency-contact',
      label: 'Emergency Contact',
      icon: 'Phone',
      color: 'bg-accent',
      hoverColor: 'hover:bg-accent-700',
      action: () => console.log('Emergency contact initiated')
    },
    {
      id: 'voice-note',
      label: 'Voice Note',
      icon: 'Mic',
      color: 'bg-warning',
      hoverColor: 'hover:bg-warning-600',
      action: () => console.log('Voice note recording started')
    }
  ];

  const togglePanel = () => {
    setIsExpanded(!isExpanded);
  };

  const handleOfflineToggle = () => {
    setIsOfflineMode(!isOfflineMode);
  };

  return (
    <>
      {/* Desktop Floating Panel */}
      <div className="hidden lg:block fixed bottom-6 right-6 z-200">
        <div className={`bg-surface border border-border rounded-lg shadow-elevation-4 transition-all duration-200 ease-in-out ${isExpanded ? 'w-64' : 'w-auto'}`}>
          {/* Panel Header */}
          <div className="flex items-center justify-between p-4 border-b border-border">
            <div className="flex items-center space-x-2">
              <Icon name="Zap" size={16} className="text-primary" />
              {isExpanded && (
                <span className="text-sm font-medium text-text-primary">Quick Actions</span>
              )}
            </div>
            <button
              onClick={togglePanel}
              className="p-1 hover:bg-surface-secondary rounded transition-colors duration-150 ease-out"
              title={isExpanded ? 'Collapse Panel' : 'Expand Panel'}
            >
              <Icon name={isExpanded ? 'ChevronDown' : 'ChevronUp'} size={16} />
            </button>
          </div>

          {/* Quick Actions */}
          {isExpanded && (
            <div className="p-4 space-y-3">
              {quickActions.map((action) => (
                <button
                  key={action.id}
                  onClick={action.action}
                  className={`w-full flex items-center space-x-3 px-3 py-2 text-white rounded-md transition-colors duration-150 ease-out min-h-touch ${action.color} ${action.hoverColor}`}
                  title={action.label}
                >
                  <Icon name={action.icon} size={16} />
                  <span className="text-sm font-medium">{action.label}</span>
                </button>
              ))}
            </div>
          )}

          {/* Offline Mode Toggle */}
          {isExpanded && (
            <div className="p-4 border-t border-border">
              <button
                onClick={handleOfflineToggle}
                className="w-full flex items-center justify-between p-2 hover:bg-surface-secondary rounded-md transition-colors duration-150 ease-out"
              >
                <div className="flex items-center space-x-2">
                  <Icon name="Wifi" size={16} className={isOfflineMode ? 'text-error' : 'text-success'} />
                  <span className="text-sm text-text-primary">
                    {isOfflineMode ? 'Offline Mode' : 'Online Mode'}
                  </span>
                </div>
                <div className={`w-10 h-6 rounded-full transition-colors duration-200 ${isOfflineMode ? 'bg-error' : 'bg-success'}`}>
                  <div className={`w-4 h-4 bg-white rounded-full mt-1 transition-transform duration-200 ${isOfflineMode ? 'translate-x-1' : 'translate-x-5'}`} />
                </div>
              </button>
            </div>
          )}
        </div>
      </div>

      {/* Mobile Bottom Action Bar */}
      <div className="lg:hidden fixed bottom-0 left-0 right-0 bg-surface border-t border-border z-200">
        <div className="flex items-center justify-around p-2">
          {quickActions.slice(0, 4).map((action) => (
            <button
              key={action.id}
              onClick={action.action}
              className={`flex flex-col items-center space-y-1 p-3 rounded-lg transition-colors duration-150 ease-out min-h-touch min-w-touch ${action.color} ${action.hoverColor} text-white`}
              title={action.label}
            >
              <Icon name={action.icon} size={20} />
              <span className="text-xs font-medium">{action.label.split(' ')[0]}</span>
            </button>
          ))}
        </div>

        {/* Mobile Offline Indicator */}
        <div className="flex items-center justify-center py-2 border-t border-border">
          <div className="flex items-center space-x-2">
            <div className={`w-2 h-2 rounded-full ${isOfflineMode ? 'bg-error' : 'bg-success'}`} />
            <span className="text-xs text-text-secondary">
              {isOfflineMode ? 'Offline Mode Active' : 'Connected'}
            </span>
            <button
              onClick={handleOfflineToggle}
              className="text-xs text-primary hover:text-primary-700 transition-colors duration-150 ease-out"
            >
              Toggle
            </button>
          </div>
        </div>
      </div>
    </>
  );
};

export default QuickActionPanel;