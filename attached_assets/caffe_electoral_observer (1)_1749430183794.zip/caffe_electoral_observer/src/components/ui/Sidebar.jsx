import React, { useState } from 'react';
import { useLocation, useNavigate } from 'react-router-dom';
import Icon from '../AppIcon';

const Sidebar = () => {
  const [isCollapsed, setIsCollapsed] = useState(false);
  const [isMobileOpen, setIsMobileOpen] = useState(false);
  const location = useLocation();
  const navigate = useNavigate();

  const navigationItems = [
    {
      label: 'Dashboard',
      path: '/observer-dashboard',
      icon: 'LayoutDashboard',
      tooltip: 'Observer Dashboard - Central command center'
    },
    {
      label: 'Station Check-in',
      path: '/polling-station-check-in',
      icon: 'MapPin',
      tooltip: 'Polling Station Check-in - Location verification'
    },
    {
      label: 'Document Upload',
      path: '/document-upload-ocr-processing',
      icon: 'Upload',
      tooltip: 'Document Upload & OCR - Process electoral documents'
    },
    {
      label: 'Communication Hub',
      path: '/live-communication-hub',
      icon: 'MessageSquare',
      tooltip: 'Live Communication - Real-time messaging and coordination'
    },
    {
      label: 'Training Portal',
      path: '/training-certification-portal',
      icon: 'GraduationCap',
      tooltip: 'Training & Certification - Learning modules and assessments'
    },
    {
      label: 'Route Management',
      path: '/roving-observer-route-management',
      icon: 'Route',
      tooltip: 'Roving Observer Routes - Multi-location management'
    },
    {
      label: 'Admin Center',
      path: '/admin-control-center',
      icon: 'Settings',
      tooltip: 'Admin Control Center - System oversight and analytics'
    }
  ];

  const handleNavigation = (path) => {
    navigate(path);
    setIsMobileOpen(false);
  };

  const toggleCollapse = () => {
    setIsCollapsed(!isCollapsed);
  };

  const toggleMobileMenu = () => {
    setIsMobileOpen(!isMobileOpen);
  };

  const isActiveRoute = (path) => {
    return location.pathname === path;
  };

  return (
    <>
      {/* Mobile Menu Button */}
      <button
        onClick={toggleMobileMenu}
        className="lg:hidden fixed top-20 left-4 z-200 p-2 bg-surface border border-border rounded-md shadow-elevation-2 min-h-touch min-w-touch"
        title="Toggle Navigation Menu"
      >
        <Icon name="Menu" size={20} />
      </button>

      {/* Mobile Overlay */}
      {isMobileOpen && (
        <div
          className="lg:hidden fixed inset-0 bg-black bg-opacity-50 z-100"
          onClick={() => setIsMobileOpen(false)}
        />
      )}

      {/* Sidebar */}
      <aside
        className={`
          fixed top-16 left-0 h-[calc(100vh-4rem)] bg-surface border-r border-border z-100 transition-all duration-200 ease-in-out
          ${isCollapsed ? 'w-16' : 'w-64'}
          ${isMobileOpen ? 'translate-x-0' : '-translate-x-full lg:translate-x-0'}
        `}
      >
        <div className="flex flex-col h-full">
          {/* Sidebar Header */}
          <div className="flex items-center justify-between p-4 border-b border-border">
            {!isCollapsed && (
              <h2 className="text-lg font-semibold text-text-primary">Navigation</h2>
            )}
            <button
              onClick={toggleCollapse}
              className="hidden lg:flex p-2 hover:bg-surface-secondary rounded-md transition-colors duration-150 ease-out min-h-touch min-w-touch"
              title={isCollapsed ? 'Expand Sidebar' : 'Collapse Sidebar'}
            >
              <Icon name={isCollapsed ? 'ChevronRight' : 'ChevronLeft'} size={16} />
            </button>
          </div>

          {/* Navigation Items */}
          <nav className="flex-1 p-4 space-y-2 overflow-y-auto">
            {navigationItems.map((item) => (
              <button
                key={item.path}
                onClick={() => handleNavigation(item.path)}
                className={`
                  w-full flex items-center space-x-3 px-3 py-3 rounded-md transition-colors duration-150 ease-out min-h-touch
                  ${isActiveRoute(item.path)
                    ? 'bg-primary-100 text-primary-700 border-r-2 border-primary-600' :'text-text-secondary hover:text-text-primary hover:bg-surface-secondary'
                  }
                `}
                title={isCollapsed ? item.tooltip : item.label}
              >
                <Icon
                  name={item.icon}
                  size={20}
                  className={isActiveRoute(item.path) ? 'text-primary-600' : 'text-current'}
                />
                {!isCollapsed && (
                  <span className="text-sm font-medium truncate">{item.label}</span>
                )}
              </button>
            ))}
          </nav>

          {/* Quick Actions */}
          <div className="p-4 border-t border-border">
            <div className="space-y-2">
              <button
                className={`
                  w-full flex items-center space-x-3 px-3 py-2 text-sm text-text-secondary hover:text-text-primary hover:bg-surface-secondary rounded-md transition-colors duration-150 ease-out min-h-touch
                  ${isCollapsed ? 'justify-center' : ''}
                `}
                title="Quick Check-in"
              >
                <Icon name="Zap" size={16} />
                {!isCollapsed && <span>Quick Check-in</span>}
              </button>
              <button
                className={`
                  w-full flex items-center space-x-3 px-3 py-2 text-sm text-text-secondary hover:text-text-primary hover:bg-surface-secondary rounded-md transition-colors duration-150 ease-out min-h-touch
                  ${isCollapsed ? 'justify-center' : ''}
                `}
                title="Emergency Report"
              >
                <Icon name="AlertTriangle" size={16} />
                {!isCollapsed && <span>Emergency Report</span>}
              </button>
            </div>
          </div>

          {/* Status Indicator */}
          <div className="p-4 border-t border-border">
            <div className={`flex items-center space-x-2 ${isCollapsed ? 'justify-center' : ''}`}>
              <div className="w-2 h-2 bg-success rounded-full animate-pulse" />
              {!isCollapsed && (
                <div>
                  <p className="text-xs text-text-secondary">System Status</p>
                  <p className="text-xs font-medium text-success">All Systems Operational</p>
                </div>
              )}
            </div>
          </div>
        </div>
      </aside>
    </>
  );
};

export default Sidebar;