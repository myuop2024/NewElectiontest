// src/utils/supabaseClient.js
import { createClient } from '@supabase/supabase-js';

const supabaseUrl = import.meta.env.VITE_SUPABASE_URL;
const supabaseAnonKey = import.meta.env.VITE_SUPABASE_ANON_KEY;

if (!supabaseUrl || !supabaseAnonKey) {
  console.warn('Supabase credentials not found. Using mock data.');
}

export const supabase = supabaseUrl && supabaseAnonKey 
  ? createClient(supabaseUrl, supabaseAnonKey)
  : null;

// Function to get observers data from Supabase or mock data if not available
export const getObservers = async () => {
  if (!supabase) {
    // Return mock data if Supabase is not configured
    return {
      data: [
        {
          id: 'OBS-001',
          name: 'John Doe',
          email: 'john.doe@example.com',
          phone: '+1234567890',
          role: 'indoor-agent',
          parish: 'Kingston',
          pollingStation: 'STA-001',
          status: 'active',
          lastCheckIn: new Date().toISOString()
        },
        {
          id: 'OBS-002',
          name: 'Jane Smith',
          email: 'jane.smith@example.com',
          phone: '+1987654321',
          role: 'roving-observer',
          parish: 'St. Andrew',
          pollingStation: 'STA-002',
          status: 'inactive',
          lastCheckIn: null
        },
        {
          id: 'OBS-003',
          name: 'Bob Johnson',
          email: 'bob.johnson@example.com',
          phone: '+1567890123',
          role: 'parish-coordinator',
          parish: 'St. Catherine',
          pollingStation: null,
          status: 'pending-check-in',
          lastCheckIn: null
        }
      ]
    };
  }

  try {
    // Query user_profiles table to get observer data
    const { data, error } = await supabase
      .from('user_profiles')
      .select('*')
      .order('created_at', { ascending: false });

    if (error) {
      throw error;
    }

    // Transform data to match expected format if needed
    const transformedData = data.map(observer => ({
      id: observer.id,
      name: observer.full_name,
      email: observer.username,
      phone: observer.phone || '',
      role: observer.role || 'observer',
      parish: observer.parish || '',
      pollingStation: observer.station_assignment,
      status: observer.is_online ? 'active' : 'inactive',
      lastCheckIn: observer.last_seen
    }));

    return { data: transformedData };
  } catch (error) {
    console.error('Error fetching observers:', error.message);
    return { data: [], error };
  }
};

// Function to get polling stations data from Supabase or mock data if not available
export const getPollingStations = async () => {
  if (!supabase) {
    // Return mock data if Supabase is not configured
    return {
      data: [
        {
          id: 'STA-001',
          name: 'Kingston Primary School',
          address: '123 Main St, Kingston',
          parish: 'Kingston',
          expectedVoters: 1200,
          status: 'operational',
          assignedObservers: ['OBS-001'],
          incidentsReported: 0,
          gpsCoordinates: { lat: 18.0179, lng: -76.8099 }
        },
        {
          id: 'STA-002',
          name: 'St. Andrew High School',
          address: '456 Park Ave, St. Andrew',
          parish: 'St. Andrew',
          expectedVoters: 1500,
          status: 'issue-reported',
          assignedObservers: ['OBS-002'],
          incidentsReported: 2,
          gpsCoordinates: { lat: 18.0270, lng: -76.7979 }
        },
        {
          id: 'STA-003',
          name: 'St. Catherine Community Center',
          address: '789 Church St, Spanish Town',
          parish: 'St. Catherine',
          expectedVoters: 900,
          status: 'operational',
          assignedObservers: [],
          incidentsReported: 0,
          gpsCoordinates: { lat: 17.9991, lng: -76.9674 }
        }
      ]
    };
  }

  try {
    // Query the polling_stations table
    const { data, error } = await supabase
      .from('polling_stations')
      .select('*')
      .order('name', { ascending: true });

    if (error) {
      console.error('Error fetching polling stations:', error.message);
      // If the table doesn't exist, we'll return mock data instead of throwing
      if (error.message.includes('relation "public.polling_stations" does not exist')) {
        console.warn('The polling_stations table does not exist yet. Using mock data.');
        return getPollingStations();
      }
      throw error;
    }

    // If the table exists but is empty, return mock data with a note
    if (!data || data.length === 0) {
      console.warn('No polling stations found in database, using mock data');
      return getPollingStations();
    }

    // Transform data to match expected format if needed
    const transformedData = data.map(station => ({
      id: station.id,
      name: station.name,
      address: station.address,
      parish: station.parish,
      expectedVoters: station.expected_voters,
      status: station.status,
      assignedObservers: [], // This would need to be populated from a relationship query
      incidentsReported: 0, // This would need to be populated from a relationship query
      gpsCoordinates: station.gps_coordinates
    }));

    return { data: transformedData };
  } catch (error) {
    console.error('Error fetching polling stations:', error.message);
    // Fallback to mock data if there's an error
    return getPollingStations();
  }
};

// Function to get incident reports data from Supabase or mock data if not available
export const getIncidentReports = async () => {
  if (!supabase) {
    // Return mock data if Supabase is not configured
    return {
      data: [
        {
          id: 'INC-001',
          description: 'Voter intimidation reported outside polling station',
          pollingStation: 'STA-002',
          reportedBy: 'OBS-002',
          category: 'voter-intimidation',
          severity: 'high',
          status: 'in-progress',
          timestamp: new Date(Date.now() - 3600000).toISOString(),
          resolution: null,
          attachments: [
            '/assets/images/incident-photo-1.jpg'
          ]
        },
        {
          id: 'INC-002',
          description: 'Long queues forming due to slow processing',
          pollingStation: 'STA-001',
          reportedBy: 'OBS-001',
          category: 'logistics',
          severity: 'medium',
          status: 'resolved',
          timestamp: new Date(Date.now() - 7200000).toISOString(),
          resolution: 'Additional staff assigned to speed up processing',
          attachments: []
        },
        {
          id: 'INC-003',
          description: 'Equipment failure - ballot scanner not working',
          pollingStation: 'STA-002',
          reportedBy: 'OBS-002',
          category: 'equipment-failure',
          severity: 'high',
          status: 'escalated',
          timestamp: new Date(Date.now() - 5400000).toISOString(),
          resolution: null,
          attachments: [
            '/assets/images/incident-photo-2.jpg',
            '/assets/images/incident-photo-3.jpg'
          ]
        }
      ]
    };
  }

  try {
    // Query the incident_reports table with corrected join syntax for auth.users
    const { data, error } = await supabase
      .from('incident_reports')
      .select(`
        id,
        description,
        polling_station_id,
        reported_by,
        category,
        severity,
        status,
        resolution,
        attachments,
        created_at,
        updated_at,
        polling_stations(
          id,
          name,
          parish
        )
      `)
      .order('created_at', { ascending: false });

    if (error) {
      console.error('Error fetching incident reports:', error.message);
      // If the table doesn't exist, we'll return mock data instead of throwing
      if (error.message.includes('relation "public.incident_reports" does not exist')) {
        console.warn('The incident_reports table does not exist yet. Using mock data.');
        return getIncidentReports();
      }
      throw error;
    }

    // If the table exists but is empty, return mock data with a note
    if (!data || data.length === 0) {
      console.warn('No incident reports found in database, using mock data');
      return getIncidentReports();
    }

    // Get user information separately for reported_by field
    const userIds = [...new Set(data.map(incident => incident.reported_by).filter(Boolean))];
    let usersData = [];
    
    if (userIds.length > 0) {
      const { data: users, error: usersError } = await supabase
        .from('user_profiles')
        .select('id, full_name, username')
        .in('id', userIds);
      
      if (!usersError && users) {
        usersData = users;
      }
    }

    // Transform data to match the expected format used by the React components
    const transformedData = data.map(incident => {
      const reporter = usersData.find(user => user.id === incident.reported_by);
      
      return {
        id: incident.id,
        description: incident.description,
        pollingStation: incident.polling_station_id,
        reportedBy: incident.reported_by,
        reporterName: reporter ? (reporter.full_name || reporter.username) : 'Unknown',
        category: incident.category,
        severity: incident.severity,
        status: incident.status,
        timestamp: incident.created_at,
        resolution: incident.resolution,
        attachments: Array.isArray(incident.attachments) ? incident.attachments : [],
        pollingStationData: incident.polling_stations
      };
    });

    return { data: transformedData };
  } catch (error) {
    console.error('Error fetching incident reports:', error.message);
    // Fallback to mock data if there's an error
    return getIncidentReports();
  }
};

// Function to get system analytics data from Supabase or mock data if not available
export const getSystemAnalytics = async () => {
  if (!supabase) {
    // Return mock data if Supabase is not configured
    return {
      data: {
        observerActivities: {
          activeObservers: 42,
          totalCheckIns: 75,
          totalDocumentsUploaded: 64,
          totalIncidentsReported: 8,
          observersByParish: {
            'Kingston': 15,
            'St. Andrew': 20,
            'St. Catherine': 12,
            'St. Thomas': 8
          }
        },
        pollingStationCoverage: {
          totalStations: 120,
          stationsWithObservers: 96,
          coveragePercentage: 80,
          averageIncidentsPerStation: 0.2
        },
        systemHealth: {
          uptime: 99.8,
          errorRate: 0.2,
          storageUsed: 45,
          averageResponseTime: 124,
          apiCallsToday: 1267
        },
        dataSync: {
          lastSyncTime: new Date().toISOString(),
          totalDataSynced: '45.7 MB',
          failedSyncAttempts: 2,
          documentsAwaitingSync: 7
        }
      }
    };
  }

  try {
    // In a real app, you would calculate these metrics from various tables
    // For now, we'll return mock data even if Supabase is configured
    // In a production app, you would implement this with actual queries
    
    // This would typically involve multiple queries and calculations
    // For example, counting active users, calculating percentages, etc.
    
    return {
      data: {
        observerActivities: {
          activeObservers: 42,
          totalCheckIns: 75,
          totalDocumentsUploaded: 64,
          totalIncidentsReported: 8,
          observersByParish: {
            'Kingston': 15,
            'St. Andrew': 20,
            'St. Catherine': 12,
            'St. Thomas': 8
          }
        },
        pollingStationCoverage: {
          totalStations: 120,
          stationsWithObservers: 96,
          coveragePercentage: 80,
          averageIncidentsPerStation: 0.2
        },
        systemHealth: {
          uptime: 99.8,
          errorRate: 0.2,
          storageUsed: 45,
          averageResponseTime: 124,
          apiCallsToday: 1267
        },
        dataSync: {
          lastSyncTime: new Date().toISOString(),
          totalDataSynced: '45.7 MB',
          failedSyncAttempts: 2,
          documentsAwaitingSync: 7
        }
      }
    };
  } catch (error) {
    console.error('Error fetching system analytics:', error.message);
    return getSystemAnalytics();
  }
};

export default supabase;