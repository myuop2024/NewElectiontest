import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import Icon from 'components/AppIcon';
import LoginForm from './components/LoginForm';
import RegistrationForm from './components/RegistrationForm';
import SecurityInfo from './components/SecurityInfo';

const LoginRegistration = () => {
  const [activeTab, setActiveTab] = useState('login');
  const [isLoading, setIsLoading] = useState(false);
  const navigate = useNavigate();

  const mockCredentials = {
    phone: "+1-876-555-0123",
    smsCode: "123456",
    email: "observer@caffe.org.jm",
    password: "CAFFE2024!",
    whatsappCode: "789012"
  };

  const handleTabSwitch = (tab) => {
    setActiveTab(tab);
  };

  const handleLoginSuccess = (userRole) => {
    setIsLoading(true);
    setTimeout(() => {
      setIsLoading(false);
      // Navigate based on user role
      switch (userRole) {
        case 'admin': navigate('/admin-control-center');
          break;
        case 'parish-coordinator': navigate('/roving-observer-route-management');
          break;
        default:
          navigate('/observer-dashboard');
      }
    }, 2000);
  };

  const handleRegistrationSuccess = () => {
    setIsLoading(true);
    setTimeout(() => {
      setIsLoading(false);
      navigate('/observer-dashboard');
    }, 2000);
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-primary-50 to-background">
      <div className="container mx-auto px-4 py-8">
        <div className="flex flex-col lg:flex-row min-h-screen lg:min-h-[calc(100vh-4rem)]">
          {/* Left Side - Branding & Info (Desktop) */}
          <div className="hidden lg:flex lg:w-1/2 flex-col justify-center p-8">
            <div className="max-w-md">
              {/* CAFFE Logo */}
              <div className="mb-8">
                <div className="w-20 h-20 bg-primary rounded-xl flex items-center justify-center mb-6">
                  <svg
                    viewBox="0 0 24 24"
                    className="w-10 h-10 text-white"
                    fill="currentColor"
                  >
                    <path d="M12 2L2 7v10c0 5.55 3.84 9.74 9 11 5.16-1.26 9-5.45 9-11V7l-10-5z" />
                    <path d="M9 12l2 2 4-4" stroke="white" strokeWidth="2" fill="none" />
                  </svg>
                </div>
                <h1 className="text-4xl font-bold text-text-primary mb-2">CAFFE</h1>
                <p className="text-lg text-text-secondary font-mono">Electoral Observer Platform</p>
                <p className="text-sm text-text-secondary mt-2">Citizens Action For Free And Fair Elections</p>
              </div>

              {/* Mission Statement */}
              <div className="mb-8">
                <h2 className="text-xl font-semibold text-text-primary mb-4">Securing Democracy Through Technology</h2>
                <p className="text-text-secondary leading-relaxed mb-4">
                  Join Jamaica's premier electoral observation network. Our digital platform empowers citizens to ensure transparent, fair, and credible elections across all constituencies.
                </p>
                <div className="space-y-3">
                  <div className="flex items-center space-x-3">
                    <div className="w-8 h-8 bg-success-100 rounded-full flex items-center justify-center">
                      <Icon name="Shield" size={16} className="text-success-600" />
                    </div>
                    <span className="text-sm text-text-primary">Military-grade security & encryption</span>
                  </div>
                  <div className="flex items-center space-x-3">
                    <div className="w-8 h-8 bg-primary-100 rounded-full flex items-center justify-center">
                      <Icon name="MapPin" size={16} className="text-primary-600" />
                    </div>
                    <span className="text-sm text-text-primary">Real-time location verification</span>
                  </div>
                  <div className="flex items-center space-x-3">
                    <div className="w-8 h-8 bg-secondary-100 rounded-full flex items-center justify-center">
                      <Icon name="Users" size={16} className="text-secondary-600" />
                    </div>
                    <span className="text-sm text-text-primary">Collaborative observation network</span>
                  </div>
                </div>
              </div>

              {/* Security Info Component */}
              <SecurityInfo />
            </div>
          </div>

          {/* Right Side - Authentication Form */}
          <div className="w-full lg:w-1/2 flex items-center justify-center p-4 lg:p-8">
            <div className="w-full max-w-md">
              {/* Mobile Logo */}
              <div className="lg:hidden text-center mb-8">
                <div className="w-16 h-16 bg-primary rounded-xl flex items-center justify-center mx-auto mb-4">
                  <svg
                    viewBox="0 0 24 24"
                    className="w-8 h-8 text-white"
                    fill="currentColor"
                  >
                    <path d="M12 2L2 7v10c0 5.55 3.84 9.74 9 11 5.16-1.26 9-5.45 9-11V7l-10-5z" />
                    <path d="M9 12l2 2 4-4" stroke="white" strokeWidth="2" fill="none" />
                  </svg>
                </div>
                <h1 className="text-2xl font-bold text-text-primary">CAFFE</h1>
                <p className="text-sm text-text-secondary font-mono">Electoral Observer Platform</p>
              </div>

              {/* Authentication Card */}
              <div className="bg-surface border border-border rounded-xl shadow-elevation-3 p-6 lg:p-8">
                {/* Tab Navigation */}
                <div className="flex mb-6 bg-surface-secondary rounded-lg p-1">
                  <button
                    onClick={() => handleTabSwitch('login')}
                    className={`flex-1 py-2 px-4 rounded-md text-sm font-medium transition-colors duration-150 ease-out min-h-touch ${
                      activeTab === 'login' ?'bg-surface text-primary shadow-elevation-1' :'text-text-secondary hover:text-text-primary'
                    }`}
                  >
                    Login
                  </button>
                  <button
                    onClick={() => handleTabSwitch('register')}
                    className={`flex-1 py-2 px-4 rounded-md text-sm font-medium transition-colors duration-150 ease-out min-h-touch ${
                      activeTab === 'register' ?'bg-surface text-primary shadow-elevation-1' :'text-text-secondary hover:text-text-primary'
                    }`}
                  >
                    Register
                  </button>
                </div>

                {/* Form Content */}
                {activeTab === 'login' ? (
                  <LoginForm
                    onSuccess={handleLoginSuccess}
                    isLoading={isLoading}
                    mockCredentials={mockCredentials}
                  />
                ) : (
                  <RegistrationForm
                    onSuccess={handleRegistrationSuccess}
                    isLoading={isLoading}
                    onSwitchToLogin={() => handleTabSwitch('login')}
                  />
                )}

                {/* Footer */}
                <div className="mt-6 pt-6 border-t border-border text-center">
                  <p className="text-xs text-text-secondary">
                    By continuing, you agree to CAFFE's Terms of Service and Privacy Policy
                  </p>
                  <div className="flex items-center justify-center space-x-4 mt-3">
                    <div className="flex items-center space-x-1">
                      <Icon name="Shield" size={12} className="text-success" />
                      <span className="text-xs text-text-secondary">Secure</span>
                    </div>
                    <div className="flex items-center space-x-1">
                      <Icon name="Lock" size={12} className="text-success" />
                      <span className="text-xs text-text-secondary">Encrypted</span>
                    </div>
                    <div className="flex items-center space-x-1">
                      <Icon name="Check" size={12} className="text-success" />
                      <span className="text-xs text-text-secondary">Verified</span>
                    </div>
                  </div>
                </div>
              </div>

              {/* Emergency Contact */}
              <div className="mt-6 text-center">
                <p className="text-sm text-text-secondary mb-2">Need immediate assistance?</p>
                <button className="flex items-center space-x-2 mx-auto px-4 py-2 bg-accent text-white rounded-lg hover:bg-accent-700 transition-colors duration-150 ease-out min-h-touch">
                  <Icon name="Phone" size={16} />
                  <span className="text-sm font-medium">Emergency Contact</span>
                </button>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Loading Overlay */}
      {isLoading && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-200">
          <div className="bg-surface rounded-lg p-6 max-w-sm w-full mx-4">
            <div className="text-center">
              <div className="w-12 h-12 bg-primary rounded-full flex items-center justify-center mx-auto mb-4">
                <Icon name="RefreshCw" size={24} className="text-white animate-spin" />
              </div>
              <h3 className="text-lg font-semibold text-text-primary mb-2">
                {activeTab === 'login' ? 'Authenticating...' : 'Creating Account...'}
              </h3>
              <p className="text-sm text-text-secondary">
                {activeTab === 'login' ?'Verifying your credentials and setting up your session' :'Processing your registration and generating Observer ID'
                }
              </p>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default LoginRegistration;