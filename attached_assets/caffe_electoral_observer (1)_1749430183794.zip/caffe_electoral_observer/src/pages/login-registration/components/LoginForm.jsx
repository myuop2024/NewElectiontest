import React, { useState } from 'react';
import Icon from 'components/AppIcon';

const LoginForm = ({ onSuccess, isLoading, mockCredentials }) => {
  const [loginMethod, setLoginMethod] = useState('sms');
  const [formData, setFormData] = useState({
    phone: '',
    smsCode: '',
    email: '',
    password: '',
    whatsappCode: ''
  });
  const [step, setStep] = useState(1);
  const [errors, setErrors] = useState({});
  const [showPassword, setShowPassword] = useState(false);

  const handleInputChange = (field, value) => {
    setFormData(prev => ({ ...prev, [field]: value }));
    if (errors[field]) {
      setErrors(prev => ({ ...prev, [field]: '' }));
    }
  };

  const validateForm = () => {
    const newErrors = {};

    if (loginMethod === 'sms') {
      if (step === 1) {
        if (!formData.phone) {
          newErrors.phone = 'Phone number is required';
        } else if (formData.phone !== mockCredentials.phone) {
          newErrors.phone = `Use mock phone: ${mockCredentials.phone}`;
        }
      } else {
        if (!formData.smsCode) {
          newErrors.smsCode = 'SMS code is required';
        } else if (formData.smsCode !== mockCredentials.smsCode) {
          newErrors.smsCode = `Use mock code: ${mockCredentials.smsCode}`;
        }
      }
    } else if (loginMethod === 'email') {
      if (!formData.email) {
        newErrors.email = 'Email is required';
      } else if (formData.email !== mockCredentials.email) {
        newErrors.email = `Use mock email: ${mockCredentials.email}`;
      }
      if (!formData.password) {
        newErrors.password = 'Password is required';
      } else if (formData.password !== mockCredentials.password) {
        newErrors.password = `Use mock password: ${mockCredentials.password}`;
      }
    } else if (loginMethod === 'whatsapp') {
      if (!formData.whatsappCode) {
        newErrors.whatsappCode = 'WhatsApp code is required';
      } else if (formData.whatsappCode !== mockCredentials.whatsappCode) {
        newErrors.whatsappCode = `Use mock code: ${mockCredentials.whatsappCode}`;
      }
    }

    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    if (!validateForm()) return;

    if (loginMethod === 'sms' && step === 1) {
      setStep(2);
      return;
    }

    // Simulate different user roles based on login method
    let userRole = 'observer';
    if (loginMethod === 'email') userRole = 'admin';
    if (loginMethod === 'whatsapp') userRole = 'parish-coordinator';

    onSuccess(userRole);
  };

  const handleWhatsAppLogin = () => {
    // Simulate WhatsApp one-tap authentication
    setFormData(prev => ({ ...prev, whatsappCode: mockCredentials.whatsappCode }));
    setTimeout(() => {
      onSuccess('parish-coordinator');
    }, 1000);
  };

  const getButtonText = () => {
    if (loginMethod === 'sms') {
      return step === 1 ? 'Send SMS Code' : 'Verify & Login';
    }
    return 'Login';
  };

  return (
    <form onSubmit={handleSubmit} className="space-y-6">
      {/* Login Method Selection */}
      <div className="space-y-3">
        <label className="text-sm font-medium text-text-primary">Choose Login Method</label>
        <div className="grid grid-cols-1 gap-2">
          <button
            type="button"
            onClick={() => setLoginMethod('sms')}
            className={`flex items-center space-x-3 p-3 rounded-lg border transition-colors duration-150 ease-out min-h-touch ${
              loginMethod === 'sms' ?'border-primary bg-primary-50 text-primary' :'border-border hover:bg-surface-secondary'
            }`}
          >
            <Icon name="MessageSquare" size={20} />
            <div className="text-left">
              <p className="font-medium">SMS Verification</p>
              <p className="text-xs text-text-secondary">Secure code via text message</p>
            </div>
          </button>
          
          <button
            type="button"
            onClick={() => setLoginMethod('email')}
            className={`flex items-center space-x-3 p-3 rounded-lg border transition-colors duration-150 ease-out min-h-touch ${
              loginMethod === 'email' ?'border-primary bg-primary-50 text-primary' :'border-border hover:bg-surface-secondary'
            }`}
          >
            <Icon name="Mail" size={20} />
            <div className="text-left">
              <p className="font-medium">Email & Password</p>
              <p className="text-xs text-text-secondary">Traditional login method</p>
            </div>
          </button>

          <button
            type="button"
            onClick={() => setLoginMethod('whatsapp')}
            className={`flex items-center space-x-3 p-3 rounded-lg border transition-colors duration-150 ease-out min-h-touch ${
              loginMethod === 'whatsapp' ?'border-primary bg-primary-50 text-primary' :'border-border hover:bg-surface-secondary'
            }`}
          >
            <Icon name="MessageCircle" size={20} />
            <div className="text-left">
              <p className="font-medium">WhatsApp Login</p>
              <p className="text-xs text-text-secondary">One-tap authentication</p>
            </div>
          </button>
        </div>
      </div>

      {/* SMS Login Form */}
      {loginMethod === 'sms' && (
        <div className="space-y-4">
          {step === 1 ? (
            <div>
              <label className="block text-sm font-medium text-text-primary mb-2">
                Phone Number
              </label>
              <div className="relative">
                <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                  <span className="text-text-secondary text-sm">+1-876</span>
                </div>
                <input
                  type="tel"
                  value={formData.phone}
                  onChange={(e) => handleInputChange('phone', e.target.value)}
                  className={`w-full pl-16 pr-4 py-3 border rounded-lg focus:ring-2 focus:ring-primary-500 focus:border-primary-500 transition-colors duration-150 ease-out ${
                    errors.phone ? 'border-error' : 'border-border'
                  }`}
                  placeholder="555-0123"
                />
              </div>
              {errors.phone && (
                <p className="mt-1 text-sm text-error">{errors.phone}</p>
              )}
            </div>
          ) : (
            <div>
              <label className="block text-sm font-medium text-text-primary mb-2">
                SMS Verification Code
              </label>
              <input
                type="text"
                value={formData.smsCode}
                onChange={(e) => handleInputChange('smsCode', e.target.value)}
                className={`w-full px-4 py-3 border rounded-lg focus:ring-2 focus:ring-primary-500 focus:border-primary-500 transition-colors duration-150 ease-out ${
                  errors.smsCode ? 'border-error' : 'border-border'
                }`}
                placeholder="Enter 6-digit code"
                maxLength="6"
              />
              {errors.smsCode && (
                <p className="mt-1 text-sm text-error">{errors.smsCode}</p>
              )}
              <p className="mt-2 text-sm text-text-secondary">
                Code sent to {formData.phone}. 
                <button
                  type="button"
                  onClick={() => setStep(1)}
                  className="text-primary hover:text-primary-700 ml-1"
                >
                  Change number
                </button>
              </p>
            </div>
          )}
        </div>
      )}

      {/* Email Login Form */}
      {loginMethod === 'email' && (
        <div className="space-y-4">
          <div>
            <label className="block text-sm font-medium text-text-primary mb-2">
              Email Address
            </label>
            <input
              type="email"
              value={formData.email}
              onChange={(e) => handleInputChange('email', e.target.value)}
              className={`w-full px-4 py-3 border rounded-lg focus:ring-2 focus:ring-primary-500 focus:border-primary-500 transition-colors duration-150 ease-out ${
                errors.email ? 'border-error' : 'border-border'
              }`}
              placeholder="your.email@caffe.org.jm"
            />
            {errors.email && (
              <p className="mt-1 text-sm text-error">{errors.email}</p>
            )}
          </div>
          
          <div>
            <label className="block text-sm font-medium text-text-primary mb-2">
              Password
            </label>
            <div className="relative">
              <input
                type={showPassword ? 'text' : 'password'}
                value={formData.password}
                onChange={(e) => handleInputChange('password', e.target.value)}
                className={`w-full px-4 py-3 pr-12 border rounded-lg focus:ring-2 focus:ring-primary-500 focus:border-primary-500 transition-colors duration-150 ease-out ${
                  errors.password ? 'border-error' : 'border-border'
                }`}
                placeholder="Enter your password"
              />
              <button
                type="button"
                onClick={() => setShowPassword(!showPassword)}
                className="absolute inset-y-0 right-0 pr-3 flex items-center"
              >
                <Icon
                  name={showPassword ? 'EyeOff' : 'Eye'}
                  size={20}
                  className="text-text-secondary hover:text-text-primary"
                />
              </button>
            </div>
            {errors.password && (
              <p className="mt-1 text-sm text-error">{errors.password}</p>
            )}
          </div>
        </div>
      )}

      {/* WhatsApp Login */}
      {loginMethod === 'whatsapp' && (
        <div className="space-y-4">
          <div className="text-center p-6 bg-success-50 rounded-lg border border-success-200">
            <Icon name="MessageCircle" size={48} className="text-success mx-auto mb-4" />
            <h3 className="text-lg font-semibold text-text-primary mb-2">WhatsApp Authentication</h3>
            <p className="text-sm text-text-secondary mb-4">
              Click below to receive a secure login code via WhatsApp
            </p>
            <button
              type="button"
              onClick={handleWhatsAppLogin}
              className="w-full flex items-center justify-center space-x-2 px-6 py-3 bg-success text-white rounded-lg hover:bg-success-700 transition-colors duration-150 ease-out min-h-touch"
            >
              <Icon name="MessageCircle" size={20} />
              <span className="font-medium">Login with WhatsApp</span>
            </button>
          </div>
          
          <div className="text-center">
            <p className="text-sm text-text-secondary mb-2">Or enter code manually:</p>
            <input
              type="text"
              value={formData.whatsappCode}
              onChange={(e) => handleInputChange('whatsappCode', e.target.value)}
              className={`w-full px-4 py-3 border rounded-lg focus:ring-2 focus:ring-primary-500 focus:border-primary-500 transition-colors duration-150 ease-out ${
                errors.whatsappCode ? 'border-error' : 'border-border'
              }`}
              placeholder="Enter WhatsApp code"
            />
            {errors.whatsappCode && (
              <p className="mt-1 text-sm text-error">{errors.whatsappCode}</p>
            )}
          </div>
        </div>
      )}

      {/* Submit Button */}
      {loginMethod !== 'whatsapp' && (
        <button
          type="submit"
          disabled={isLoading}
          className="w-full flex items-center justify-center space-x-2 px-6 py-3 bg-primary text-white rounded-lg hover:bg-primary-700 focus:ring-2 focus:ring-primary-500 focus:ring-offset-2 transition-colors duration-200 ease-in-out disabled:opacity-50 disabled:cursor-not-allowed min-h-touch"
        >
          {isLoading ? (
            <Icon name="RefreshCw" size={20} className="animate-spin" />
          ) : (
            <Icon name="LogIn" size={20} />
          )}
          <span className="font-medium">{getButtonText()}</span>
        </button>
      )}

      {/* Forgot Password */}
      {loginMethod === 'email' && (
        <div className="text-center">
          <button
            type="button"
            className="text-sm text-primary hover:text-primary-700 transition-colors duration-150 ease-out"
          >
            Forgot your password?
          </button>
        </div>
      )}
    </form>
  );
};

export default LoginForm;