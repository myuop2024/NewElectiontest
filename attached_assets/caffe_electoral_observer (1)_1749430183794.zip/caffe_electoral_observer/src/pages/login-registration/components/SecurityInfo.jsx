import React from 'react';
import Icon from 'components/AppIcon';

const SecurityInfo = () => {
  const securityFeatures = [
    {
      icon: 'Shield',
      title: 'End-to-End Encryption',
      description: 'All data transmission uses military-grade AES-256 encryption'
    },
    {
      icon: 'Smartphone',
      title: 'Device Binding',
      description: 'Secure device fingerprinting prevents unauthorized access'
    },
    {
      icon: 'Eye',
      title: 'Audit Trail',
      description: 'Complete logging of all observer activities for transparency'
    },
    {
      icon: 'Clock',
      title: 'Real-time Verification',
      description: 'Instant validation of observer credentials and location'
    }
  ];

  return (
    <div className="bg-surface border border-border rounded-lg p-6">
      <div className="flex items-center space-x-2 mb-4">
        <Icon name="Lock" size={20} className="text-primary" />
        <h3 className="text-lg font-semibold text-text-primary">Security & Trust</h3>
      </div>
      
      <p className="text-sm text-text-secondary mb-6">
        CAFFE employs enterprise-grade security measures to protect electoral integrity and observer safety.
      </p>

      <div className="space-y-4">
        {securityFeatures.map((feature, index) => (
          <div key={index} className="flex items-start space-x-3">
            <div className="w-8 h-8 bg-primary-100 rounded-full flex items-center justify-center flex-shrink-0 mt-0.5">
              <Icon name={feature.icon} size={16} className="text-primary-600" />
            </div>
            <div>
              <h4 className="text-sm font-medium text-text-primary">{feature.title}</h4>
              <p className="text-xs text-text-secondary mt-1">{feature.description}</p>
            </div>
          </div>
        ))}
      </div>

      <div className="mt-6 pt-4 border-t border-border">
        <div className="flex items-center space-x-2 text-success">
          <Icon name="CheckCircle" size={16} />
          <span className="text-sm font-medium">Verified by Electoral Office of Jamaica</span>
        </div>
      </div>
    </div>
  );
};

export default SecurityInfo;