import React, { useState } from 'react';
import Icon from 'components/AppIcon';

const RegistrationForm = ({ onSuccess, isLoading, onSwitchToLogin }) => {
  const [step, setStep] = useState(1);
  const [formData, setFormData] = useState({
    firstName: '',
    lastName: '',
    email: '',
    phone: '',
    trn: '',
    role: '',
    parish: '',
    constituency: '',
    password: '',
    confirmPassword: '',
    agreeTerms: false,
    agreePrivacy: false
  });
  const [errors, setErrors] = useState({});
  const [showPassword, setShowPassword] = useState(false);
  const [generatedObserverId, setGeneratedObserverId] = useState('');

  const roles = [
    { value: 'indoor-agent', label: 'Indoor Agent', description: 'Stationed at specific polling locations' },
    { value: 'roving-observer', label: 'Roving Observer', description: 'Mobile observer covering multiple locations' },
    { value: 'parish-coordinator', label: 'Parish Coordinator', description: 'Regional supervisor managing multiple observers' }
  ];

  const parishes = [
    'Kingston', 'St. Andrew', 'St. Thomas', 'Portland', 'St. Mary', 'St. Ann',
    'Trelawny', 'St. James', 'Hanover', 'Westmoreland', 'St. Elizabeth',
    'Manchester', 'Clarendon', 'St. Catherine'
  ];

  const handleInputChange = (field, value) => {
    setFormData(prev => ({ ...prev, [field]: value }));
    if (errors[field]) {
      setErrors(prev => ({ ...prev, [field]: '' }));
    }
  };

  const generateObserverId = () => {
    const year = new Date().getFullYear();
    const randomNum = Math.floor(Math.random() * 1000).toString().padStart(3, '0');
    return `OBS-${year}-${randomNum}`;
  };

  const validateStep = (stepNumber) => {
    const newErrors = {};

    if (stepNumber === 1) {
      if (!formData.firstName.trim()) newErrors.firstName = 'First name is required';
      if (!formData.lastName.trim()) newErrors.lastName = 'Last name is required';
      if (!formData.email.trim()) newErrors.email = 'Email is required';
      else if (!/\S+@\S+\.\S+/.test(formData.email)) newErrors.email = 'Invalid email format';
      if (!formData.phone.trim()) newErrors.phone = 'Phone number is required';
      if (!formData.trn.trim()) newErrors.trn = 'TRN is required';
      else if (!/^\d{9}$/.test(formData.trn)) newErrors.trn = 'TRN must be 9 digits';
    }

    if (stepNumber === 2) {
      if (!formData.role) newErrors.role = 'Please select a role';
      if (!formData.parish) newErrors.parish = 'Please select a parish';
      if (!formData.constituency.trim()) newErrors.constituency = 'Constituency is required';
    }

    if (stepNumber === 3) {
      if (!formData.password) newErrors.password = 'Password is required';
      else if (formData.password.length < 8) newErrors.password = 'Password must be at least 8 characters';
      if (formData.password !== formData.confirmPassword) newErrors.confirmPassword = 'Passwords do not match';
      if (!formData.agreeTerms) newErrors.agreeTerms = 'You must agree to the terms of service';
      if (!formData.agreePrivacy) newErrors.agreePrivacy = 'You must agree to the privacy policy';
    }

    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  const handleNext = () => {
    if (validateStep(step)) {
      if (step === 2) {
        // Generate Observer ID when moving to final step
        setGeneratedObserverId(generateObserverId());
      }
      setStep(step + 1);
    }
  };

  const handlePrevious = () => {
    setStep(step - 1);
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    if (validateStep(3)) {
      onSuccess();
    }
  };

  const renderStepIndicator = () => (
    <div className="flex items-center justify-center mb-6">
      {[1, 2, 3].map((stepNum) => (
        <React.Fragment key={stepNum}>
          <div className={`w-8 h-8 rounded-full flex items-center justify-center text-sm font-medium ${
            stepNum <= step ? 'bg-primary text-white' : 'bg-surface-secondary text-text-secondary'
          }`}>
            {stepNum < step ? <Icon name="Check" size={16} /> : stepNum}
          </div>
          {stepNum < 3 && (
            <div className={`w-12 h-0.5 ${stepNum < step ? 'bg-primary' : 'bg-surface-secondary'}`} />
          )}
        </React.Fragment>
      ))}
    </div>
  );

  return (
    <form onSubmit={handleSubmit} className="space-y-6">
      {renderStepIndicator()}

      {/* Step 1: Personal Information */}
      {step === 1 && (
        <div className="space-y-4">
          <div className="text-center mb-6">
            <h3 className="text-lg font-semibold text-text-primary">Personal Information</h3>
            <p className="text-sm text-text-secondary">Enter your basic details for KYC verification</p>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div>
              <label className="block text-sm font-medium text-text-primary mb-2">
                First Name *
              </label>
              <input
                type="text"
                value={formData.firstName}
                onChange={(e) => handleInputChange('firstName', e.target.value)}
                className={`w-full px-4 py-3 border rounded-lg focus:ring-2 focus:ring-primary-500 focus:border-primary-500 transition-colors duration-150 ease-out ${
                  errors.firstName ? 'border-error' : 'border-border'
                }`}
                placeholder="Enter first name"
              />
              {errors.firstName && <p className="mt-1 text-sm text-error">{errors.firstName}</p>}
            </div>

            <div>
              <label className="block text-sm font-medium text-text-primary mb-2">
                Last Name *
              </label>
              <input
                type="text"
                value={formData.lastName}
                onChange={(e) => handleInputChange('lastName', e.target.value)}
                className={`w-full px-4 py-3 border rounded-lg focus:ring-2 focus:ring-primary-500 focus:border-primary-500 transition-colors duration-150 ease-out ${
                  errors.lastName ? 'border-error' : 'border-border'
                }`}
                placeholder="Enter last name"
              />
              {errors.lastName && <p className="mt-1 text-sm text-error">{errors.lastName}</p>}
            </div>
          </div>

          <div>
            <label className="block text-sm font-medium text-text-primary mb-2">
              Email Address *
            </label>
            <input
              type="email"
              value={formData.email}
              onChange={(e) => handleInputChange('email', e.target.value)}
              className={`w-full px-4 py-3 border rounded-lg focus:ring-2 focus:ring-primary-500 focus:border-primary-500 transition-colors duration-150 ease-out ${
                errors.email ? 'border-error' : 'border-border'
              }`}
              placeholder="your.email@example.com"
            />
            {errors.email && <p className="mt-1 text-sm text-error">{errors.email}</p>}
          </div>

          <div>
            <label className="block text-sm font-medium text-text-primary mb-2">
              Phone Number *
            </label>
            <div className="relative">
              <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                <span className="text-text-secondary text-sm">+1-876</span>
              </div>
              <input
                type="tel"
                value={formData.phone}
                onChange={(e) => handleInputChange('phone', e.target.value)}
                className={`w-full pl-16 pr-4 py-3 border rounded-lg focus:ring-2 focus:ring-primary-500 focus:border-primary-500 transition-colors duration-150 ease-out ${
                  errors.phone ? 'border-error' : 'border-border'
                }`}
                placeholder="555-0123"
              />
            </div>
            {errors.phone && <p className="mt-1 text-sm text-error">{errors.phone}</p>}
          </div>

          <div>
            <label className="block text-sm font-medium text-text-primary mb-2">
              TRN (Tax Registration Number) *
            </label>
            <input
              type="text"
              value={formData.trn}
              onChange={(e) => handleInputChange('trn', e.target.value)}
              className={`w-full px-4 py-3 border rounded-lg focus:ring-2 focus:ring-primary-500 focus:border-primary-500 transition-colors duration-150 ease-out ${
                errors.trn ? 'border-error' : 'border-border'
              }`}
              placeholder="123456789"
              maxLength="9"
            />
            {errors.trn && <p className="mt-1 text-sm text-error">{errors.trn}</p>}
          </div>
        </div>
      )}

      {/* Step 2: Role & Location */}
      {step === 2 && (
        <div className="space-y-4">
          <div className="text-center mb-6">
            <h3 className="text-lg font-semibold text-text-primary">Role & Location</h3>
            <p className="text-sm text-text-secondary">Select your observer role and assignment location</p>
          </div>

          <div>
            <label className="block text-sm font-medium text-text-primary mb-3">
              Observer Role *
            </label>
            <div className="space-y-3">
              {roles.map((role) => (
                <button
                  key={role.value}
                  type="button"
                  onClick={() => handleInputChange('role', role.value)}
                  className={`w-full p-4 text-left border rounded-lg transition-colors duration-150 ease-out min-h-touch ${
                    formData.role === role.value
                      ? 'border-primary bg-primary-50 text-primary' :'border-border hover:bg-surface-secondary'
                  }`}
                >
                  <div className="font-medium">{role.label}</div>
                  <div className="text-sm text-text-secondary mt-1">{role.description}</div>
                </button>
              ))}
            </div>
            {errors.role && <p className="mt-1 text-sm text-error">{errors.role}</p>}
          </div>

          <div>
            <label className="block text-sm font-medium text-text-primary mb-2">
              Parish *
            </label>
            <select
              value={formData.parish}
              onChange={(e) => handleInputChange('parish', e.target.value)}
              className={`w-full px-4 py-3 border rounded-lg focus:ring-2 focus:ring-primary-500 focus:border-primary-500 transition-colors duration-150 ease-out ${
                errors.parish ? 'border-error' : 'border-border'
              }`}
            >
              <option value="">Select Parish</option>
              {parishes.map((parish) => (
                <option key={parish} value={parish}>{parish}</option>
              ))}
            </select>
            {errors.parish && <p className="mt-1 text-sm text-error">{errors.parish}</p>}
          </div>

          <div>
            <label className="block text-sm font-medium text-text-primary mb-2">
              Constituency *
            </label>
            <input
              type="text"
              value={formData.constituency}
              onChange={(e) => handleInputChange('constituency', e.target.value)}
              className={`w-full px-4 py-3 border rounded-lg focus:ring-2 focus:ring-primary-500 focus:border-primary-500 transition-colors duration-150 ease-out ${
                errors.constituency ? 'border-error' : 'border-border'
              }`}
              placeholder="Enter constituency name"
            />
            {errors.constituency && <p className="mt-1 text-sm text-error">{errors.constituency}</p>}
          </div>
        </div>
      )}

      {/* Step 3: Security & Confirmation */}
      {step === 3 && (
        <div className="space-y-4">
          <div className="text-center mb-6">
            <h3 className="text-lg font-semibold text-text-primary">Security & Confirmation</h3>
            <p className="text-sm text-text-secondary">Set up your account security and review details</p>
          </div>

          {/* Generated Observer ID */}
          <div className="p-4 bg-success-50 border border-success-200 rounded-lg">
            <div className="flex items-center space-x-2 mb-2">
              <Icon name="Shield" size={16} className="text-success" />
              <span className="text-sm font-medium text-success">Your Observer ID</span>
            </div>
            <div className="font-mono text-lg font-bold text-text-primary">{generatedObserverId}</div>
            <p className="text-xs text-text-secondary mt-1">
              This unique ID will be used for all your electoral observation activities
            </p>
          </div>

          <div>
            <label className="block text-sm font-medium text-text-primary mb-2">
              Password *
            </label>
            <div className="relative">
              <input
                type={showPassword ? 'text' : 'password'}
                value={formData.password}
                onChange={(e) => handleInputChange('password', e.target.value)}
                className={`w-full px-4 py-3 pr-12 border rounded-lg focus:ring-2 focus:ring-primary-500 focus:border-primary-500 transition-colors duration-150 ease-out ${
                  errors.password ? 'border-error' : 'border-border'
                }`}
                placeholder="Create a strong password"
              />
              <button
                type="button"
                onClick={() => setShowPassword(!showPassword)}
                className="absolute inset-y-0 right-0 pr-3 flex items-center"
              >
                <Icon
                  name={showPassword ? 'EyeOff' : 'Eye'}
                  size={20}
                  className="text-text-secondary hover:text-text-primary"
                />
              </button>
            </div>
            {errors.password && <p className="mt-1 text-sm text-error">{errors.password}</p>}
          </div>

          <div>
            <label className="block text-sm font-medium text-text-primary mb-2">
              Confirm Password *
            </label>
            <input
              type="password"
              value={formData.confirmPassword}
              onChange={(e) => handleInputChange('confirmPassword', e.target.value)}
              className={`w-full px-4 py-3 border rounded-lg focus:ring-2 focus:ring-primary-500 focus:border-primary-500 transition-colors duration-150 ease-out ${
                errors.confirmPassword ? 'border-error' : 'border-border'
              }`}
              placeholder="Confirm your password"
            />
            {errors.confirmPassword && <p className="mt-1 text-sm text-error">{errors.confirmPassword}</p>}
          </div>

          {/* Terms and Privacy */}
          <div className="space-y-3">
            <label className="flex items-start space-x-3">
              <input
                type="checkbox"
                checked={formData.agreeTerms}
                onChange={(e) => handleInputChange('agreeTerms', e.target.checked)}
                className="mt-1 w-4 h-4 text-primary border-border rounded focus:ring-primary-500"
              />
              <span className="text-sm text-text-primary">
                I agree to the <button type="button" className="text-primary hover:text-primary-700">Terms of Service</button> *
              </span>
            </label>
            {errors.agreeTerms && <p className="text-sm text-error">{errors.agreeTerms}</p>}

            <label className="flex items-start space-x-3">
              <input
                type="checkbox"
                checked={formData.agreePrivacy}
                onChange={(e) => handleInputChange('agreePrivacy', e.target.checked)}
                className="mt-1 w-4 h-4 text-primary border-border rounded focus:ring-primary-500"
              />
              <span className="text-sm text-text-primary">
                I agree to the <button type="button" className="text-primary hover:text-primary-700">Privacy Policy</button> *
              </span>
            </label>
            {errors.agreePrivacy && <p className="text-sm text-error">{errors.agreePrivacy}</p>}
          </div>
        </div>
      )}

      {/* Navigation Buttons */}
      <div className="flex space-x-4">
        {step > 1 && (
          <button
            type="button"
            onClick={handlePrevious}
            className="flex-1 flex items-center justify-center space-x-2 px-6 py-3 border border-border text-text-primary rounded-lg hover:bg-surface-secondary transition-colors duration-150 ease-out min-h-touch"
          >
            <Icon name="ChevronLeft" size={20} />
            <span className="font-medium">Previous</span>
          </button>
        )}

        {step < 3 ? (
          <button
            type="button"
            onClick={handleNext}
            className="flex-1 flex items-center justify-center space-x-2 px-6 py-3 bg-primary text-white rounded-lg hover:bg-primary-700 transition-colors duration-150 ease-out min-h-touch"
          >
            <span className="font-medium">Next</span>
            <Icon name="ChevronRight" size={20} />
          </button>
        ) : (
          <button
            type="submit"
            disabled={isLoading}
            className="flex-1 flex items-center justify-center space-x-2 px-6 py-3 bg-primary text-white rounded-lg hover:bg-primary-700 focus:ring-2 focus:ring-primary-500 focus:ring-offset-2 transition-colors duration-200 ease-in-out disabled:opacity-50 disabled:cursor-not-allowed min-h-touch"
          >
            {isLoading ? (
              <Icon name="RefreshCw" size={20} className="animate-spin" />
            ) : (
              <Icon name="UserPlus" size={20} />
            )}
            <span className="font-medium">Complete Registration</span>
          </button>
        )}
      </div>

      {/* Already have account */}
      <div className="text-center">
        <p className="text-sm text-text-secondary">
          Already have an account?{' '}
          <button
            type="button"
            onClick={onSwitchToLogin}
            className="text-primary hover:text-primary-700 font-medium transition-colors duration-150 ease-out"
          >
            Sign in here
          </button>
        </p>
      </div>
    </form>
  );
};

export default RegistrationForm;