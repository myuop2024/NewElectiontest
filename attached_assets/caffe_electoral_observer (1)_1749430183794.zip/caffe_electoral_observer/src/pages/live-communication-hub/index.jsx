// src/pages/live-communication-hub/index.jsx
import React, { useState, useEffect, useCallback } from 'react';
import { useSupabase } from '../../context/SupabaseContext';
import Header from 'components/ui/Header';
import Sidebar from 'components/ui/Sidebar';
import QuickActionPanel from 'components/ui/QuickActionPanel';
import StatusIndicator from 'components/ui/StatusIndicator';
import Icon from 'components/AppIcon';

import ChannelList from './components/ChannelList';
import ChatArea from './components/ChatArea';
import UserList from './components/UserList';
import EmergencyAlert from './components/EmergencyAlert';
import ConnectionStatus from './components/ConnectionStatus';
import VideoConference from './components/VideoConference';
import FileManager from './components/FileManager';
import ObserverStatusDashboard from './components/ObserverStatusDashboard';
import MediaPreview from './components/MediaPreview';
import KeyboardShortcuts from './components/KeyboardShortcuts';

const LiveCommunicationHub = () => {
  const { user, supabase } = useSupabase();
  const [channels, setChannels] = useState([]);
  const [activeChannel, setActiveChannel] = useState(null);
  const [messages, setMessages] = useState([]);
  const [onlineUsers, setOnlineUsers] = useState([]);
  const [loading, setLoading] = useState(true);
  const [connectionStatus, setConnectionStatus] = useState('connected');
  const [emergencyAlert, setEmergencyAlert] = useState(null);
  const [isMobileView, setIsMobileView] = useState(false);
  const [mobileActivePanel, setMobileActivePanel] = useState('channels');
  const [isVideoCallActive, setIsVideoCallActive] = useState(false);
  const [isMultiWindow, setIsMultiWindow] = useState(false);
  const [showFileManager, setShowFileManager] = useState(false);
  const [showObserverDashboard, setShowObserverDashboard] = useState(true);
  const [selectedMedia, setSelectedMedia] = useState(null);
  const [keyboardShortcutsVisible, setKeyboardShortcutsVisible] = useState(false);
  const [searchQuery, setSearchQuery] = useState('');
  const [activeConversations, setActiveConversations] = useState([]);
  const [splitScreenMode, setSplitScreenMode] = useState(false);

  // Mock data enhanced for desktop features
  const mockData = {
    channels: [
      {
        id: '1',
        name: 'General Discussion',
        description: 'General communication for all observers',
        type: 'general',
        unread_count: 3,
        last_message: {
          content: 'Everyone please check in for the morning briefing',
          created_at: new Date(Date.now() - 300000),
          user: { full_name: 'Sarah Johnson' }
        },
        participant_count: 15
      },
      {
        id: '2',
        name: 'Emergency Alerts',
        description: 'Emergency communications and alerts',
        type: 'emergency',
        unread_count: 0,
        last_message: {
          content: 'All systems operational',
          created_at: new Date(Date.now() - 3600000),
          user: { full_name: 'System' }
        },
        participant_count: 25
      },
      {
        id: '3',
        name: 'Kingston Parish Team',
        description: 'Communication for Kingston Parish observers',
        type: 'team',
        unread_count: 1,
        last_message: {
          content: 'Station PS-001-A reporting normal operations',
          created_at: new Date(Date.now() - 900000),
          user: { full_name: 'Michael Rodriguez' }
        },
        participant_count: 8
      },
      {
        id: '4',
        name: 'Training & Support',
        description: 'Training resources and technical support',
        type: 'general',
        unread_count: 0,
        last_message: {
          content: 'New training module available on document processing',
          created_at: new Date(Date.now() - 7200000),
          user: { full_name: 'Training Bot' }
        },
        participant_count: 12
      },
      {
        id: '5',
        name: 'Coordinator Conference',
        description: 'Real-time coordination and decision making',
        type: 'conference',
        unread_count: 2,
        last_message: {
          content: 'Video conference starting in 10 minutes',
          created_at: new Date(Date.now() - 600000),
          user: { full_name: 'Maria Santos' }
        },
        participant_count: 5,
        has_active_call: true
      }
    ],
    observerStatuses: [
      {
        id: 'obs1',
        name: 'Michael Rodriguez',
        station: 'PS-001-A',
        status: 'checked_in',
        last_checkin: new Date(Date.now() - 1800000),
        location: { lat: 18.0179, lng: -76.8099 },
        incident_count: 0,
        battery_level: 85
      },
      {
        id: 'obs2',
        name: 'Jessica Chen',
        station: 'PS-002-B',
        status: 'in_transit',
        last_checkin: new Date(Date.now() - 3600000),
        location: { lat: 18.0176, lng: -76.8102 },
        incident_count: 1,
        battery_level: 92
      },
      {
        id: 'obs3',
        name: 'David Thompson',
        station: 'PS-003-A',
        status: 'emergency',
        last_checkin: new Date(Date.now() - 900000),
        location: { lat: 18.0182, lng: -76.8095 },
        incident_count: 2,
        battery_level: 23
      }
    ]
  };

  // Keyboard shortcuts configuration
  const keyboardShortcuts = {
    'Ctrl+K': () => document.querySelector('input[placeholder="Search channels..."]')?.focus(),
    'Ctrl+1': () => setMobileActivePanel('channels'),
    'Ctrl+2': () => setMobileActivePanel('chat'),
    'Ctrl+3': () => setMobileActivePanel('users'),
    'Ctrl+Shift+E': () => setShowEmergencyDialog(true),
    'Ctrl+Shift+V': () => toggleVideoCall(),
    'Ctrl+Shift+F': () => setShowFileManager(true),
    'Ctrl+?': () => setKeyboardShortcutsVisible(true),
    'Escape': () => {
      setSelectedMedia(null);
      setKeyboardShortcutsVisible(false);
    }
  };

  // Setup keyboard shortcuts
  useEffect(() => {
    const handleKeyDown = (event) => {
      const key = `${event.ctrlKey ? 'Ctrl+' : ''}${event.shiftKey ? 'Shift+' : ''}${event.key}`;
      const shortcut = keyboardShortcuts[key];
      if (shortcut) {
        event.preventDefault();
        shortcut();
      }
    };

    document.addEventListener('keydown', handleKeyDown);
    return () => document.removeEventListener('keydown', handleKeyDown);
  }, []);

  // Check if running on mobile
  useEffect(() => {
    const checkMobile = () => {
      setIsMobileView(window.innerWidth < 1024);
    };
    
    checkMobile();
    window.addEventListener('resize', checkMobile);
    
    return () => window.removeEventListener('resize', checkMobile);
  }, []);

  // Initialize data
  useEffect(() => {
    if (supabase && user) {
      loadChannels();
      loadOnlineUsers();
      subscribeToUpdates();
    } else {
      // Use mock data
      setChannels(mockData.channels);
      setActiveChannel(mockData.channels[0]);
      setMessages(mockData.messages || []);
      setOnlineUsers(mockData.onlineUsers || []);
      setLoading(false);
    }
  }, [user, supabase]);

  // Load channels from Supabase
  const loadChannels = async () => {
    try {
      const { data, error } = await supabase
        .from('channels')
        .select(`
          *,
          channel_members!inner (
            user_id,
            role
          ),
          messages (
            id,
            content,
            created_at,
            user:user_profiles (full_name)
          )
        `)
        .eq('channel_members.user_id', user?.id)
        .order('created_at', { ascending: false });

      if (error) throw error;

      const channelsWithMeta = data?.map(channel => ({
        ...channel,
        unread_count: 0,
        last_message: channel.messages?.[0] || null,
        participant_count: channel.channel_members?.length || 0
      })) || [];

      setChannels(channelsWithMeta);
      if (channelsWithMeta.length > 0) {
        setActiveChannel(channelsWithMeta[0]);
      }
    } catch (error) {
      console.error('Error loading channels:', error);
      setChannels(mockData.channels);
      setActiveChannel(mockData.channels[0]);
    }
  };

  // Load online users
  const loadOnlineUsers = async () => {
    try {
      const { data, error } = await supabase
        .from('user_profiles')
        .select('*')
        .order('is_online', { ascending: false });

      if (error) throw error;
      setOnlineUsers(data || []);
    } catch (error) {
      console.error('Error loading users:', error);
      setOnlineUsers(mockData.onlineUsers || []);
    }
  };

  // Load messages for active channel
  const loadMessages = async (channelId) => {
    if (!channelId || !supabase) {
      setMessages(mockData.messages || []);
      return;
    }

    try {
      // Validate UUID format before making the request
      const uuidRegex = /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i;
      if (!uuidRegex.test(channelId)) {
        console.error('Invalid UUID format for channel ID:', channelId);
        setMessages(mockData.messages || []);
        return;
      }
      
      // Use the stored function to get messages with user info instead of a direct join
      const { data, error } = await supabase
        .rpc('get_messages_with_user_info', { channel_uuid: channelId });

      if (error) throw error;
      setMessages(data || []);
    } catch (error) {
      console.error('Error loading messages:', error);
      setMessages(mockData.messages || []);
    }
  };

  // Subscribe to real-time updates
  const subscribeToUpdates = () => {
    if (!supabase) return;

    const messagesSubscription = supabase
      .channel('messages')
      .on(
        'postgres_changes',
        {
          event: 'INSERT',
          schema: 'public',
          table: 'messages'
        },
        (payload) => {
          if (payload.new.channel_id === activeChannel?.id) {
            setMessages(prev => [...prev, payload.new]);
          }
        }
      )
      .subscribe();

    const usersSubscription = supabase
      .channel('user_profiles')
      .on(
        'postgres_changes',
        {
          event: 'UPDATE',
          schema: 'public',
          table: 'user_profiles'
        },
        (payload) => {
          setOnlineUsers(prev => 
            prev.map(user => 
              user.id === payload.new.id ? payload.new : user
            )
          );
        }
      )
      .subscribe();

    return () => {
      messagesSubscription.unsubscribe();
      usersSubscription.unsubscribe();
    };
  };

  // Handle channel selection
  const handleChannelSelect = (channel) => {
    setActiveChannel(channel);
    
    // Check if the channel ID is a valid UUID before loading messages
    const uuidRegex = /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i;
    if (channel?.id && uuidRegex.test(channel.id)) {
      loadMessages(channel.id);
    } else if (supabase) {
      console.warn('Invalid UUID format for channel ID. Using mock data.', channel?.id);
      setMessages(mockData.messages || []);
    } else {
      setMessages(mockData.messages || []);
    }
    
    if (isMobileView) {
      setMobileActivePanel('chat');
    }
  };

  // Send message with file support
  const sendMessage = async (content, type = 'text', attachments = []) => {
    if (!content.trim() && attachments.length === 0) return;

    if (supabase && user && activeChannel) {
      try {
        const { error } = await supabase
          .from('messages')
          .insert({
            channel_id: activeChannel.id,
            user_id: user.id,
            content: content.trim(),
            message_type: type,
            attachments: attachments
          });

        if (error) throw error;
      } catch (error) {
        console.error('Error sending message:', error);
        const newMessage = {
          id: Date.now().toString(),
          content: content.trim(),
          user_id: 'current_user',
          created_at: new Date(),
          user: {
            full_name: 'You',
            role: 'observer',
            avatar_url: 'https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?w=32&h=32&fit=crop&crop=face'
          },
          message_type: type,
          attachments: attachments
        };
        setMessages(prev => [...prev, newMessage]);
      }
    } else {
      const newMessage = {
        id: Date.now().toString(),
        content: content.trim(),
        user_id: 'current_user',
        created_at: new Date(),
        user: {
          full_name: 'You',
          role: 'observer',
          avatar_url: 'https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?w=32&h=32&fit=crop&crop=face'
        },
        message_type: type,
        attachments: attachments
      };
      setMessages(prev => [...prev, newMessage]);
    }
  };

  // Video call functions
  const toggleVideoCall = () => {
    setIsVideoCallActive(!isVideoCallActive);
  };

  const handleEmergencyBroadcast = (message) => {
    setEmergencyAlert({
      id: Date.now(),
      title: 'Emergency Broadcast',
      message,
      severity: 'critical',
      timestamp: new Date(),
      actions: [
        {
          label: 'Acknowledge',
          icon: 'Check',
          onClick: () => setEmergencyAlert(null)
        },
        {
          label: 'Respond',
          icon: 'MessageSquare',
          onClick: () => {
            setMobileActivePanel('chat');
            setEmergencyAlert(null);
          }
        }
      ]
    });
  };

  // Multi-window support for coordinators
  const openInNewWindow = (content) => {
    if (!isMultiWindow) return;
    
    const newWindow = window.open('', '_blank', 'width=800,height=600');
    newWindow.document.write(`
      <html>
        <head><title>CAFFE - ${content.title}</title></head>
        <body>${content.html}</body>
      </html>
    `);
  };

  useEffect(() => {
    if (activeChannel) {
      loadMessages(activeChannel.id);
    }
  }, [activeChannel]);

  useEffect(() => {
    setLoading(false);
  }, []);

  if (loading) {
    return (
      <div className="min-h-screen bg-background flex items-center justify-center">
        <div className="text-center">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-primary mx-auto mb-4"></div>
          <p className="text-text-secondary">Loading communication hub...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-background">
      <Header />
      <Sidebar />
      <QuickActionPanel />
      <StatusIndicator />

      {/* Emergency Alert */}
      {emergencyAlert && (
        <EmergencyAlert
          alert={emergencyAlert}
          onDismiss={() => setEmergencyAlert(null)}
        />
      )}

      {/* Keyboard Shortcuts Help */}
      {keyboardShortcutsVisible && (
        <KeyboardShortcuts
          shortcuts={keyboardShortcuts}
          onClose={() => setKeyboardShortcutsVisible(false)}
        />
      )}

      {/* Media Preview Modal */}
      {selectedMedia && (
        <MediaPreview
          media={selectedMedia}
          onClose={() => setSelectedMedia(null)}
        />
      )}

      {/* Video Conference Window */}
      {isVideoCallActive && (
        <VideoConference
          channel={activeChannel}
          participants={onlineUsers}
          onClose={() => setIsVideoCallActive(false)}
          splitScreen={splitScreenMode}
          onToggleSplitScreen={() => setSplitScreenMode(!splitScreenMode)}
        />
      )}

      {/* File Manager */}
      {showFileManager && (
        <FileManager
          onClose={() => setShowFileManager(false)}
          onFileSelect={(file) => {
            sendMessage('', 'file', [file]);
            setShowFileManager(false);
          }}
        />
      )}

      {/* Main Content */}
      <main className="lg:ml-64 pt-16 pb-20 lg:pb-6">
        <div className="h-[calc(100vh-4rem)] lg:h-[calc(100vh-1.5rem)] flex flex-col">
          {/* Desktop Controls Bar */}
          {!isMobileView && (
            <div className="flex items-center justify-between px-6 py-3 bg-surface border-b border-border">
              <div className="flex items-center space-x-4">
                <h1 className="text-xl font-semibold text-text-primary">Communication Hub</h1>
                <ConnectionStatus status={connectionStatus} />
                <div className="flex items-center space-x-2 text-sm text-text-secondary">
                  <Icon name="Users" size={16} />
                  <span>{onlineUsers.filter(u => u.is_online).length} online</span>
                </div>
              </div>
              
              <div className="flex items-center space-x-2">
                <button
                  onClick={() => setShowFileManager(true)}
                  className="flex items-center space-x-2 px-3 py-2 text-sm bg-primary-50 text-primary hover:bg-primary-100 rounded-lg transition-colors"
                  title="File Manager (Ctrl+Shift+F)"
                >
                  <Icon name="FolderOpen" size={16} />
                  <span>Files</span>
                </button>
                
                <button
                  onClick={toggleVideoCall}
                  className={`flex items-center space-x-2 px-3 py-2 text-sm rounded-lg transition-colors ${
                    isVideoCallActive 
                      ? 'bg-success text-white hover:bg-success-600' :'bg-surface border border-border text-text-primary hover:bg-surface-secondary'
                  }`}
                  title="Video Conference (Ctrl+Shift+V)"
                >
                  <Icon name={isVideoCallActive ? "VideoOff" : "Video"} size={16} />
                  <span>{isVideoCallActive ? 'End Call' : 'Start Call'}</span>
                </button>
                
                <button
                  onClick={() => setIsMultiWindow(!isMultiWindow)}
                  className={`flex items-center space-x-2 px-3 py-2 text-sm rounded-lg transition-colors ${
                    isMultiWindow 
                      ? 'bg-secondary text-white hover:bg-secondary-600' :'bg-surface border border-border text-text-primary hover:bg-surface-secondary'
                  }`}
                  title="Multi-Window Mode"
                >
                  <Icon name="ExternalLink" size={16} />
                  <span>Multi-Window</span>
                </button>
                
                <button
                  onClick={() => setKeyboardShortcutsVisible(true)}
                  className="flex items-center space-x-2 px-3 py-2 text-sm bg-surface border border-border text-text-primary hover:bg-surface-secondary rounded-lg transition-colors"
                  title="Keyboard Shortcuts (Ctrl+?)"
                >
                  <Icon name="Keyboard" size={16} />
                </button>
              </div>
            </div>
          )}

          {/* Mobile Navigation */}
          {isMobileView && (
            <div className="flex bg-surface border-b border-border">
              <button
                onClick={() => setMobileActivePanel('channels')}
                className={`flex-1 py-3 px-4 text-sm font-medium ${
                  mobileActivePanel === 'channels' ?'text-primary border-b-2 border-primary bg-primary-50' :'text-text-secondary'
                }`}
              >
                <Icon name="Hash" size={16} className="inline mr-2" />
                Channels
              </button>
              <button
                onClick={() => setMobileActivePanel('chat')}
                className={`flex-1 py-3 px-4 text-sm font-medium ${
                  mobileActivePanel === 'chat' ?'text-primary border-b-2 border-primary bg-primary-50' :'text-text-secondary'
                }`}
              >
                <Icon name="MessageSquare" size={16} className="inline mr-2" />
                Chat
              </button>
              <button
                onClick={() => setMobileActivePanel('users')}
                className={`flex-1 py-3 px-4 text-sm font-medium ${
                  mobileActivePanel === 'users' ?'text-primary border-b-2 border-primary bg-primary-50' :'text-text-secondary'
                }`}
              >
                <Icon name="Users" size={16} className="inline mr-2" />
                Users
              </button>
              {showObserverDashboard && (
                <button
                  onClick={() => setMobileActivePanel('dashboard')}
                  className={`flex-1 py-3 px-4 text-sm font-medium ${
                    mobileActivePanel === 'dashboard' ?'text-primary border-b-2 border-primary bg-primary-50' :'text-text-secondary'
                  }`}
                >
                  <Icon name="Activity" size={16} className="inline mr-2" />
                  Status
                </button>
              )}
            </div>
          )}

          {/* Main Chat Interface */}
          <div className="flex-1 flex overflow-hidden">
            {/* Channel List */}
            <div className={`${
              isMobileView
                ? (mobileActivePanel === 'channels' ? 'flex' : 'hidden')
                : 'flex'
            } w-full lg:w-80 flex-col border-r border-border bg-surface`}>
              <div className="p-4 border-b border-border">
                <div className="relative mb-4">
                  <Icon name="Search" size={16} className="absolute left-3 top-3 text-text-secondary" />
                  <input
                    type="text"
                    placeholder="Search channels... (Ctrl+K)"
                    value={searchQuery}
                    onChange={(e) => setSearchQuery(e.target.value)}
                    className="w-full pl-10 pr-4 py-2 text-sm border border-border rounded-lg bg-background focus:outline-none focus:ring-2 focus:ring-primary focus:border-transparent"
                  />
                </div>
              </div>
              <ChannelList
                channels={channels.filter(ch => 
                  ch.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
                  ch.description?.toLowerCase().includes(searchQuery.toLowerCase())
                )}
                activeChannel={activeChannel}
                onChannelSelect={handleChannelSelect}
                searchQuery={searchQuery}
              />
            </div>

            {/* Chat Area */}
            <div className={`${
              isMobileView
                ? (mobileActivePanel === 'chat' ? 'flex' : 'hidden')
                : 'flex'
            } flex-1 flex-col bg-background ${splitScreenMode ? 'lg:w-1/2' : ''}`}>
              {activeChannel ? (
                <ChatArea
                  channel={activeChannel}
                  messages={messages}
                  onSendMessage={sendMessage}
                  currentUser={user}
                  onMediaSelect={setSelectedMedia}
                  onStartVideoCall={toggleVideoCall}
                  isVideoCallActive={isVideoCallActive}
                  multiWindowMode={isMultiWindow}
                  onOpenInNewWindow={openInNewWindow}
                />
              ) : (
                <div className="flex-1 flex items-center justify-center text-text-secondary">
                  <div className="text-center">
                    <Icon name="MessageSquare" size={48} className="mx-auto mb-4 opacity-50" />
                    <p className="text-lg mb-2">Welcome to Communication Hub</p>
                    <p className="text-sm">Select a channel to start chatting</p>
                    <div className="mt-4 text-xs text-text-tertiary">
                      Press <kbd className="px-2 py-1 bg-surface border border-border rounded">Ctrl+?</kbd> for keyboard shortcuts
                    </div>
                  </div>
                </div>
              )}
            </div>

            {/* User List / Observer Dashboard */}
            <div className={`${
              isMobileView
                ? (mobileActivePanel === 'users' || mobileActivePanel === 'dashboard' ? 'flex' : 'hidden')
                : 'flex'
            } w-full lg:w-80 flex-col border-l border-border bg-surface ${splitScreenMode ? 'lg:w-1/2' : ''}`}>
              {(!isMobileView || mobileActivePanel === 'users') && (
                <UserList 
                  users={onlineUsers} 
                  onDirectMessage={(user) => {
                    // Create or switch to direct message channel
                    console.log('Direct message to:', user);
                  }}
                  onVoiceCall={(user) => {
                    console.log('Voice call to:', user);
                  }}
                />
              )}
              
              {showObserverDashboard && ((!isMobileView && mobileActivePanel !== 'dashboard') || mobileActivePanel === 'dashboard') && (
                <ObserverStatusDashboard
                  observers={mockData.observerStatuses}
                  onEmergencyBroadcast={handleEmergencyBroadcast}
                  onObserverSelect={(observer) => {
                    console.log('Selected observer:', observer);
                  }}
                />
              )}
            </div>
          </div>
        </div>
      </main>
    </div>
  );
};

export default LiveCommunicationHub;