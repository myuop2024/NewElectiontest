// src/pages/live-communication-hub/components/KeyboardShortcuts.jsx
import React from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import Icon from 'components/AppIcon';
import Button from 'components/ui/Button';

const KeyboardShortcuts = ({ shortcuts, onClose }) => {
  const shortcutCategories = {
    'Navigation': [
      { key: 'Ctrl+1', description: 'Switch to Channels panel' },
      { key: 'Ctrl+2', description: 'Switch to Chat panel' },
      { key: 'Ctrl+3', description: 'Switch to Users panel' },
      { key: 'Ctrl+K', description: 'Focus search input' },
    ],
    'Communication': [
      { key: 'Ctrl+Shift+V', description: 'Start/Stop video call' },
      { key: 'Ctrl+Shift+E', description: 'Emergency contact' },
      { key: 'Enter', description: 'Send message' },
      { key: 'Shift+Enter', description: 'New line in message' },
    ],
    'File Management': [
      { key: 'Ctrl+Shift+F', description: 'Open file manager' },
      { key: 'Ctrl+U', description: 'Upload files' },
      { key: 'Ctrl+D', description: 'Download selected file' },
    ],
    'General': [
      { key: 'Escape', description: 'Close dialogs/cancel actions' },
      { key: 'Ctrl+?', description: 'Show keyboard shortcuts' },
      { key: 'F11', description: 'Toggle fullscreen' },
      { key: 'F5', description: 'Refresh/Reload' },
    ],
    'Media & Preview': [
      { key: 'Space', description: 'Play/Pause media' },
      { key: 'F', description: 'Toggle fullscreen (in media)' },
      { key: '+/-', description: 'Zoom in/out (images)' },
      { key: '0', description: 'Reset zoom (images)' },
    ],
    'Advanced': [
      { key: 'Ctrl+Shift+M', description: 'Toggle multi-window mode' },
      { key: 'Ctrl+Shift+S', description: 'Split screen mode' },
      { key: 'Ctrl+Shift+R', description: 'Start/Stop recording' },
      { key: 'Ctrl+B', description: 'Toggle sidebar' },
    ]
  };

  return (
    <AnimatePresence>
      <motion.div
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        exit={{ opacity: 0 }}
        className="fixed inset-0 z-50 bg-black bg-opacity-50 flex items-center justify-center p-4"
        onClick={(e) => e.target === e.currentTarget && onClose()}
      >
        <motion.div
          initial={{ scale: 0.9, opacity: 0 }}
          animate={{ scale: 1, opacity: 1 }}
          exit={{ scale: 0.9, opacity: 0 }}
          className="bg-surface rounded-lg shadow-xl w-full max-w-4xl max-h-[80vh] overflow-hidden"
        >
          {/* Header */}
          <div className="flex items-center justify-between p-6 border-b border-border">
            <div className="flex items-center space-x-3">
              <Icon name="Keyboard" size={24} className="text-primary" />
              <h2 className="text-xl font-semibold text-text-primary">Keyboard Shortcuts</h2>
            </div>
            <Button
              variant="ghost"
              size="sm"
              onClick={onClose}
              className="text-text-secondary hover:text-text-primary"
            >
              <Icon name="X" size={20} />
            </Button>
          </div>

          {/* Content */}
          <div className="p-6 overflow-y-auto max-h-[calc(80vh-80px)]">
            <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-3">
              {Object.entries(shortcutCategories).map(([category, shortcuts]) => (
                <div key={category} className="space-y-3">
                  <h3 className="text-lg font-medium text-text-primary border-b border-border pb-2">
                    {category}
                  </h3>
                  <div className="space-y-2">
                    {shortcuts.map((shortcut, index) => (
                      <div
                        key={index}
                        className="flex items-center justify-between p-2 rounded-lg hover:bg-surface-secondary transition-colors"
                      >
                        <span className="text-sm text-text-secondary flex-1">
                          {shortcut.description}
                        </span>
                        <div className="ml-3">
                          {shortcut.key.split('+').map((key, keyIndex) => (
                            <React.Fragment key={keyIndex}>
                              {keyIndex > 0 && (
                                <span className="mx-1 text-text-tertiary">+</span>
                              )}
                              <kbd className="inline-flex items-center px-2 py-1 text-xs font-medium bg-background border border-border rounded text-text-primary">
                                {key}
                              </kbd>
                            </React.Fragment>
                          ))}
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              ))}
            </div>

            {/* Additional Tips */}
            <div className="mt-8 p-4 bg-primary-50 border border-primary-200 rounded-lg">
              <div className="flex items-start space-x-3">
                <Icon name="Lightbulb" size={20} className="text-primary mt-0.5" />
                <div>
                  <h4 className="text-sm font-medium text-primary mb-2">Pro Tips</h4>
                  <ul className="text-sm text-primary-700 space-y-1">
                    <li>• Use Tab to navigate between interface elements</li>
                    <li>• Hold Shift while clicking to select multiple items</li>
                    <li>• Right-click for context menus with additional options</li>
                    <li>• Most shortcuts work globally throughout the application</li>
                    <li>• Customize shortcuts in Settings &gt; Keyboard</li>
                  </ul>
                </div>
              </div>
            </div>

            {/* Accessibility Note */}
            <div className="mt-4 p-4 bg-surface-secondary border border-border rounded-lg">
              <div className="flex items-start space-x-3">
                <Icon name="Accessibility" size={20} className="text-text-secondary mt-0.5" />
                <div>
                  <h4 className="text-sm font-medium text-text-primary mb-2">Accessibility</h4>
                  <p className="text-sm text-text-secondary">
                    All features are accessible via keyboard navigation. Use Tab to move forward, 
                    Shift+Tab to move backward, and Enter or Space to activate controls.
                  </p>
                </div>
              </div>
            </div>
          </div>

          {/* Footer */}
          <div className="flex items-center justify-between p-6 border-t border-border bg-surface-secondary">
            <div className="text-sm text-text-secondary">
              Press <kbd className="px-2 py-1 bg-background border border-border rounded text-text-primary">Esc</kbd> or 
              <kbd className="px-2 py-1 bg-background border border-border rounded text-text-primary ml-1">Ctrl+?</kbd> to close this dialog
            </div>
            <div className="flex items-center space-x-3">
              <Button
                variant="ghost"
                size="sm"
                onClick={() => window.print()}
                className="text-text-secondary hover:text-text-primary"
              >
                <Icon name="Printer" size={16} className="mr-2" />
                Print
              </Button>
              <Button
                onClick={onClose}
                className="bg-primary text-white hover:bg-primary-700"
              >
                Got it
              </Button>
            </div>
          </div>
        </motion.div>
      </motion.div>
    </AnimatePresence>
  );
};

export default KeyboardShortcuts;