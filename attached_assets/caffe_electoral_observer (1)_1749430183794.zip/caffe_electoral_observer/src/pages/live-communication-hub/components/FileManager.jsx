// src/pages/live-communication-hub/components/FileManager.jsx
import React, { useState, useRef, useCallback } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { formatDistanceToNow } from 'date-fns';
import Icon from 'components/AppIcon';
import Button from 'components/ui/Button';

const FileManager = ({ onClose, onFileSelect }) => {
  const [activeTab, setActiveTab] = useState('upload'); // 'upload', 'recent', 'shared'
  const [dragActive, setDragActive] = useState(false);
  const [uploadProgress, setUploadProgress] = useState({});
  const [files, setFiles] = useState([]);
  const [selectedFiles, setSelectedFiles] = useState([]);
  const [searchQuery, setSearchQuery] = useState('');
  const fileInputRef = useRef(null);
  const dropRef = useRef(null);

  // Mock recent files data
  const mockRecentFiles = [
    {
      id: '1',
      name: 'Observer_Report_PS001.pdf',
      type: 'pdf',
      size: 2456789,
      uploaded_at: new Date(Date.now() - 3600000),
      uploaded_by: 'Michael Rodriguez',
      channel: 'Kingston Parish Team',
      thumbnail: null
    },
    {
      id: '2',
      name: 'Station_Photo_001.jpg',
      type: 'image',
      size: 1024567,
      uploaded_at: new Date(Date.now() - 7200000),
      uploaded_by: 'Jessica Chen',
      channel: 'General Discussion',
      thumbnail: 'https://images.unsplash.com/photo-1586479766346-3a423342b3cd?w=100&h=100&fit=crop'
    },
    {
      id: '3',
      name: 'Training_Manual_V2.docx',
      type: 'document',
      size: 3456789,
      uploaded_at: new Date(Date.now() - 86400000),
      uploaded_by: 'Training Bot',
      channel: 'Training & Support',
      thumbnail: null
    },
    {
      id: '4',
      name: 'Emergency_Contacts.xlsx',
      type: 'spreadsheet',
      size: 567890,
      uploaded_at: new Date(Date.now() - 172800000),
      uploaded_by: 'Sarah Johnson',
      channel: 'Emergency Alerts',
      thumbnail: null
    }
  ];

  const [recentFiles] = useState(mockRecentFiles);

  // Handle drag events
  const handleDrag = useCallback((e) => {
    e.preventDefault();
    e.stopPropagation();
    if (e.type === "dragenter" || e.type === "dragover") {
      setDragActive(true);
    } else if (e.type === "dragleave") {
      setDragActive(false);
    }
  }, []);

  const handleDrop = useCallback((e) => {
    e.preventDefault();
    e.stopPropagation();
    setDragActive(false);

    if (e.dataTransfer.files && e.dataTransfer.files[0]) {
      handleFiles(Array.from(e.dataTransfer.files));
    }
  }, []);

  const handleFileInput = (e) => {
    if (e.target.files) {
      handleFiles(Array.from(e.target.files));
    }
  };

  const handleFiles = (fileList) => {
    const validFiles = fileList.filter(file => {
      // Validate file types and sizes
      const maxSize = 10 * 1024 * 1024; // 10MB
      const allowedTypes = [
        'image/jpeg', 'image/png', 'image/gif', 'image/webp',
        'application/pdf',
        'application/msword', 'application/vnd.openxmlformats-officedocument.wordprocessingml.document',
        'application/vnd.ms-excel', 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
        'text/plain', 'text/csv',
        'video/mp4', 'video/webm',
        'audio/mp3', 'audio/wav'
      ];
      
      return file.size <= maxSize && allowedTypes.includes(file.type);
    });

    setFiles(prev => [...prev, ...validFiles.map(file => ({
      id: Date.now() + Math.random(),
      file,
      name: file.name,
      type: getFileType(file.type),
      size: file.size,
      status: 'pending' // 'pending', 'uploading', 'completed', 'error'
    }))]);

    // Start upload simulation
    validFiles.forEach(file => {
      uploadFile(file);
    });
  };

  const uploadFile = (file) => {
    const fileId = Date.now() + Math.random();
    setUploadProgress(prev => ({ ...prev, [fileId]: 0 }));

    // Simulate upload progress
    const interval = setInterval(() => {
      setUploadProgress(prev => {
        const current = prev[fileId] || 0;
        const next = current + Math.random() * 30;
        
        if (next >= 100) {
          clearInterval(interval);
          setFiles(prevFiles => 
            prevFiles.map(f => 
              f.file === file ? { ...f, status: 'completed' } : f
            )
          );
          return { ...prev, [fileId]: 100 };
        }
        
        return { ...prev, [fileId]: next };
      });
    }, 500);
  };

  const getFileType = (mimeType) => {
    if (mimeType.startsWith('image/')) return 'image';
    if (mimeType.startsWith('video/')) return 'video';
    if (mimeType.startsWith('audio/')) return 'audio';
    if (mimeType.includes('pdf')) return 'pdf';
    if (mimeType.includes('word') || mimeType.includes('document')) return 'document';
    if (mimeType.includes('excel') || mimeType.includes('spreadsheet')) return 'spreadsheet';
    return 'file';
  };

  const getFileIcon = (type) => {
    switch (type) {
      case 'image': return 'Image';
      case 'video': return 'Video';
      case 'audio': return 'Music';
      case 'pdf': return 'FileText';
      case 'document': return 'FileText';
      case 'spreadsheet': return 'Grid3X3';
      default: return 'File';
    }
  };

  const formatFileSize = (bytes) => {
    if (bytes === 0) return '0 Bytes';
    const k = 1024;
    const sizes = ['Bytes', 'KB', 'MB', 'GB'];
    const i = Math.floor(Math.log(bytes) / Math.log(k));
    return parseFloat((bytes / Math.pow(k, i)).toFixed(2)) + ' ' + sizes[i];
  };

  const handleFileSelect = (file) => {
    onFileSelect(file);
  };

  const filteredRecentFiles = recentFiles.filter(file =>
    file.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
    file.uploaded_by.toLowerCase().includes(searchQuery.toLowerCase())
  );

  const removeFile = (fileId) => {
    setFiles(prev => prev.filter(f => f.id !== fileId));
  };

  const toggleFileSelection = (fileId) => {
    setSelectedFiles(prev => 
      prev.includes(fileId) 
        ? prev.filter(id => id !== fileId)
        : [...prev, fileId]
    );
  };

  return (
    <AnimatePresence>
      <motion.div
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        exit={{ opacity: 0 }}
        className="fixed inset-0 z-50 bg-black bg-opacity-50 flex items-center justify-center p-4"
        onClick={(e) => e.target === e.currentTarget && onClose()}
      >
        <motion.div
          initial={{ scale: 0.9, opacity: 0 }}
          animate={{ scale: 1, opacity: 1 }}
          exit={{ scale: 0.9, opacity: 0 }}
          className="bg-surface rounded-lg shadow-xl w-full max-w-4xl h-[80vh] flex flex-col"
        >
          {/* Header */}
          <div className="flex items-center justify-between p-6 border-b border-border">
            <h2 className="text-xl font-semibold text-text-primary">File Manager</h2>
            <Button
              variant="ghost"
              size="sm"
              onClick={onClose}
              className="text-text-secondary hover:text-text-primary"
            >
              <Icon name="X" size={20} />
            </Button>
          </div>

          {/* Tabs */}
          <div className="flex border-b border-border">
            {[
              { key: 'upload', label: 'Upload', icon: 'Upload' },
              { key: 'recent', label: 'Recent Files', icon: 'Clock' },
              { key: 'shared', label: 'Shared with Me', icon: 'Share2' }
            ].map(tab => (
              <button
                key={tab.key}
                onClick={() => setActiveTab(tab.key)}
                className={`flex items-center space-x-2 px-6 py-3 text-sm font-medium border-b-2 transition-colors ${
                  activeTab === tab.key
                    ? 'border-primary text-primary bg-primary-50' :'border-transparent text-text-secondary hover:text-text-primary hover:bg-surface-secondary'
                }`}
              >
                <Icon name={tab.icon} size={16} />
                <span>{tab.label}</span>
              </button>
            ))}
          </div>

          {/* Content */}
          <div className="flex-1 overflow-hidden">
            {/* Upload Tab */}
            {activeTab === 'upload' && (
              <div className="h-full p-6">
                {/* Drop Zone */}
                <div
                  ref={dropRef}
                  onDragEnter={handleDrag}
                  onDragLeave={handleDrag}
                  onDragOver={handleDrag}
                  onDrop={handleDrop}
                  onClick={() => fileInputRef.current?.click()}
                  className={`border-2 border-dashed rounded-lg p-8 text-center cursor-pointer transition-colors ${
                    dragActive
                      ? 'border-primary bg-primary-50 text-primary' :'border-border hover:border-primary hover:bg-surface-secondary text-text-secondary'
                  }`}
                >
                  <Icon name="Upload" size={48} className="mx-auto mb-4 opacity-50" />
                  <p className="text-lg font-medium mb-2">
                    {dragActive ? 'Drop files here' : 'Drag and drop files here'}
                  </p>
                  <p className="text-sm mb-4">or click to browse</p>
                  <div className="text-xs text-text-tertiary">
                    Supports: Images, PDFs, Documents, Spreadsheets, Videos, Audio (Max 10MB)
                  </div>
                </div>

                <input
                  ref={fileInputRef}
                  type="file"
                  multiple
                  onChange={handleFileInput}
                  className="hidden"
                  accept="image/*,application/pdf,.doc,.docx,.xls,.xlsx,.txt,.csv,video/*,audio/*"
                />

                {/* Upload Queue */}
                {files.length > 0 && (
                  <div className="mt-6">
                    <h3 className="text-lg font-medium text-text-primary mb-4">Upload Queue</h3>
                    <div className="space-y-3 max-h-60 overflow-y-auto">
                      {files.map(file => (
                        <div key={file.id} className="flex items-center space-x-3 p-3 bg-surface-secondary rounded-lg">
                          <Icon name={getFileIcon(file.type)} size={20} className="text-primary" />
                          <div className="flex-1 min-w-0">
                            <p className="text-sm font-medium text-text-primary truncate">
                              {file.name}
                            </p>
                            <p className="text-xs text-text-secondary">
                              {formatFileSize(file.size)}
                            </p>
                            {file.status === 'uploading' && (
                              <div className="mt-1 w-full bg-border rounded-full h-1">
                                <div
                                  className="bg-primary h-1 rounded-full transition-all duration-300"
                                  style={{ width: `${uploadProgress[file.id] || 0}%` }}
                                ></div>
                              </div>
                            )}
                          </div>
                          <div className="flex items-center space-x-2">
                            {file.status === 'completed' && (
                              <Icon name="Check" size={16} className="text-success" />
                            )}
                            {file.status === 'error' && (
                              <Icon name="AlertCircle" size={16} className="text-error" />
                            )}
                            <Button
                              variant="ghost"
                              size="sm"
                              onClick={() => removeFile(file.id)}
                              className="text-text-secondary hover:text-error"
                            >
                              <Icon name="Trash2" size={14} />
                            </Button>
                          </div>
                        </div>
                      ))}
                    </div>
                  </div>
                )}
              </div>
            )}

            {/* Recent Files Tab */}
            {activeTab === 'recent' && (
              <div className="h-full flex flex-col">
                {/* Search */}
                <div className="p-6 border-b border-border">
                  <div className="relative">
                    <Icon name="Search" size={16} className="absolute left-3 top-3 text-text-secondary" />
                    <input
                      type="text"
                      placeholder="Search files..."
                      value={searchQuery}
                      onChange={(e) => setSearchQuery(e.target.value)}
                      className="w-full pl-10 pr-4 py-2 text-sm border border-border rounded-lg bg-background focus:outline-none focus:ring-2 focus:ring-primary focus:border-transparent"
                    />
                  </div>
                </div>

                {/* File List */}
                <div className="flex-1 overflow-y-auto p-6">
                  <div className="grid gap-4">
                    {filteredRecentFiles.map(file => (
                      <div
                        key={file.id}
                        className="flex items-center space-x-4 p-4 border border-border rounded-lg hover:bg-surface-secondary cursor-pointer transition-colors"
                        onClick={() => handleFileSelect(file)}
                      >
                        {/* Thumbnail/Icon */}
                        <div className="flex-shrink-0">
                          {file.thumbnail ? (
                            <img
                              src={file.thumbnail}
                              alt={file.name}
                              className="w-12 h-12 object-cover rounded"
                            />
                          ) : (
                            <div className="w-12 h-12 bg-primary-100 rounded flex items-center justify-center">
                              <Icon name={getFileIcon(file.type)} size={24} className="text-primary" />
                            </div>
                          )}
                        </div>

                        {/* File Info */}
                        <div className="flex-1 min-w-0">
                          <h4 className="text-sm font-medium text-text-primary truncate">
                            {file.name}
                          </h4>
                          <div className="flex items-center space-x-4 text-xs text-text-secondary mt-1">
                            <span>Uploaded by {file.uploaded_by}</span>
                            <span>{formatFileSize(file.size)}</span>
                            <span>{formatDistanceToNow(file.uploaded_at)} ago</span>
                          </div>
                          <div className="text-xs text-text-tertiary mt-1">
                            Shared in {file.channel}
                          </div>
                        </div>

                        {/* Actions */}
                        <div className="flex items-center space-x-2">
                          <Button
                            variant="ghost"
                            size="sm"
                            onClick={(e) => {
                              e.stopPropagation();
                              // Download file
                            }}
                            className="text-text-secondary hover:text-text-primary"
                          >
                            <Icon name="Download" size={16} />
                          </Button>
                          <Button
                            variant="ghost"
                            size="sm"
                            onClick={(e) => {
                              e.stopPropagation();
                              // Share file
                            }}
                            className="text-text-secondary hover:text-text-primary"
                          >
                            <Icon name="Share2" size={16} />
                          </Button>
                        </div>
                      </div>
                    ))}
                  </div>

                  {filteredRecentFiles.length === 0 && (
                    <div className="text-center py-12">
                      <Icon name="File" size={48} className="mx-auto mb-4 text-text-secondary opacity-50" />
                      <p className="text-text-secondary">
                        {searchQuery ? 'No files found matching your search' : 'No recent files'}
                      </p>
                    </div>
                  )}
                </div>
              </div>
            )}

            {/* Shared Files Tab */}
            {activeTab === 'shared' && (
              <div className="h-full flex items-center justify-center">
                <div className="text-center">
                  <Icon name="Share2" size={48} className="mx-auto mb-4 text-text-secondary opacity-50" />
                  <p className="text-text-secondary">Shared files will appear here</p>
                </div>
              </div>
            )}
          </div>
        </motion.div>
      </motion.div>
    </AnimatePresence>
  );
};

export default FileManager;