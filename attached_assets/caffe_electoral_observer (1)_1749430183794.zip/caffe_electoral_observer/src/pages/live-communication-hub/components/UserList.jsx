// src/pages/live-communication-hub/components/UserList.jsx
import React, { useState } from 'react';
import { formatDistanceToNow } from 'date-fns';
import Icon from 'components/AppIcon';

const UserList = ({ users = [] }) => {
  const [filter, setFilter] = useState('all'); // 'all', 'online', 'offline'

  const getUserInitials = (fullName) => {
    if (!fullName) return 'U';
    return fullName.split(' ').map(name => name[0]).join('').toUpperCase().slice(0, 2);
  };

  const getRoleColor = (role) => {
    switch (role) {
      case 'coordinator':
        return 'text-purple-600 bg-purple-100';
      case 'admin':
        return 'text-red-600 bg-red-100';
      case 'observer':
      default:
        return 'text-blue-600 bg-blue-100';
    }
  };

  const getRoleIcon = (role) => {
    switch (role) {
      case 'coordinator':
        return 'UserCheck';
      case 'admin':
        return 'Shield';
      case 'observer':
      default:
        return 'User';
    }
  };

  const filteredUsers = users.filter(user => {
    if (filter === 'online') return user.is_online;
    if (filter === 'offline') return !user.is_online;
    return true;
  });

  const onlineUsers = users.filter(user => user.is_online);
  const offlineUsers = users.filter(user => !user.is_online);

  const formatLastSeen = (timestamp) => {
    if (!timestamp) return 'Never';
    return formatDistanceToNow(new Date(timestamp), { addSuffix: true });
  };

  const handleUserAction = (user, action) => {
    // Handle user actions like direct message, call, etc.
    console.log('User action:', action, user);
  };

  return (
    <div className="flex flex-col h-full">
      {/* Header */}
      <div className="p-4 border-b border-border">
        <div className="flex items-center justify-between mb-4">
          <h3 className="text-lg font-semibold text-text-primary">Team Members</h3>
          <div className="flex items-center space-x-2 text-sm text-text-secondary">
            <div className="w-2 h-2 bg-success rounded-full"></div>
            <span>{onlineUsers.length} online</span>
          </div>
        </div>
        
        {/* Filter Tabs */}
        <div className="flex space-x-1 p-1 bg-background border border-border rounded-lg">
          {[
            { key: 'all', label: 'All', count: users.length },
            { key: 'online', label: 'Online', count: onlineUsers.length },
            { key: 'offline', label: 'Offline', count: offlineUsers.length }
          ].map(tab => (
            <button
              key={tab.key}
              onClick={() => setFilter(tab.key)}
              className={`flex-1 px-3 py-2 text-xs font-medium rounded-md transition-colors duration-150 ease-out ${
                filter === tab.key
                  ? 'bg-primary text-white' :'text-text-secondary hover:text-text-primary hover:bg-surface-secondary'
              }`}
            >
              {tab.label} ({tab.count})
            </button>
          ))}
        </div>
      </div>

      {/* User List */}
      <div className="flex-1 overflow-y-auto">
        <div className="p-4 space-y-3">
          {filteredUsers.length === 0 ? (
            <div className="text-center text-text-secondary py-8">
              <Icon name="Users" size={48} className="mx-auto mb-4 opacity-50" />
              <p className="text-sm">No users found</p>
            </div>
          ) : (
            filteredUsers.map((user) => (
              <div
                key={user.id}
                className="flex items-start space-x-3 p-3 rounded-lg hover:bg-surface-secondary transition-colors duration-150 ease-out group"
              >
                {/* Avatar with Status */}
                <div className="relative flex-shrink-0">
                  {user.avatar_url ? (
                    <img
                      src={user.avatar_url}
                      alt={user.full_name}
                      className="w-10 h-10 rounded-full object-cover"
                    />
                  ) : (
                    <div className="w-10 h-10 rounded-full bg-gray-500 flex items-center justify-center text-white text-sm font-medium">
                      {getUserInitials(user.full_name)}
                    </div>
                  )}
                  
                  {/* Online Status Indicator */}
                  <div className={`absolute -bottom-0.5 -right-0.5 w-3 h-3 rounded-full border-2 border-white ${
                    user.is_online ? 'bg-success' : 'bg-gray-400'
                  }`}></div>
                </div>
                
                {/* User Info */}
                <div className="flex-1 min-w-0">
                  <div className="flex items-center justify-between mb-1">
                    <h4 className="text-sm font-medium text-text-primary truncate">
                      {user.full_name}
                    </h4>
                    <div className="opacity-0 group-hover:opacity-100 transition-opacity duration-150 flex items-center space-x-1">
                      <button
                        onClick={() => handleUserAction(user, 'message')}
                        className="p-1 rounded text-text-secondary hover:text-primary hover:bg-primary-50 transition-colors"
                        title="Send message"
                      >
                        <Icon name="MessageSquare" size={14} />
                      </button>
                      <button
                        onClick={() => handleUserAction(user, 'call')}
                        className="p-1 rounded text-text-secondary hover:text-success hover:bg-success-50 transition-colors"
                        title="Call"
                      >
                        <Icon name="Phone" size={14} />
                      </button>
                    </div>
                  </div>
                  
                  {/* Role Badge */}
                  <div className="flex items-center space-x-2 mb-2">
                    <span className={`inline-flex items-center px-2 py-1 rounded-full text-xs font-medium ${
                      getRoleColor(user.role)
                    }`}>
                      <Icon name={getRoleIcon(user.role)} size={12} className="mr-1" />
                      {user.role?.charAt(0).toUpperCase() + user.role?.slice(1)}
                    </span>
                  </div>
                  
                  {/* Assignment Info */}
                  {user.station_assignment && (
                    <div className="flex items-center space-x-1 mb-1">
                      <Icon name="MapPin" size={12} className="text-text-secondary" />
                      <span className="text-xs text-text-secondary">
                        {user.station_assignment}
                      </span>
                    </div>
                  )}
                  
                  {user.parish && (
                    <div className="flex items-center space-x-1 mb-1">
                      <Icon name="Home" size={12} className="text-text-secondary" />
                      <span className="text-xs text-text-secondary">
                        {user.parish} Parish
                      </span>
                    </div>
                  )}
                  
                  {/* Status */}
                  <div className="flex items-center space-x-1">
                    {user.is_online ? (
                      <>
                        <div className="w-2 h-2 bg-success rounded-full"></div>
                        <span className="text-xs text-success font-medium">Online</span>
                      </>
                    ) : (
                      <>
                        <div className="w-2 h-2 bg-gray-400 rounded-full"></div>
                        <span className="text-xs text-text-secondary">
                          Last seen {formatLastSeen(user.last_seen)}
                        </span>
                      </>
                    )}
                  </div>
                </div>
              </div>
            ))
          )}
        </div>
      </div>
      
      {/* Emergency Contact Button */}
      <div className="p-4 border-t border-border">
        <button
          onClick={() => handleUserAction(null, 'emergency')}
          className="w-full flex items-center justify-center space-x-2 px-4 py-3 bg-error text-white rounded-lg hover:bg-error-700 transition-colors duration-150 ease-out"
        >
          <Icon name="AlertTriangle" size={16} />
          <span className="text-sm font-medium">Emergency Contact</span>
        </button>
      </div>
    </div>
  );
};

export default UserList;