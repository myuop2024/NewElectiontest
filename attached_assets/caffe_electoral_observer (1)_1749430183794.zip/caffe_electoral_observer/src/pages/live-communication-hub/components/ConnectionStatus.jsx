// src/pages/live-communication-hub/components/ConnectionStatus.jsx
import React from 'react';
import Icon from 'components/AppIcon';

const ConnectionStatus = ({ status = 'connected' }) => {
  const getStatusConfig = (currentStatus) => {
    switch (currentStatus) {
      case 'connected':
        return {
          color: 'text-success',
          bgColor: 'bg-success',
          icon: 'Wifi',
          label: 'Connected',
          description: 'Real-time communication active'
        };
      case 'connecting':
        return {
          color: 'text-warning',
          bgColor: 'bg-warning',
          icon: 'RotateCw',
          label: 'Connecting',
          description: 'Establishing connection...'
        };
      case 'disconnected':
        return {
          color: 'text-error',
          bgColor: 'bg-error',
          icon: 'WifiOff',
          label: 'Disconnected',
          description: 'No connection available'
        };
      case 'offline':
        return {
          color: 'text-text-secondary',
          bgColor: 'bg-text-secondary',
          icon: 'Cloud',
          label: 'Offline',
          description: 'Working in offline mode'
        };
      default:
        return {
          color: 'text-text-secondary',
          bgColor: 'bg-text-secondary',
          icon: 'HelpCircle',
          label: 'Unknown',
          description: 'Status unknown'
        };
    }
  };

  const config = getStatusConfig(status);

  return (
    <div className="flex items-center space-x-2">
      <div className="relative">
        <div className={`w-2 h-2 rounded-full ${config.bgColor}`}></div>
        {status === 'connected' && (
          <div className={`absolute inset-0 w-2 h-2 rounded-full ${config.bgColor} animate-ping opacity-75`}></div>
        )}
      </div>
      
      <div className="flex items-center space-x-1">
        <Icon 
          name={config.icon} 
          size={14} 
          className={`${config.color} ${status === 'connecting' ? 'animate-spin' : ''}`} 
        />
        <span className={`text-xs font-medium ${config.color}`}>
          {config.label}
        </span>
      </div>
    </div>
  );
};

export default ConnectionStatus;