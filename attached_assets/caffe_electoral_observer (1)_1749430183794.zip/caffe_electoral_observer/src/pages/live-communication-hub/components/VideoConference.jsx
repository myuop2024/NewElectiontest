// src/pages/live-communication-hub/components/VideoConference.jsx
import React, { useState, useRef, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import Icon from 'components/AppIcon';
import Button from 'components/ui/Button';

const VideoConference = ({ 
  channel, 
  participants = [], 
  onClose, 
  splitScreen = false, 
  onToggleSplitScreen 
}) => {
  const [isFullscreen, setIsFullscreen] = useState(false);
  const [isMuted, setIsMuted] = useState(false);
  const [isVideoOff, setIsVideoOff] = useState(false);
  const [isScreenSharing, setIsScreenSharing] = useState(false);
  const [isRecording, setIsRecording] = useState(false);
  const [participants_list, setParticipantsList] = useState(participants.slice(0, 4));
  const [localStream, setLocalStream] = useState(null);
  const [remoteStreams, setRemoteStreams] = useState({});
  const videoRef = useRef(null);
  const containerRef = useRef(null);

  // Initialize video call
  useEffect(() => {
    startLocalVideo();
    
    return () => {
      if (localStream) {
        localStream.getTracks().forEach(track => track.stop());
      }
    };
  }, []);

  const startLocalVideo = async () => {
    try {
      const stream = await navigator.mediaDevices.getUserMedia({
        video: true,
        audio: true
      });
      setLocalStream(stream);
      if (videoRef.current) {
        videoRef.current.srcObject = stream;
      }
    } catch (error) {
      console.error('Error accessing media devices:', error);
    }
  };

  const toggleMute = () => {
    if (localStream) {
      localStream.getAudioTracks().forEach(track => {
        track.enabled = !track.enabled;
      });
      setIsMuted(!isMuted);
    }
  };

  const toggleVideo = () => {
    if (localStream) {
      localStream.getVideoTracks().forEach(track => {
        track.enabled = !track.enabled;
      });
      setIsVideoOff(!isVideoOff);
    }
  };

  const toggleScreenShare = async () => {
    try {
      if (!isScreenSharing) {
        const screenStream = await navigator.mediaDevices.getDisplayMedia({
          video: true,
          audio: true
        });
        setLocalStream(screenStream);
        if (videoRef.current) {
          videoRef.current.srcObject = screenStream;
        }
        setIsScreenSharing(true);
      } else {
        await startLocalVideo();
        setIsScreenSharing(false);
      }
    } catch (error) {
      console.error('Error sharing screen:', error);
    }
  };

  const toggleRecording = () => {
    setIsRecording(!isRecording);
    // Implement recording logic here
  };

  const toggleFullscreen = () => {
    if (!document.fullscreenElement) {
      containerRef.current?.requestFullscreen();
      setIsFullscreen(true);
    } else {
      document.exitFullscreen();
      setIsFullscreen(false);
    }
  };

  const getParticipantInitials = (name) => {
    return name?.split(' ').map(n => n[0]).join('').toUpperCase().slice(0, 2) || 'U';
  };

  const getLayoutClass = () => {
    const count = participants_list.length + 1; // +1 for local video
    if (count <= 2) return 'grid-cols-1 md:grid-cols-2';
    if (count <= 4) return 'grid-cols-2';
    if (count <= 6) return 'grid-cols-2 md:grid-cols-3';
    return 'grid-cols-2 md:grid-cols-3 lg:grid-cols-4';
  };

  return (
    <AnimatePresence>
      <motion.div
        ref={containerRef}
        initial={{ opacity: 0, scale: 0.9 }}
        animate={{ opacity: 1, scale: 1 }}
        exit={{ opacity: 0, scale: 0.9 }}
        className={`fixed inset-0 z-50 bg-black flex flex-col ${
          splitScreen ? 'lg:inset-x-1/2' : ''
        }`}
      >
        {/* Header */}
        <div className="flex items-center justify-between p-4 bg-gray-900 text-white">
          <div className="flex items-center space-x-3">
            <div className="w-3 h-3 bg-red-500 rounded-full animate-pulse"></div>
            <h3 className="text-lg font-medium">
              {channel?.name || 'Video Conference'}
            </h3>
            <span className="text-sm text-gray-300">
              {participants_list.length + 1} participants
            </span>
            {isRecording && (
              <div className="flex items-center space-x-1 text-red-400">
                <Icon name="Circle" size={12} className="fill-current" />
                <span className="text-xs">REC</span>
              </div>
            )}
          </div>

          <div className="flex items-center space-x-2">
            <Button
              variant="ghost"
              size="sm"
              onClick={onToggleSplitScreen}
              className="text-white hover:bg-gray-800"
              title="Toggle Split Screen"
            >
              <Icon name={splitScreen ? "Minimize2" : "Maximize2"} size={16} />
            </Button>
            
            <Button
              variant="ghost"
              size="sm"
              onClick={toggleFullscreen}
              className="text-white hover:bg-gray-800"
              title="Toggle Fullscreen"
            >
              <Icon name={isFullscreen ? "Minimize" : "Maximize"} size={16} />
            </Button>
            
            <Button
              variant="ghost"
              size="sm"
              onClick={onClose}
              className="text-white hover:bg-gray-800"
              title="Close Conference"
            >
              <Icon name="X" size={16} />
            </Button>
          </div>
        </div>

        {/* Video Grid */}
        <div className="flex-1 p-4">
          <div className={`grid gap-4 h-full ${getLayoutClass()}`}>
            {/* Local Video */}
            <div className="relative bg-gray-800 rounded-lg overflow-hidden">
              <video
                ref={videoRef}
                autoPlay
                muted
                className="w-full h-full object-cover"
              />
              {isVideoOff && (
                <div className="absolute inset-0 bg-gray-800 flex items-center justify-center">
                  <div className="w-16 h-16 bg-gray-600 rounded-full flex items-center justify-center">
                    <span className="text-white text-lg font-medium">
                      {getParticipantInitials('You')}
                    </span>
                  </div>
                </div>
              )}
              <div className="absolute bottom-2 left-2 bg-black bg-opacity-50 text-white px-2 py-1 rounded text-sm">
                You {isMuted && '(muted)'}
              </div>
              {isScreenSharing && (
                <div className="absolute top-2 left-2 bg-primary text-white px-2 py-1 rounded text-xs">
                  <Icon name="Monitor" size={12} className="inline mr-1" />
                  Sharing
                </div>
              )}
            </div>

            {/* Participant Videos */}
            {participants_list.map((participant, index) => (
              <div key={participant.id} className="relative bg-gray-800 rounded-lg overflow-hidden">
                {participant.avatar_url ? (
                  <img
                    src={participant.avatar_url}
                    alt={participant.full_name}
                    className="w-full h-full object-cover"
                  />
                ) : (
                  <div className="w-full h-full flex items-center justify-center">
                    <div className="w-16 h-16 bg-gray-600 rounded-full flex items-center justify-center">
                      <span className="text-white text-lg font-medium">
                        {getParticipantInitials(participant.full_name)}
                      </span>
                    </div>
                  </div>
                )}
                <div className="absolute bottom-2 left-2 bg-black bg-opacity-50 text-white px-2 py-1 rounded text-sm">
                  {participant.full_name}
                </div>
                <div className="absolute top-2 right-2 flex items-center space-x-1">
                  {participant.is_muted && (
                    <div className="w-6 h-6 bg-red-500 rounded-full flex items-center justify-center">
                      <Icon name="MicOff" size={12} className="text-white" />
                    </div>
                  )}
                  {participant.is_video_off && (
                    <div className="w-6 h-6 bg-red-500 rounded-full flex items-center justify-center">
                      <Icon name="VideoOff" size={12} className="text-white" />
                    </div>
                  )}
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Controls */}
        <div className="bg-gray-900 p-4">
          <div className="flex items-center justify-center space-x-4">
            <Button
              onClick={toggleMute}
              className={`w-12 h-12 rounded-full ${
                isMuted 
                  ? 'bg-red-600 hover:bg-red-700 text-white' :'bg-gray-700 hover:bg-gray-600 text-white'
              }`}
              title={isMuted ? 'Unmute' : 'Mute'}
            >
              <Icon name={isMuted ? "MicOff" : "Mic"} size={20} />
            </Button>

            <Button
              onClick={toggleVideo}
              className={`w-12 h-12 rounded-full ${
                isVideoOff 
                  ? 'bg-red-600 hover:bg-red-700 text-white' :'bg-gray-700 hover:bg-gray-600 text-white'
              }`}
              title={isVideoOff ? 'Turn on video' : 'Turn off video'}
            >
              <Icon name={isVideoOff ? "VideoOff" : "Video"} size={20} />
            </Button>

            <Button
              onClick={toggleScreenShare}
              className={`w-12 h-12 rounded-full ${
                isScreenSharing 
                  ? 'bg-primary hover:bg-primary-700 text-white' :'bg-gray-700 hover:bg-gray-600 text-white'
              }`}
              title={isScreenSharing ? 'Stop sharing' : 'Share screen'}
            >
              <Icon name="Monitor" size={20} />
            </Button>

            <Button
              onClick={toggleRecording}
              className={`w-12 h-12 rounded-full ${
                isRecording 
                  ? 'bg-red-600 hover:bg-red-700 text-white' :'bg-gray-700 hover:bg-gray-600 text-white'
              }`}
              title={isRecording ? 'Stop recording' : 'Start recording'}
            >
              <Icon name="Circle" size={20} />
            </Button>

            <div className="border-l border-gray-600 h-8 mx-2"></div>

            <Button
              onClick={onClose}
              className="w-12 h-12 rounded-full bg-red-600 hover:bg-red-700 text-white"
              title="End call"
            >
              <Icon name="PhoneOff" size={20} />
            </Button>
          </div>

          {/* Additional Controls */}
          <div className="flex items-center justify-center space-x-4 mt-4 text-sm text-gray-300">
            <button className="flex items-center space-x-1 hover:text-white">
              <Icon name="Users" size={16} />
              <span>Participants</span>
            </button>
            <button className="flex items-center space-x-1 hover:text-white">
              <Icon name="MessageSquare" size={16} />
              <span>Chat</span>
            </button>
            <button className="flex items-center space-x-1 hover:text-white">
              <Icon name="Settings" size={16} />
              <span>Settings</span>
            </button>
          </div>
        </div>
      </motion.div>
    </AnimatePresence>
  );
};

export default VideoConference;