// src/pages/live-communication-hub/components/ChatArea.jsx
import React, { useState, useRef, useEffect, useCallback } from 'react';
import { format, isToday, isYesterday } from 'date-fns';
import Icon from 'components/AppIcon';
import Button from 'components/ui/Button';

const ChatArea = ({ 
  channel, 
  messages = [], 
  onSendMessage, 
  currentUser, 
  onMediaSelect,
  onStartVideoCall,
  isVideoCallActive,
  multiWindowMode,
  onOpenInNewWindow
}) => {
  const [newMessage, setNewMessage] = useState('');
  const [isTyping, setIsTyping] = useState(false);
  const [dragActive, setDragActive] = useState(false);
  const [attachments, setAttachments] = useState([]);
  const [showEmojiPicker, setShowEmojiPicker] = useState(false);
  const [searchQuery, setSearchQuery] = useState('');
  const [searchResults, setSearchResults] = useState([]);
  const [showSearch, setShowSearch] = useState(false);
  const [isRecording, setIsRecording] = useState(false);
  const [recordingDuration, setRecordingDuration] = useState(0);
  const messagesEndRef = useRef(null);
  const inputRef = useRef(null);
  const fileInputRef = useRef(null);
  const chatAreaRef = useRef(null);
  const mediaRecorderRef = useRef(null);
  const recordingTimerRef = useRef(null);

  // Enhanced emoji list
  const commonEmojis = ['😀', '😂', '😍', '🤔', '😢', '😡', '👍', '👎', '❤️', '🎉', '🔥', '💯'];

  // Auto-scroll to bottom when new messages arrive
  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages]);

  // Focus input on channel change
  useEffect(() => {
    inputRef.current?.focus();
  }, [channel]);

  // Handle drag and drop for files
  const handleDrag = useCallback((e) => {
    e.preventDefault();
    e.stopPropagation();
    if (e.type === "dragenter" || e.type === "dragover") {
      setDragActive(true);
    } else if (e.type === "dragleave") {
      setDragActive(false);
    }
  }, []);

  const handleDrop = useCallback((e) => {
    e.preventDefault();
    e.stopPropagation();
    setDragActive(false);

    if (e.dataTransfer.files && e.dataTransfer.files[0]) {
      handleFileSelect(Array.from(e.dataTransfer.files));
    }
  }, []);

  const handleFileSelect = (files) => {
    const validFiles = files.filter(file => {
      const maxSize = 10 * 1024 * 1024; // 10MB
      return file.size <= maxSize;
    });

    setAttachments(prev => [...prev, ...validFiles.map(file => ({
      id: Date.now() + Math.random(),
      file,
      name: file.name,
      type: file.type,
      size: file.size,
      preview: file.type.startsWith('image/') ? URL.createObjectURL(file) : null
    }))]);
  };

  const removeAttachment = (attachmentId) => {
    setAttachments(prev => {
      const attachment = prev.find(a => a.id === attachmentId);
      if (attachment?.preview) {
        URL.revokeObjectURL(attachment.preview);
      }
      return prev.filter(a => a.id !== attachmentId);
    });
  };

  const handleSendMessage = (e) => {
    e.preventDefault();
    if (newMessage.trim() || attachments.length > 0) {
      onSendMessage(newMessage.trim(), 'text', attachments.map(a => a.file));
      setNewMessage('');
      setAttachments([]);
    }
  };

  const handleKeyPress = (e) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault();
      handleSendMessage(e);
    }
  };

  // Voice recording functions
  const startRecording = async () => {
    try {
      const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
      mediaRecorderRef.current = new MediaRecorder(stream);
      const chunks = [];

      mediaRecorderRef.current.ondataavailable = (e) => {
        chunks.push(e.data);
      };

      mediaRecorderRef.current.onstop = () => {
        const blob = new Blob(chunks, { type: 'audio/wav' });
        const file = new File([blob], `voice-${Date.now()}.wav`, { type: 'audio/wav' });
        handleFileSelect([file]);
        stream.getTracks().forEach(track => track.stop());
      };

      mediaRecorderRef.current.start();
      setIsRecording(true);
      setRecordingDuration(0);
      
      recordingTimerRef.current = setInterval(() => {
        setRecordingDuration(prev => prev + 1);
      }, 1000);
    } catch (error) {
      console.error('Error starting recording:', error);
    }
  };

  const stopRecording = () => {
    if (mediaRecorderRef.current && isRecording) {
      mediaRecorderRef.current.stop();
      setIsRecording(false);
      clearInterval(recordingTimerRef.current);
    }
  };

  // Message search functionality
  const handleSearch = (query) => {
    setSearchQuery(query);
    if (query.trim()) {
      const results = messages.filter(message => 
        message.content?.toLowerCase().includes(query.toLowerCase()) ||
        message.user?.full_name?.toLowerCase().includes(query.toLowerCase())
      );
      setSearchResults(results);
    } else {
      setSearchResults([]);
    }
  };

  const scrollToMessage = (messageId) => {
    const messageElement = document.getElementById(`message-${messageId}`);
    messageElement?.scrollIntoView({ behavior: 'smooth', block: 'center' });
  };

  const formatMessageTime = (timestamp) => {
    const date = new Date(timestamp);
    if (isToday(date)) {
      return format(date, 'HH:mm');
    } else if (isYesterday(date)) {
      return 'Yesterday ' + format(date, 'HH:mm');
    } else {
      return format(date, 'MMM dd, HH:mm');
    }
  };

  const formatMessageDate = (timestamp) => {
    const date = new Date(timestamp);
    if (isToday(date)) {
      return 'Today';
    } else if (isYesterday(date)) {
      return 'Yesterday';
    } else {
      return format(date, 'MMMM dd, yyyy');
    }
  };

  const shouldShowDateDivider = (currentMessage, previousMessage) => {
    if (!previousMessage) return true;
    
    const currentDate = new Date(currentMessage.created_at);
    const previousDate = new Date(previousMessage.created_at);
    
    return currentDate.toDateString() !== previousDate.toDateString();
  };

  const getUserInitials = (fullName) => {
    if (!fullName) return 'U';
    return fullName.split(' ').map(name => name[0]).join('').toUpperCase().slice(0, 2);
  };

  const getRoleColor = (role) => {
    switch (role) {
      case 'coordinator':
        return 'text-purple-600';
      case 'admin':
        return 'text-red-600';
      case 'observer':
      default:
        return 'text-blue-600';
    }
  };

  const getChannelIcon = (type) => {
    switch (type) {
      case 'emergency':
        return { name: 'AlertTriangle', color: 'text-error' };
      case 'team':
        return { name: 'Users', color: 'text-primary' };
      case 'conference':
        return { name: 'Video', color: 'text-secondary' };
      case 'general':
      default:
        return { name: 'Hash', color: 'text-text-secondary' };
    }
  };

  const iconConfig = getChannelIcon(channel?.type);

  const formatFileSize = (bytes) => {
    if (bytes === 0) return '0 Bytes';
    const k = 1024;
    const sizes = ['Bytes', 'KB', 'MB', 'GB'];
    const i = Math.floor(Math.log(bytes) / Math.log(k));
    return parseFloat((bytes / Math.pow(k, i)).toFixed(2)) + ' ' + sizes[i];
  };

  const formatRecordingTime = (seconds) => {
    const mins = Math.floor(seconds / 60);
    const secs = seconds % 60;
    return `${mins}:${secs.toString().padStart(2, '0')}`;
  };

  return (
    <div 
      className="flex flex-col h-full"
      onDragEnter={handleDrag}
      onDragLeave={handleDrag}
      onDragOver={handleDrag}
      onDrop={handleDrop}
    >
      {/* Drag overlay */}
      {dragActive && (
        <div className="absolute inset-0 z-10 bg-primary bg-opacity-20 border-2 border-dashed border-primary rounded-lg flex items-center justify-center">
          <div className="text-center text-primary">
            <Icon name="Upload" size={48} className="mx-auto mb-4" />
            <p className="text-lg font-medium">Drop files here to share</p>
          </div>
        </div>
      )}

      {/* Chat Header */}
      <div className="px-6 py-4 border-b border-border bg-surface">
        <div className="flex items-center justify-between">
          <div className="flex items-center space-x-3">
            <Icon
              name={iconConfig.name}
              size={20}
              className={iconConfig.color}
            />
            <div>
              <h2 className="text-lg font-semibold text-text-primary">
                {channel?.name}
              </h2>
              {channel?.description && (
                <p className="text-sm text-text-secondary">
                  {channel.description}
                </p>
              )}
              {channel?.participant_count && (
                <p className="text-xs text-text-tertiary">
                  {channel.participant_count} participants
                </p>
              )}
            </div>
          </div>
          
          <div className="flex items-center space-x-2">
            <Button
              variant="ghost"
              size="sm"
              onClick={() => setShowSearch(!showSearch)}
              className={`${showSearch ? 'text-primary bg-primary-50' : 'text-text-secondary hover:text-text-primary'}`}
              title="Search messages"
            >
              <Icon name="Search" size={16} />
            </Button>
            
            {channel?.type === 'conference' || channel?.has_active_call ? (
              <Button
                variant="ghost"
                size="sm"
                onClick={onStartVideoCall}
                className={`${isVideoCallActive ? 'text-success bg-success-50' : 'text-text-secondary hover:text-text-primary'}`}
                title="Join video call"
              >
                <Icon name={isVideoCallActive ? "VideoOff" : "Video"} size={16} />
              </Button>
            ) : null}
            
            {multiWindowMode && (
              <Button
                variant="ghost"
                size="sm"
                onClick={() => onOpenInNewWindow?.({
                  title: `Chat - ${channel?.name}`,
                  html: `<h1>${channel?.name}</h1><p>Chat window opened in new window</p>`
                })}
                className="text-text-secondary hover:text-text-primary"
                title="Open in new window"
              >
                <Icon name="ExternalLink" size={16} />
              </Button>
            )}
            
            <Button
              variant="ghost"
              size="sm"
              onClick={() => {}}
              className="text-text-secondary hover:text-text-primary"
              title="Channel info"
            >
              <Icon name="Info" size={16} />
            </Button>
          </div>
        </div>

        {/* Search Bar */}
        {showSearch && (
          <div className="mt-4">
            <div className="relative">
              <Icon name="Search" size={16} className="absolute left-3 top-3 text-text-secondary" />
              <input
                type="text"
                placeholder="Search messages..."
                value={searchQuery}
                onChange={(e) => handleSearch(e.target.value)}
                className="w-full pl-10 pr-4 py-2 text-sm border border-border rounded-lg bg-background focus:outline-none focus:ring-2 focus:ring-primary focus:border-transparent"
              />
            </div>
            {searchResults.length > 0 && (
              <div className="mt-2 max-h-32 overflow-y-auto bg-background border border-border rounded-lg">
                {searchResults.map(result => (
                  <button
                    key={result.id}
                    onClick={() => scrollToMessage(result.id)}
                    className="w-full text-left p-2 hover:bg-surface-secondary text-sm border-b border-border last:border-b-0"
                  >
                    <span className="font-medium">{result.user?.full_name}:</span> {result.content?.substring(0, 50)}...
                  </button>
                ))}
              </div>
            )}
          </div>
        )}
      </div>

      {/* Messages Area */}
      <div ref={chatAreaRef} className="flex-1 overflow-y-auto px-6 py-4 space-y-4">
        {messages.length === 0 ? (
          <div className="flex-1 flex items-center justify-center text-text-secondary">
            <div className="text-center">
              <Icon name="MessageSquare" size={48} className="mx-auto mb-4 opacity-50" />
              <p className="text-lg mb-2">No messages yet</p>
              <p className="text-sm">Be the first to start the conversation!</p>
            </div>
          </div>
        ) : (
          messages.map((message, index) => {
            const previousMessage = index > 0 ? messages[index - 1] : null;
            const showDateDivider = shouldShowDateDivider(message, previousMessage);
            const isOwnMessage = message.user_id === currentUser?.id || message.user_id === 'current_user';
            
            return (
              <div key={message.id} id={`message-${message.id}`}>
                {showDateDivider && (
                  <div className="flex items-center justify-center my-6">
                    <div className="px-3 py-1 bg-surface border border-border rounded-full text-xs text-text-secondary">
                      {formatMessageDate(message.created_at)}
                    </div>
                  </div>
                )}
                
                <div className={`flex space-x-3 ${isOwnMessage ? 'flex-row-reverse space-x-reverse' : ''}`}>
                  {/* Avatar */}
                  <div className="flex-shrink-0">
                    {message.user?.avatar_url ? (
                      <img
                        src={message.user.avatar_url}
                        alt={message.user?.full_name || 'User'}
                        className="w-8 h-8 rounded-full object-cover"
                        onError={(e) => {
                          e.target.style.display = 'none';
                          e.target.nextSibling.style.display = 'flex';
                        }}
                      />
                    ) : (
                      <div className={`w-8 h-8 rounded-full flex items-center justify-center text-white text-xs font-medium ${
                        isOwnMessage ? 'bg-primary' : 'bg-gray-500'
                      }`}>
                        {getUserInitials(message.user?.full_name)}
                      </div>
                    )}
                  </div>
                  
                  {/* Message Content */}
                  <div className={`flex-1 max-w-xs sm:max-w-md lg:max-w-lg xl:max-w-2xl ${isOwnMessage ? 'text-right' : ''}`}>
                    {/* Message Info */}
                    <div className={`flex items-center space-x-2 mb-1 ${isOwnMessage ? 'flex-row-reverse space-x-reverse' : ''}`}>
                      <span className="text-sm font-medium text-text-primary">
                        {message.user?.full_name || 'Unknown User'}
                      </span>
                      {message.user?.role && (
                        <span className={`text-xs font-medium ${getRoleColor(message.user.role)}`}>
                          {message.user.role}
                        </span>
                      )}
                      <span className="text-xs text-text-secondary">
                        {formatMessageTime(message.created_at)}
                      </span>
                    </div>
                    
                    {/* Message Bubble */}
                    <div className={`inline-block px-4 py-2 rounded-2xl max-w-full break-words ${
                      isOwnMessage
                        ? 'bg-primary text-white rounded-br-md' :'bg-surface border border-border text-text-primary rounded-bl-md'
                    }`}>
                      {message.message_type === 'system' ? (
                        <div className="flex items-center space-x-2 text-sm italic">
                          <Icon name="Info" size={14} />
                          <span>{message.content}</span>
                        </div>
                      ) : message.message_type === 'emergency' ? (
                        <div className="flex items-center space-x-2 text-sm font-medium">
                          <Icon name="AlertTriangle" size={14} className="text-error" />
                          <span>{message.content}</span>
                        </div>
                      ) : (
                        <div>
                          {message.content && (
                            <p className="text-sm whitespace-pre-wrap">{message.content}</p>
                          )}
                          
                          {/* Attachments */}
                          {message.attachments && message.attachments.length > 0 && (
                            <div className="mt-2 space-y-2">
                              {message.attachments.map((attachment, index) => (
                                <div 
                                  key={index}
                                  className="bg-black bg-opacity-10 rounded-lg p-2 cursor-pointer hover:bg-opacity-20 transition-colors"
                                  onClick={() => onMediaSelect?.(attachment)}
                                >
                                  {attachment.type?.startsWith('image/') ? (
                                    <img 
                                      src={attachment.url || attachment.preview} 
                                      alt={attachment.name}
                                      className="max-w-64 max-h-64 rounded object-cover"
                                    />
                                  ) : (
                                    <div className="flex items-center space-x-2">
                                      <Icon name="File" size={16} />
                                      <div>
                                        <p className="text-xs font-medium">{attachment.name}</p>
                                        <p className="text-xs opacity-75">{formatFileSize(attachment.size)}</p>
                                      </div>
                                    </div>
                                  )}
                                </div>
                              ))}
                            </div>
                          )}
                        </div>
                      )}
                    </div>
                    
                    {/* Message Actions */}
                    <div className={`mt-1 flex items-center space-x-2 ${isOwnMessage ? 'justify-end' : ''}`}>
                      <button 
                        className="text-text-secondary hover:text-text-primary transition-colors p-1 rounded"
                        title="React"
                      >
                        <Icon name="Smile" size={14} />
                      </button>
                      <button 
                        className="text-text-secondary hover:text-text-primary transition-colors p-1 rounded"
                        title="Reply"
                      >
                        <Icon name="Reply" size={14} />
                      </button>
                      <button 
                        className="text-text-secondary hover:text-text-primary transition-colors p-1 rounded"
                        title="More options"
                      >
                        <Icon name="MoreHorizontal" size={14} />
                      </button>
                    </div>
                  </div>
                </div>
              </div>
            );
          })
        )}
        
        {/* Typing Indicator */}
        {isTyping && (
          <div className="flex items-center space-x-2 text-text-secondary text-sm">
            <div className="flex space-x-1">
              <div className="w-2 h-2 bg-text-secondary rounded-full animate-bounce"></div>
              <div className="w-2 h-2 bg-text-secondary rounded-full animate-bounce" style={{ animationDelay: '0.1s' }}></div>
              <div className="w-2 h-2 bg-text-secondary rounded-full animate-bounce" style={{ animationDelay: '0.2s' }}></div>
            </div>
            <span>Someone is typing...</span>
          </div>
        )}
        
        <div ref={messagesEndRef} />
      </div>

      {/* Attachments Preview */}
      {attachments.length > 0 && (
        <div className="px-6 py-2 border-t border-border bg-surface-secondary">
          <div className="flex items-center space-x-2 overflow-x-auto">
            {attachments.map(attachment => (
              <div key={attachment.id} className="relative flex-shrink-0">
                {attachment.preview ? (
                  <img 
                    src={attachment.preview} 
                    alt={attachment.name}
                    className="w-16 h-16 object-cover rounded"
                  />
                ) : (
                  <div className="w-16 h-16 bg-background border border-border rounded flex items-center justify-center">
                    <Icon name="File" size={20} className="text-text-secondary" />
                  </div>
                )}
                <button
                  onClick={() => removeAttachment(attachment.id)}
                  className="absolute -top-1 -right-1 w-5 h-5 bg-error text-white rounded-full flex items-center justify-center hover:bg-error-700"
                >
                  <Icon name="X" size={12} />
                </button>
                <div className="absolute bottom-0 left-0 right-0 bg-black bg-opacity-50 text-white text-xs p-1 rounded-b truncate">
                  {attachment.name}
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Message Input */}
      <div className="px-6 py-4 border-t border-border bg-surface">
        {/* Recording Indicator */}
        {isRecording && (
          <div className="mb-3 flex items-center justify-between p-3 bg-error-50 border border-error-200 rounded-lg">
            <div className="flex items-center space-x-2 text-error">
              <div className="w-3 h-3 bg-error rounded-full animate-pulse"></div>
              <span className="text-sm font-medium">Recording... {formatRecordingTime(recordingDuration)}</span>
            </div>
            <Button
              onClick={stopRecording}
              className="bg-error text-white hover:bg-error-700 text-sm"
              size="sm"
            >
              <Icon name="Square" size={14} className="mr-1" />
              Stop
            </Button>
          </div>
        )}

        <form onSubmit={handleSendMessage} className="flex items-end space-x-3">
          <div className="flex-1">
            <textarea
              ref={inputRef}
              value={newMessage}
              onChange={(e) => setNewMessage(e.target.value)}
              onKeyPress={handleKeyPress}
              placeholder={`Message ${channel?.name || 'channel'}...`}
              className="w-full px-4 py-3 text-sm border border-border rounded-lg bg-background resize-none focus:outline-none focus:ring-2 focus:ring-primary focus:border-transparent"
              rows={1}
              style={{
                minHeight: '44px',
                maxHeight: '120px',
                height: 'auto'
              }}
              onInput={(e) => {
                e.target.style.height = 'auto';
                e.target.style.height = e.target.scrollHeight + 'px';
              }}
            />
          </div>
          
          <div className="flex items-center space-x-2">
            {/* Emoji Picker */}
            <div className="relative">
              <Button
                type="button"
                variant="ghost"
                size="sm"
                onClick={() => setShowEmojiPicker(!showEmojiPicker)}
                className="text-text-secondary hover:text-text-primary"
                title="Add emoji"
              >
                <Icon name="Smile" size={18} />
              </Button>
              
              {showEmojiPicker && (
                <div className="absolute bottom-12 right-0 bg-surface border border-border rounded-lg shadow-lg p-3 z-10">
                  <div className="grid grid-cols-6 gap-1">
                    {commonEmojis.map(emoji => (
                      <button
                        key={emoji}
                        type="button"
                        onClick={() => {
                          setNewMessage(prev => prev + emoji);
                          setShowEmojiPicker(false);
                        }}
                        className="text-lg hover:bg-surface-secondary rounded p-1"
                      >
                        {emoji}
                      </button>
                    ))}
                  </div>
                </div>
              )}
            </div>

            {/* File Upload */}
            <Button
              type="button"
              variant="ghost"
              size="sm"
              onClick={() => fileInputRef.current?.click()}
              className="text-text-secondary hover:text-text-primary"
              title="Attach file"
            >
              <Icon name="Paperclip" size={18} />
            </Button>
            
            {/* Voice Recording */}
            <Button
              type="button"
              variant="ghost"
              size="sm"
              onClick={isRecording ? stopRecording : startRecording}
              className={`${isRecording ? 'text-error bg-error-50' : 'text-text-secondary hover:text-text-primary'}`}
              title={isRecording ? 'Stop recording' : 'Record voice message'}
            >
              <Icon name={isRecording ? "Square" : "Mic"} size={18} />
            </Button>
            
            <Button
              type="submit"
              disabled={!newMessage.trim() && attachments.length === 0}
              className="bg-primary hover:bg-primary-700 text-white disabled:opacity-50 disabled:cursor-not-allowed"
              title="Send message (Enter)"
            >
              <Icon name="Send" size={18} />
            </Button>
          </div>
        </form>
        
        <div className="mt-2 text-xs text-text-secondary">
          Press Enter to send, Shift+Enter for new line. Drop files to attach.
        </div>
      </div>

      {/* Hidden file input */}
      <input
        ref={fileInputRef}
        type="file"
        multiple
        onChange={(e) => e.target.files && handleFileSelect(Array.from(e.target.files))}
        className="hidden"
        accept="image/*,video/*,audio/*,application/pdf,.doc,.docx,.xls,.xlsx,.txt,.csv"
      />
    </div>
  );
};

export default ChatArea;