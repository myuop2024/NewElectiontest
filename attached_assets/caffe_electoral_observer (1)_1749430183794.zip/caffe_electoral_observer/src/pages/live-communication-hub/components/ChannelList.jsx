// src/pages/live-communication-hub/components/ChannelList.jsx
import React from 'react';
import { formatDistanceToNow } from 'date-fns';
import Icon from 'components/AppIcon';

const ChannelList = ({ channels = [], activeChannel, onChannelSelect }) => {
  const getChannelIcon = (type) => {
    switch (type) {
      case 'emergency':
        return { name: 'AlertTriangle', color: 'text-error' };
      case 'team':
        return { name: 'Users', color: 'text-primary' };
      case 'general':
      default:
        return { name: 'Hash', color: 'text-text-secondary' };
    }
  };

  const formatLastMessageTime = (timestamp) => {
    if (!timestamp) return '';
    const date = new Date(timestamp);
    return formatDistanceToNow(date, { addSuffix: true });
  };

  const truncateMessage = (message, maxLength = 50) => {
    if (!message || message.length <= maxLength) return message;
    return message.substring(0, maxLength) + '...';
  };

  return (
    <div className="flex-1 overflow-y-auto">
      <div className="p-4">
        <div className="space-y-2">
          {channels.map((channel) => {
            const iconConfig = getChannelIcon(channel.type);
            const isActive = activeChannel?.id === channel.id;
            
            return (
              <button
                key={channel.id}
                onClick={() => onChannelSelect(channel)}
                className={`w-full text-left p-3 rounded-lg transition-colors duration-150 ease-out ${
                  isActive
                    ? 'bg-primary text-white' :'hover:bg-surface-secondary text-text-primary'
                }`}
              >
                <div className="flex items-start space-x-3">
                  <div className="flex-shrink-0 mt-0.5">
                    <Icon
                      name={iconConfig.name}
                      size={18}
                      className={isActive ? 'text-white' : iconConfig.color}
                    />
                  </div>
                  <div className="flex-1 min-w-0">
                    <div className="flex items-center justify-between mb-1">
                      <h3 className={`text-sm font-medium truncate ${
                        isActive ? 'text-white' : 'text-text-primary'
                      }`}>
                        {channel.name}
                      </h3>
                      {channel.unread_count > 0 && (
                        <span className={`inline-flex items-center justify-center px-2 py-1 text-xs font-bold rounded-full ${
                          isActive
                            ? 'bg-white text-primary' :'bg-primary text-white'
                        }`}>
                          {channel.unread_count > 99 ? '99+' : channel.unread_count}
                        </span>
                      )}
                    </div>
                    
                    {channel.last_message && (
                      <div className="space-y-1">
                        <p className={`text-xs truncate ${
                          isActive ? 'text-white/80' : 'text-text-secondary'
                        }`}>
                          {channel.last_message.user?.full_name}: {truncateMessage(channel.last_message.content)}
                        </p>
                        <p className={`text-xs ${
                          isActive ? 'text-white/60' : 'text-text-secondary'
                        }`}>
                          {formatLastMessageTime(channel.last_message.created_at)}
                        </p>
                      </div>
                    )}
                    
                    {channel.description && !channel.last_message && (
                      <p className={`text-xs ${
                        isActive ? 'text-white/80' : 'text-text-secondary'
                      }`}>
                        {channel.description}
                      </p>
                    )}
                  </div>
                </div>
              </button>
            );
          })}
        </div>
      </div>
      
      {channels.length === 0 && (
        <div className="p-4 text-center text-text-secondary">
          <Icon name="Hash" size={48} className="mx-auto mb-4 opacity-50" />
          <p className="text-sm">No channels available</p>
          <p className="text-xs mt-1">Contact your coordinator to join channels</p>
        </div>
      )}
    </div>
  );
};

export default ChannelList;