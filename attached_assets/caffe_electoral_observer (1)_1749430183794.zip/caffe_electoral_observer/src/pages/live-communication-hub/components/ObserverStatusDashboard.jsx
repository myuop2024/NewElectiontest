// src/pages/live-communication-hub/components/ObserverStatusDashboard.jsx
import React, { useState, useEffect } from 'react';
import { formatDistanceToNow } from 'date-fns';
import Icon from 'components/AppIcon';
import Button from 'components/ui/Button';

const ObserverStatusDashboard = ({ 
  observers = [], 
  onEmergencyBroadcast, 
  onObserverSelect 
}) => {
  const [selectedObserver, setSelectedObserver] = useState(null);
  const [filterStatus, setFilterStatus] = useState('all'); // 'all', 'checked_in', 'in_transit', 'emergency'
  const [sortBy, setSortBy] = useState('last_checkin'); // 'last_checkin', 'name', 'station', 'incidents'
  const [emergencyBroadcastMessage, setEmergencyBroadcastMessage] = useState('');
  const [showEmergencyDialog, setShowEmergencyDialog] = useState(false);
  const [alertCount, setAlertCount] = useState(0);

  // Calculate statistics
  const stats = {
    total: observers.length,
    checked_in: observers.filter(o => o.status === 'checked_in').length,
    in_transit: observers.filter(o => o.status === 'in_transit').length,
    emergency: observers.filter(o => o.status === 'emergency').length,
    low_battery: observers.filter(o => o.battery_level < 30).length,
    incidents: observers.reduce((sum, o) => sum + (o.incident_count || 0), 0)
  };

  // Filter and sort observers
  const filteredObservers = observers
    .filter(observer => {
      if (filterStatus === 'all') return true;
      return observer.status === filterStatus;
    })
    .sort((a, b) => {
      switch (sortBy) {
        case 'name':
          return a.name.localeCompare(b.name);
        case 'station':
          return a.station.localeCompare(b.station);
        case 'incidents':
          return (b.incident_count || 0) - (a.incident_count || 0);
        case 'last_checkin':
        default:
          return new Date(b.last_checkin) - new Date(a.last_checkin);
      }
    });

  const getStatusConfig = (status) => {
    switch (status) {
      case 'checked_in':
        return {
          color: 'text-success',
          bgColor: 'bg-success',
          label: 'Checked In',
          icon: 'CheckCircle'
        };
      case 'in_transit':
        return {
          color: 'text-warning',
          bgColor: 'bg-warning',
          label: 'In Transit',
          icon: 'Navigation'
        };
      case 'emergency':
        return {
          color: 'text-error',
          bgColor: 'bg-error',
          label: 'Emergency',
          icon: 'AlertTriangle'
        };
      default:
        return {
          color: 'text-text-secondary',
          bgColor: 'bg-text-secondary',
          label: 'Unknown',
          icon: 'HelpCircle'
        };
    }
  };

  const getBatteryColor = (level) => {
    if (level > 50) return 'text-success';
    if (level > 30) return 'text-warning';
    return 'text-error';
  };

  const handleEmergencyBroadcast = () => {
    if (emergencyBroadcastMessage.trim()) {
      onEmergencyBroadcast?.(emergencyBroadcastMessage.trim());
      setEmergencyBroadcastMessage('');
      setShowEmergencyDialog(false);
      setAlertCount(prev => prev + 1);
    }
  };

  const handleObserverClick = (observer) => {
    setSelectedObserver(observer);
    onObserverSelect?.(observer);
  };

  // Update emergency alerts
  useEffect(() => {
    const emergencyObservers = observers.filter(o => o.status === 'emergency');
    if (emergencyObservers.length > 0) {
      setAlertCount(emergencyObservers.length);
    }
  }, [observers]);

  return (
    <div className="flex flex-col h-full bg-surface">
      {/* Header */}
      <div className="p-4 border-b border-border">
        <div className="flex items-center justify-between mb-4">
          <h3 className="text-lg font-semibold text-text-primary">Observer Status</h3>
          <Button
            onClick={() => setShowEmergencyDialog(true)}
            className="bg-error text-white hover:bg-error-700 text-sm px-3 py-1"
            size="sm"
          >
            <Icon name="AlertTriangle" size={14} className="mr-1" />
            Emergency
          </Button>
        </div>

        {/* Quick Stats */}
        <div className="grid grid-cols-2 gap-3 mb-4">
          <div className="bg-background p-3 rounded-lg">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-xs text-text-secondary">Checked In</p>
                <p className="text-lg font-semibold text-success">{stats.checked_in}</p>
              </div>
              <Icon name="CheckCircle" size={20} className="text-success" />
            </div>
          </div>
          
          <div className="bg-background p-3 rounded-lg">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-xs text-text-secondary">Incidents</p>
                <p className="text-lg font-semibold text-warning">{stats.incidents}</p>
              </div>
              <Icon name="AlertCircle" size={20} className="text-warning" />
            </div>
          </div>
          
          <div className="bg-background p-3 rounded-lg">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-xs text-text-secondary">Emergencies</p>
                <p className="text-lg font-semibold text-error">{stats.emergency}</p>
              </div>
              <Icon name="AlertTriangle" size={20} className="text-error" />
            </div>
          </div>
          
          <div className="bg-background p-3 rounded-lg">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-xs text-text-secondary">Low Battery</p>
                <p className="text-lg font-semibold text-warning">{stats.low_battery}</p>
              </div>
              <Icon name="Battery" size={20} className="text-warning" />
            </div>
          </div>
        </div>

        {/* Filters */}
        <div className="flex flex-col space-y-2">
          <select
            value={filterStatus}
            onChange={(e) => setFilterStatus(e.target.value)}
            className="text-xs border border-border rounded px-2 py-1 bg-background"
          >
            <option value="all">All Status</option>
            <option value="checked_in">Checked In</option>
            <option value="in_transit">In Transit</option>
            <option value="emergency">Emergency</option>
          </select>
          
          <select
            value={sortBy}
            onChange={(e) => setSortBy(e.target.value)}
            className="text-xs border border-border rounded px-2 py-1 bg-background"
          >
            <option value="last_checkin">Sort by Last Check-in</option>
            <option value="name">Sort by Name</option>
            <option value="station">Sort by Station</option>
            <option value="incidents">Sort by Incidents</option>
          </select>
        </div>
      </div>

      {/* Observer List */}
      <div className="flex-1 overflow-y-auto">
        <div className="p-4 space-y-3">
          {filteredObservers.map((observer) => {
            const statusConfig = getStatusConfig(observer.status);
            const isSelected = selectedObserver?.id === observer.id;
            
            return (
              <div
                key={observer.id}
                onClick={() => handleObserverClick(observer)}
                className={`p-3 rounded-lg border cursor-pointer transition-all duration-200 ${
                  isSelected
                    ? 'border-primary bg-primary-50' :'border-border hover:border-primary-200 hover:bg-surface-secondary'
                }`}
              >
                {/* Observer Header */}
                <div className="flex items-start justify-between mb-2">
                  <div className="flex items-center space-x-2">
                    <div className={`w-3 h-3 rounded-full ${statusConfig.bgColor}`}></div>
                    <h4 className="text-sm font-medium text-text-primary">
                      {observer.name}
                    </h4>
                  </div>
                  
                  <div className="flex items-center space-x-1">
                    {observer.incident_count > 0 && (
                      <span className="bg-warning text-white text-xs px-1.5 py-0.5 rounded-full">
                        {observer.incident_count}
                      </span>
                    )}
                    <Icon 
                      name={statusConfig.icon} 
                      size={14} 
                      className={statusConfig.color} 
                    />
                  </div>
                </div>

                {/* Station Info */}
                <div className="flex items-center space-x-1 mb-2">
                  <Icon name="MapPin" size={12} className="text-text-secondary" />
                  <span className="text-xs text-text-secondary">
                    {observer.station}
                  </span>
                </div>

                {/* Status and Battery */}
                <div className="flex items-center justify-between">
                  <div className="flex items-center space-x-2">
                    <span className={`text-xs font-medium ${statusConfig.color}`}>
                      {statusConfig.label}
                    </span>
                    <span className="text-xs text-text-tertiary">
                      {formatDistanceToNow(observer.last_checkin)} ago
                    </span>
                  </div>
                  
                  <div className="flex items-center space-x-1">
                    <Icon 
                      name="Battery" 
                      size={12} 
                      className={getBatteryColor(observer.battery_level)} 
                    />
                    <span className={`text-xs ${getBatteryColor(observer.battery_level)}`}>
                      {observer.battery_level}%
                    </span>
                  </div>
                </div>

                {/* Emergency Badge */}
                {observer.status === 'emergency' && (
                  <div className="mt-2 flex items-center space-x-1 text-error">
                    <Icon name="AlertTriangle" size={12} />
                    <span className="text-xs font-medium">EMERGENCY - Immediate Attention Required</span>
                  </div>
                )}
              </div>
            );
          })}

          {filteredObservers.length === 0 && (
            <div className="text-center py-8">
              <Icon name="Users" size={32} className="mx-auto mb-2 text-text-secondary opacity-50" />
              <p className="text-sm text-text-secondary">No observers found</p>
            </div>
          )}
        </div>
      </div>

      {/* Emergency Broadcast Dialog */}
      {showEmergencyDialog && (
        <div className="fixed inset-0 z-50 bg-black bg-opacity-50 flex items-center justify-center p-4">
          <div className="bg-surface rounded-lg shadow-xl w-full max-w-md">
            <div className="p-6">
              <div className="flex items-center space-x-2 mb-4">
                <Icon name="AlertTriangle" size={20} className="text-error" />
                <h3 className="text-lg font-semibold text-text-primary">Emergency Broadcast</h3>
              </div>
              
              <p className="text-sm text-text-secondary mb-4">
                Send an emergency message to all observers. This will trigger priority notifications.
              </p>
              
              <textarea
                value={emergencyBroadcastMessage}
                onChange={(e) => setEmergencyBroadcastMessage(e.target.value)}
                placeholder="Enter emergency message..."
                className="w-full p-3 border border-border rounded-lg text-sm resize-none h-24 focus:outline-none focus:ring-2 focus:ring-error focus:border-transparent"
              />
              
              <div className="flex items-center justify-end space-x-3 mt-6">
                <Button
                  variant="ghost"
                  onClick={() => setShowEmergencyDialog(false)}
                  className="text-text-secondary hover:text-text-primary"
                >
                  Cancel
                </Button>
                <Button
                  onClick={handleEmergencyBroadcast}
                  disabled={!emergencyBroadcastMessage.trim()}
                  className="bg-error text-white hover:bg-error-700 disabled:opacity-50"
                >
                  <Icon name="Send" size={16} className="mr-2" />
                  Send Emergency Alert
                </Button>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default ObserverStatusDashboard;