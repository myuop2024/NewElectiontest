// src/pages/live-communication-hub/components/EmergencyAlert.jsx
import React from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import Icon from 'components/AppIcon';
import Button from 'components/ui/Button';

const EmergencyAlert = ({ alert, onDismiss }) => {
  if (!alert) return null;

  const getSeverityConfig = (severity) => {
    switch (severity) {
      case 'critical':
        return {
          bgColor: 'bg-red-600',
          textColor: 'text-white',
          borderColor: 'border-red-600',
          icon: 'AlertTriangle'
        };
      case 'high':
        return {
          bgColor: 'bg-orange-500',
          textColor: 'text-white',
          borderColor: 'border-orange-500',
          icon: 'AlertCircle'
        };
      case 'medium':
        return {
          bgColor: 'bg-yellow-500',
          textColor: 'text-black',
          borderColor: 'border-yellow-500',
          icon: 'AlertTriangle'
        };
      case 'low':
      default:
        return {
          bgColor: 'bg-blue-500',
          textColor: 'text-white',
          borderColor: 'border-blue-500',
          icon: 'Info'
        };
    }
  };

  const config = getSeverityConfig(alert.severity);

  return (
    <AnimatePresence>
      <motion.div
        initial={{ opacity: 0, y: -100 }}
        animate={{ opacity: 1, y: 0 }}
        exit={{ opacity: 0, y: -100 }}
        className="fixed top-16 left-0 right-0 z-50 lg:left-64"
      >
        <div className={`mx-4 lg:mx-6 p-4 rounded-lg border-2 shadow-lg ${config.bgColor} ${config.borderColor}`}>
          <div className="flex items-start space-x-3">
            {/* Alert Icon */}
            <div className="flex-shrink-0">
              <Icon 
                name={config.icon} 
                size={24} 
                className={`${config.textColor} ${alert.severity === 'critical' ? 'animate-pulse' : ''}`} 
              />
            </div>
            
            {/* Alert Content */}
            <div className="flex-1 min-w-0">
              <div className="flex items-start justify-between">
                <div>
                  <h3 className={`text-lg font-bold ${config.textColor}`}>
                    {alert.title}
                  </h3>
                  <p className={`text-sm ${config.textColor} opacity-90 mt-1`}>
                    {alert.message}
                  </p>
                  
                  {alert.details && (
                    <div className="mt-2">
                      <p className={`text-xs ${config.textColor} opacity-75`}>
                        {alert.details}
                      </p>
                    </div>
                  )}
                  
                  {alert.actions && alert.actions.length > 0 && (
                    <div className="mt-3 flex flex-wrap gap-2">
                      {alert.actions.map((action, index) => (
                        <Button
                          key={index}
                          onClick={action.onClick}
                          size="sm"
                          className={`${config.textColor === 'text-white' ? 'bg-white/20 hover:bg-white/30 text-white' : 'bg-black/20 hover:bg-black/30 text-black'}`}
                        >
                          {action.icon && <Icon name={action.icon} size={14} className="mr-1" />}
                          {action.label}
                        </Button>
                      ))}
                    </div>
                  )}
                  
                  {alert.timestamp && (
                    <div className="mt-2">
                      <p className={`text-xs ${config.textColor} opacity-60`}>
                        {new Date(alert.timestamp).toLocaleString()}
                      </p>
                    </div>
                  )}
                </div>
                
                {/* Close Button */}
                <button
                  onClick={onDismiss}
                  className={`flex-shrink-0 p-1 rounded hover:bg-white/20 transition-colors ${config.textColor}`}
                >
                  <Icon name="X" size={20} />
                </button>
              </div>
            </div>
          </div>
          
          {/* Progress Bar for Auto-dismiss */}
          {alert.autoDismiss && (
            <motion.div
              initial={{ width: '100%' }}
              animate={{ width: '0%' }}
              transition={{ duration: alert.autoDismiss / 1000, ease: 'linear' }}
              className={`mt-3 h-1 ${config.textColor === 'text-white' ? 'bg-white/30' : 'bg-black/30'} rounded-full`}
              onAnimationComplete={onDismiss}
            />
          )}
        </div>
      </motion.div>
    </AnimatePresence>
  );
};

export default EmergencyAlert;