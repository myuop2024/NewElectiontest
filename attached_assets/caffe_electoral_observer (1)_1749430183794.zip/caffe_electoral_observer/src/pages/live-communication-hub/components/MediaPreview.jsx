// src/pages/live-communication-hub/components/MediaPreview.jsx
import React, { useState, useRef, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import Icon from 'components/AppIcon';
import Button from 'components/ui/Button';

const MediaPreview = ({ media, onClose }) => {
  const [isFullscreen, setIsFullscreen] = useState(false);
  const [zoom, setZoom] = useState(1);
  const [position, setPosition] = useState({ x: 0, y: 0 });
  const [isDragging, setIsDragging] = useState(false);
  const [dragStart, setDragStart] = useState({ x: 0, y: 0 });
  const [isPlaying, setIsPlaying] = useState(false);
  const [volume, setVolume] = useState(1);
  const [currentTime, setCurrentTime] = useState(0);
  const [duration, setDuration] = useState(0);
  const mediaRef = useRef(null);
  const containerRef = useRef(null);

  const isImage = media?.type?.startsWith('image/');
  const isVideo = media?.type?.startsWith('video/');
  const isAudio = media?.type?.startsWith('audio/');
  const isPdf = media?.type === 'application/pdf';
  const isDocument = media?.type?.includes('document') || media?.type?.includes('word');

  useEffect(() => {
    const handleKeyPress = (e) => {
      switch (e.key) {
        case 'Escape':
          onClose();
          break;
        case ' ':
          if (isVideo || isAudio) {
            e.preventDefault();
            togglePlayPause();
          }
          break;
        case 'f': case'F':
          toggleFullscreen();
          break;
        case '+': case'=':
          if (isImage) {
            e.preventDefault();
            handleZoom(zoom * 1.2);
          }
          break;
        case '-':
          if (isImage) {
            e.preventDefault();
            handleZoom(zoom / 1.2);
          }
          break;
        case '0':
          if (isImage) {
            resetZoom();
          }
          break;
      }
    };

    document.addEventListener('keydown', handleKeyPress);
    return () => document.removeEventListener('keydown', handleKeyPress);
  }, [zoom, isVideo, isAudio, isImage]);

  const toggleFullscreen = () => {
    if (!document.fullscreenElement) {
      containerRef.current?.requestFullscreen();
      setIsFullscreen(true);
    } else {
      document.exitFullscreen();
      setIsFullscreen(false);
    }
  };

  const handleZoom = (newZoom) => {
    const clampedZoom = Math.max(0.1, Math.min(5, newZoom));
    setZoom(clampedZoom);
  };

  const resetZoom = () => {
    setZoom(1);
    setPosition({ x: 0, y: 0 });
  };

  const handleMouseDown = (e) => {
    if (isImage && zoom > 1) {
      setIsDragging(true);
      setDragStart({
        x: e.clientX - position.x,
        y: e.clientY - position.y
      });
    }
  };

  const handleMouseMove = (e) => {
    if (isDragging && isImage && zoom > 1) {
      setPosition({
        x: e.clientX - dragStart.x,
        y: e.clientY - dragStart.y
      });
    }
  };

  const handleMouseUp = () => {
    setIsDragging(false);
  };

  const togglePlayPause = () => {
    if (mediaRef.current) {
      if (isPlaying) {
        mediaRef.current.pause();
      } else {
        mediaRef.current.play();
      }
      setIsPlaying(!isPlaying);
    }
  };

  const handleTimeUpdate = () => {
    if (mediaRef.current) {
      setCurrentTime(mediaRef.current.currentTime);
    }
  };

  const handleLoadedMetadata = () => {
    if (mediaRef.current) {
      setDuration(mediaRef.current.duration);
    }
  };

  const handleSeek = (e) => {
    if (mediaRef.current) {
      const rect = e.target.getBoundingClientRect();
      const percent = (e.clientX - rect.left) / rect.width;
      mediaRef.current.currentTime = percent * duration;
    }
  };

  const handleVolumeChange = (e) => {
    const newVolume = parseFloat(e.target.value);
    setVolume(newVolume);
    if (mediaRef.current) {
      mediaRef.current.volume = newVolume;
    }
  };

  const formatTime = (time) => {
    const minutes = Math.floor(time / 60);
    const seconds = Math.floor(time % 60);
    return `${minutes}:${seconds.toString().padStart(2, '0')}`;
  };

  const downloadMedia = () => {
    const link = document.createElement('a');
    link.href = media.url;
    link.download = media.name || 'download';
    link.click();
  };

  const shareMedia = async () => {
    if (navigator.share) {
      try {
        await navigator.share({
          title: media.name,
          url: media.url
        });
      } catch (error) {
        console.error('Error sharing:', error);
      }
    } else {
      // Fallback: copy URL to clipboard
      navigator.clipboard.writeText(media.url);
    }
  };

  if (!media) return null;

  return (
    <AnimatePresence>
      <motion.div
        ref={containerRef}
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        exit={{ opacity: 0 }}
        className="fixed inset-0 z-50 bg-black bg-opacity-95 flex flex-col"
        onMouseMove={handleMouseMove}
        onMouseUp={handleMouseUp}
        onMouseLeave={handleMouseUp}
      >
        {/* Header */}
        <div className="flex items-center justify-between p-4 bg-black bg-opacity-50 text-white">
          <div className="flex items-center space-x-3">
            <h3 className="text-lg font-medium truncate">
              {media.name || 'Media Preview'}
            </h3>
            <span className="text-sm text-gray-300">
              {media.size && `${(media.size / 1024 / 1024).toFixed(1)} MB`}
            </span>
          </div>

          <div className="flex items-center space-x-2">
            <Button
              variant="ghost"
              size="sm"
              onClick={downloadMedia}
              className="text-white hover:bg-white hover:bg-opacity-20"
              title="Download"
            >
              <Icon name="Download" size={18} />
            </Button>
            
            <Button
              variant="ghost"
              size="sm"
              onClick={shareMedia}
              className="text-white hover:bg-white hover:bg-opacity-20"
              title="Share"
            >
              <Icon name="Share2" size={18} />
            </Button>
            
            {(isImage || isVideo) && (
              <Button
                variant="ghost"
                size="sm"
                onClick={toggleFullscreen}
                className="text-white hover:bg-white hover:bg-opacity-20"
                title="Toggle Fullscreen (F)"
              >
                <Icon name={isFullscreen ? "Minimize" : "Maximize"} size={18} />
              </Button>
            )}
            
            <Button
              variant="ghost"
              size="sm"
              onClick={onClose}
              className="text-white hover:bg-white hover:bg-opacity-20"
              title="Close (Esc)"
            >
              <Icon name="X" size={18} />
            </Button>
          </div>
        </div>

        {/* Content */}
        <div className="flex-1 flex items-center justify-center p-4">
          {/* Image Preview */}
          {isImage && (
            <div className="relative max-w-full max-h-full">
              <img
                src={media.url}
                alt={media.name}
                className="max-w-full max-h-full object-contain cursor-move"
                style={{
                  transform: `scale(${zoom}) translate(${position.x}px, ${position.y}px)`
                }}
                onMouseDown={handleMouseDown}
                draggable={false}
              />
              
              {/* Image Controls */}
              <div className="absolute bottom-4 left-1/2 transform -translate-x-1/2 bg-black bg-opacity-50 rounded-lg p-2">
                <div className="flex items-center space-x-2 text-white">
                  <Button
                    variant="ghost"
                    size="sm"
                    onClick={() => handleZoom(zoom / 1.2)}
                    className="text-white hover:bg-white hover:bg-opacity-20"
                    title="Zoom Out (-)"
                  >
                    <Icon name="ZoomOut" size={16} />
                  </Button>
                  
                  <span className="text-sm min-w-[4rem] text-center">
                    {Math.round(zoom * 100)}%
                  </span>
                  
                  <Button
                    variant="ghost"
                    size="sm"
                    onClick={() => handleZoom(zoom * 1.2)}
                    className="text-white hover:bg-white hover:bg-opacity-20"
                    title="Zoom In (+)"
                  >
                    <Icon name="ZoomIn" size={16} />
                  </Button>
                  
                  <Button
                    variant="ghost"
                    size="sm"
                    onClick={resetZoom}
                    className="text-white hover:bg-white hover:bg-opacity-20"
                    title="Reset Zoom (0)"
                  >
                    <Icon name="RotateCcw" size={16} />
                  </Button>
                </div>
              </div>
            </div>
          )}

          {/* Video Preview */}
          {isVideo && (
            <div className="relative max-w-full max-h-full">
              <video
                ref={mediaRef}
                src={media.url}
                className="max-w-full max-h-full"
                onTimeUpdate={handleTimeUpdate}
                onLoadedMetadata={handleLoadedMetadata}
                onPlay={() => setIsPlaying(true)}
                onPause={() => setIsPlaying(false)}
               
              />
              
              {/* Video Controls */}
              <div className="absolute bottom-4 left-4 right-4 bg-black bg-opacity-50 rounded-lg p-3">
                <div className="flex items-center space-x-3 text-white">
                  <Button
                    variant="ghost"
                    size="sm"
                    onClick={togglePlayPause}
                    className="text-white hover:bg-white hover:bg-opacity-20"
                    title="Play/Pause (Space)"
                  >
                    <Icon name={isPlaying ? "Pause" : "Play"} size={16} />
                  </Button>
                  
                  <span className="text-sm">
                    {formatTime(currentTime)}
                  </span>
                  
                  <div 
                    className="flex-1 h-2 bg-gray-600 rounded cursor-pointer"
                    onClick={handleSeek}
                  >
                    <div 
                      className="h-full bg-white rounded"
                      style={{ width: `${(currentTime / duration) * 100}%` }}
                    />
                  </div>
                  
                  <span className="text-sm">
                    {formatTime(duration)}
                  </span>
                  
                  <div className="flex items-center space-x-2">
                    <Icon name="Volume2" size={16} />
                    <input
                      type="range"
                      min="0"
                      max="1"
                      step="0.1"
                      value={volume}
                      onChange={handleVolumeChange}
                      className="w-16"
                    />
                  </div>
                </div>
              </div>
            </div>
          )}

          {/* Audio Preview */}
          {isAudio && (
            <div className="bg-gray-800 rounded-lg p-8 text-white max-w-md w-full">
              <div className="text-center mb-6">
                <Icon name="Music" size={48} className="mx-auto mb-4 text-gray-400" />
                <h3 className="text-lg font-medium">{media.name}</h3>
              </div>
              
              <audio
                ref={mediaRef}
                src={media.url}
                onTimeUpdate={handleTimeUpdate}
                onLoadedMetadata={handleLoadedMetadata}
                onPlay={() => setIsPlaying(true)}
                onPause={() => setIsPlaying(false)}
              />
              
              <div className="space-y-4">
                <div className="flex items-center justify-center space-x-4">
                  <Button
                    variant="ghost"
                    size="lg"
                    onClick={togglePlayPause}
                    className="text-white hover:bg-white hover:bg-opacity-20 w-12 h-12 rounded-full"
                  >
                    <Icon name={isPlaying ? "Pause" : "Play"} size={24} />
                  </Button>
                </div>
                
                <div className="flex items-center space-x-3">
                  <span className="text-sm">
                    {formatTime(currentTime)}
                  </span>
                  
                  <div 
                    className="flex-1 h-2 bg-gray-600 rounded cursor-pointer"
                    onClick={handleSeek}
                  >
                    <div 
                      className="h-full bg-white rounded"
                      style={{ width: `${(currentTime / duration) * 100}%` }}
                    />
                  </div>
                  
                  <span className="text-sm">
                    {formatTime(duration)}
                  </span>
                </div>
                
                <div className="flex items-center justify-center space-x-2">
                  <Icon name="Volume2" size={16} />
                  <input
                    type="range"
                    min="0"
                    max="1"
                    step="0.1"
                    value={volume}
                    onChange={handleVolumeChange}
                    className="w-24"
                  />
                </div>
              </div>
            </div>
          )}

          {/* PDF/Document Preview */}
          {(isPdf || isDocument) && (
            <div className="bg-white rounded-lg p-8 max-w-2xl w-full h-full max-h-[80vh] overflow-auto">
              {isPdf ? (
                <iframe
                  src={media.url}
                  className="w-full h-full min-h-[600px] border-0"
                  title={media.name}
                />
              ) : (
                <div className="text-center">
                  <Icon name="FileText" size={48} className="mx-auto mb-4 text-gray-400" />
                  <h3 className="text-lg font-medium text-gray-800 mb-4">{media.name}</h3>
                  <p className="text-gray-600 mb-6">Document preview not available</p>
                  <Button onClick={downloadMedia} className="bg-primary text-white">
                    <Icon name="Download" size={16} className="mr-2" />
                    Download to view
                  </Button>
                </div>
              )}
            </div>
          )}
        </div>

        {/* Keyboard Shortcuts Info */}
        <div className="absolute bottom-4 left-4 bg-black bg-opacity-50 rounded-lg p-2 text-white text-xs">
          <div>Press <kbd className="bg-gray-700 px-1 rounded">Esc</kbd> to close</div>
          {isImage && (
            <>
              <div><kbd className="bg-gray-700 px-1 rounded">+/-</kbd> to zoom</div>
              <div><kbd className="bg-gray-700 px-1 rounded">0</kbd> to reset</div>
            </>
          )}
          {(isVideo || isAudio) && (
            <div><kbd className="bg-gray-700 px-1 rounded">Space</kbd> to play/pause</div>
          )}
          <div><kbd className="bg-gray-700 px-1 rounded">F</kbd> for fullscreen</div>
        </div>
      </motion.div>
    </AnimatePresence>
  );
};

export default MediaPreview;