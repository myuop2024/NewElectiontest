// src/pages/admin-control-center/components/PollingStationOverview.jsx
import React, { useState, useEffect } from 'react';
import Icon from 'components/AppIcon';
import Button from 'components/ui/Button';
import Input from 'components/ui/Input';

const PollingStationOverview = ({ stations, observers, onRefresh }) => {
  const [searchTerm, setSearchTerm] = useState('');
  const [filterParish, setFilterParish] = useState('all');
  const [filterStatus, setFilterStatus] = useState('all');
  const [filteredStations, setFilteredStations] = useState([]);
  const [selectedStation, setSelectedStation] = useState(null);
  const [isDetailsModalOpen, setIsDetailsModalOpen] = useState(false);
  
  // Calculate statistics
  const totalStations = stations.length;
  const stationsWithObservers = stations.filter(s => s.assignedObservers?.length > 0).length;
  const stationsWithIssues = stations.filter(s => s.incidentsReported > 0).length;
  const coveragePercentage = totalStations > 0 ? Math.round((stationsWithObservers / totalStations) * 100) : 0;
  
  // Get unique parishes for filter
  const parishes = ['all', ...new Set(stations.map(station => station.parish))];

  // Apply filters whenever search term, parish filter, or status filter changes
  useEffect(() => {
    let filtered = [...stations];
    
    // Apply search filter
    if (searchTerm) {
      const lowercasedSearch = searchTerm.toLowerCase();
      filtered = filtered.filter(station => 
        station.id.toLowerCase().includes(lowercasedSearch) ||
        station.name.toLowerCase().includes(lowercasedSearch) ||
        station.address.toLowerCase().includes(lowercasedSearch)
      );
    }
    
    // Apply parish filter
    if (filterParish !== 'all') {
      filtered = filtered.filter(station => station.parish === filterParish);
    }
    
    // Apply status filter
    if (filterStatus !== 'all') {
      filtered = filtered.filter(station => station.status === filterStatus);
    }
    
    setFilteredStations(filtered);
  }, [stations, searchTerm, filterParish, filterStatus]);

  const handleSearchChange = (e) => {
    setSearchTerm(e.target.value);
  };

  const handleParishFilterChange = (e) => {
    setFilterParish(e.target.value);
  };

  const handleStatusFilterChange = (e) => {
    setFilterStatus(e.target.value);
  };

  const handleStationSelect = (station) => {
    setSelectedStation(station);
    setIsDetailsModalOpen(true);
  };

  const handleCloseModal = () => {
    setIsDetailsModalOpen(false);
    setSelectedStation(null);
  };

  // Get assigned observers for a station
  const getAssignedObservers = (stationId) => {
    return observers.filter(obs => obs.pollingStation === stationId);
  };

  // Render status badge with appropriate color
  const renderStatusBadge = (status) => {
    const statusConfig = {
      'operational': { color: 'bg-success text-white', icon: 'CheckCircle' },
      'issue-reported': { color: 'bg-warning text-primary-foreground', icon: 'AlertTriangle' },
      'non-operational': { color: 'bg-error text-white', icon: 'XCircle' }
    };

    const config = statusConfig[status] || { color: 'bg-gray-500 text-white', icon: 'HelpCircle' };

    return (
      <span className={`inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium ${config.color}`}>
        <Icon name={config.icon} size={12} className="mr-1" />
        {status.split('-').map(word => word.charAt(0).toUpperCase() + word.slice(1)).join(' ')}
      </span>
    );
  };

  return (
    <div className="p-6">
      <div className="flex flex-col lg:flex-row lg:items-center lg:justify-between mb-6">
        <h2 className="text-xl font-semibold text-text-primary mb-4 lg:mb-0">
          Polling Station Overview
        </h2>
        <div className="flex flex-col sm:flex-row space-y-3 sm:space-y-0 sm:space-x-3">
          <Button 
            variant="primary" 
            size="sm"
            iconName="Plus"
          >
            Add Station
          </Button>
          <Button 
            variant="secondary" 
            size="sm"
            iconName="FileText"
          >
            Export Stations
          </Button>
        </div>
      </div>

      {/* Statistics Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4 mb-6">
        <div className="bg-surface border border-border rounded-lg p-4">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm text-text-secondary">Total Stations</p>
              <p className="text-2xl font-bold text-text-primary">{totalStations}</p>
            </div>
            <div className="w-10 h-10 bg-primary-50 rounded-full flex items-center justify-center">
              <Icon name="MapPin" size={20} className="text-primary" />
            </div>
          </div>
        </div>

        <div className="bg-surface border border-border rounded-lg p-4">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm text-text-secondary">Stations with Observers</p>
              <p className="text-2xl font-bold text-text-primary">{stationsWithObservers}</p>
            </div>
            <div className="w-10 h-10 bg-success-50 rounded-full flex items-center justify-center">
              <Icon name="Users" size={20} className="text-success" />
            </div>
          </div>
        </div>

        <div className="bg-surface border border-border rounded-lg p-4">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm text-text-secondary">Coverage</p>
              <p className="text-2xl font-bold text-text-primary">{coveragePercentage}%</p>
            </div>
            <div className="w-10 h-10 bg-info-50 rounded-full flex items-center justify-center">
              <Icon name="PieChart" size={20} className="text-accent" />
            </div>
          </div>
        </div>

        <div className="bg-surface border border-border rounded-lg p-4">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm text-text-secondary">Stations with Issues</p>
              <p className="text-2xl font-bold text-text-primary">{stationsWithIssues}</p>
            </div>
            <div className="w-10 h-10 bg-warning-50 rounded-full flex items-center justify-center">
              <Icon name="AlertTriangle" size={20} className="text-warning" />
            </div>
          </div>
        </div>
      </div>

      {/* Filters */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-6">
        <div>
          <label htmlFor="search-station" className="block text-sm font-medium text-text-secondary mb-1">
            Search Stations
          </label>
          <div className="relative">
            <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
              <Icon name="Search" size={16} className="text-text-secondary" />
            </div>
            <Input
              id="search-station"
              type="text"
              placeholder="ID, Name or Address"
              value={searchTerm}
              onChange={handleSearchChange}
              className="pl-10"
            />
          </div>
        </div>

        <div>
          <label htmlFor="parish-filter" className="block text-sm font-medium text-text-secondary mb-1">
            Filter by Parish
          </label>
          <select
            id="parish-filter"
            value={filterParish}
            onChange={handleParishFilterChange}
            className="w-full h-10 rounded-md border border-input bg-background px-3 py-2 text-base ring-offset-background focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2 md:text-sm"
          >
            {parishes.map(parish => (
              <option key={parish} value={parish}>
                {parish === 'all' ? 'All Parishes' : parish}
              </option>
            ))}
          </select>
        </div>

        <div>
          <label htmlFor="status-filter" className="block text-sm font-medium text-text-secondary mb-1">
            Filter by Status
          </label>
          <select
            id="status-filter"
            value={filterStatus}
            onChange={handleStatusFilterChange}
            className="w-full h-10 rounded-md border border-input bg-background px-3 py-2 text-base ring-offset-background focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2 md:text-sm"
          >
            <option value="all">All Statuses</option>
            <option value="operational">Operational</option>
            <option value="issue-reported">Issue Reported</option>
            <option value="non-operational">Non-operational</option>
          </select>
        </div>
      </div>

      {/* Stations Table */}
      <div className="overflow-x-auto bg-surface border border-border rounded-lg">
        <table className="min-w-full divide-y divide-border">
          <thead>
            <tr>
              <th className="px-6 py-3 bg-surface-secondary text-left text-xs font-medium text-text-secondary uppercase tracking-wider">
                Station ID
              </th>
              <th className="px-6 py-3 bg-surface-secondary text-left text-xs font-medium text-text-secondary uppercase tracking-wider">
                Name & Address
              </th>
              <th className="px-6 py-3 bg-surface-secondary text-left text-xs font-medium text-text-secondary uppercase tracking-wider">
                Parish
              </th>
              <th className="px-6 py-3 bg-surface-secondary text-left text-xs font-medium text-text-secondary uppercase tracking-wider">
                Expected Voters
              </th>
              <th className="px-6 py-3 bg-surface-secondary text-left text-xs font-medium text-text-secondary uppercase tracking-wider">
                Assigned Observers
              </th>
              <th className="px-6 py-3 bg-surface-secondary text-left text-xs font-medium text-text-secondary uppercase tracking-wider">
                Status
              </th>
              <th className="px-6 py-3 bg-surface-secondary text-right text-xs font-medium text-text-secondary uppercase tracking-wider">
                Actions
              </th>
            </tr>
          </thead>
          <tbody className="bg-surface divide-y divide-border">
            {filteredStations.length > 0 ? (
              filteredStations.map((station) => {
                const assignedObservers = getAssignedObservers(station.id);
                return (
                  <tr key={station.id} className="hover:bg-surface-secondary transition-colors duration-150">
                    <td className="px-6 py-4 whitespace-nowrap text-sm font-mono text-text-secondary">
                      {station.id}
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap">
                      <div>
                        <p className="text-sm font-medium text-text-primary">{station.name}</p>
                        <p className="text-xs text-text-secondary">{station.address}</p>
                      </div>
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap text-sm text-text-primary">
                      {station.parish}
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap text-sm text-text-primary">
                      {station.expectedVoters.toLocaleString()}
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap">
                      {assignedObservers.length > 0 ? (
                        <div className="flex items-center">
                          <div className="flex -space-x-2 mr-2">
                            {assignedObservers.slice(0, 3).map((observer, i) => (
                              <div key={observer.id} className="w-6 h-6 rounded-full bg-primary-100 border-2 border-surface flex items-center justify-center overflow-hidden" style={{ zIndex: 10 - i }}>
                                <Icon name="User" size={12} className="text-primary-600" />
                              </div>
                            ))}
                            {assignedObservers.length > 3 && (
                              <div className="w-6 h-6 rounded-full bg-surface-secondary border-2 border-surface flex items-center justify-center text-xs font-medium" style={{ zIndex: 7 }}>
                                +{assignedObservers.length - 3}
                              </div>
                            )}
                          </div>
                          <span className="text-sm text-text-secondary">
                            {assignedObservers.length} {assignedObservers.length === 1 ? 'observer' : 'observers'}
                          </span>
                        </div>
                      ) : (
                        <span className="text-sm text-text-secondary">No observers assigned</span>
                      )}
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap">
                      {renderStatusBadge(station.status)}
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap text-sm text-right">
                      <div className="flex justify-end space-x-2">
                        <Button
                          size="xs"
                          variant="ghost"
                          iconName="Info"
                          onClick={() => handleStationSelect(station)}
                          aria-label="View station details"
                        />
                        <Button
                          size="xs"
                          variant="ghost"
                          iconName="Edit"
                          aria-label="Edit station"
                        />
                        <Button
                          size="xs"
                          variant="ghost"
                          iconName="UserPlus"
                          aria-label="Assign observers"
                        />
                      </div>
                    </td>
                  </tr>
                );
              })
            ) : (
              <tr>
                <td colSpan="7" className="px-6 py-12 text-center">
                  <Icon name="Search" size={24} className="mx-auto mb-3 text-text-secondary" />
                  <p className="text-text-secondary">No polling stations found with the current filters</p>
                  <Button
                    variant="ghost"
                    size="sm"
                    onClick={() => {
                      setSearchTerm('');
                      setFilterParish('all');
                      setFilterStatus('all');
                    }}
                    className="mt-2"
                  >
                    Clear Filters
                  </Button>
                </td>
              </tr>
            )}
          </tbody>
        </table>
      </div>

      {/* Pagination */}
      <div className="flex items-center justify-between mt-6">
        <div className="text-sm text-text-secondary">
          Showing <span className="font-medium">{filteredStations.length}</span> of <span className="font-medium">{stations.length}</span> stations
        </div>
        <div className="flex items-center space-x-2">
          <Button
            variant="outline"
            size="sm"
            iconName="ChevronLeft"
            disabled
          >
            Previous
          </Button>
          <Button
            variant="outline"
            size="sm"
            iconName="ChevronRight"
            iconPosition="right"
            disabled
          >
            Next
          </Button>
        </div>
      </div>

      {/* Station Details Modal */}
      {isDetailsModalOpen && selectedStation && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-4">
          <div className="bg-surface rounded-lg shadow-elevation-3 max-w-3xl w-full max-h-[90vh] overflow-y-auto">
            <div className="flex items-center justify-between p-6 border-b border-border">
              <h3 className="text-lg font-semibold text-text-primary">Polling Station Details</h3>
              <Button
                variant="ghost"
                size="sm"
                iconName="X"
                onClick={handleCloseModal}
                aria-label="Close modal"
              />
            </div>
            <div className="p-6">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                {/* Station Info */}
                <div className="space-y-4">
                  <div>
                    <h4 className="text-base font-semibold text-text-primary mb-2 flex items-center">
                      <Icon name="Info" size={16} className="mr-2" />
                      Station Information
                    </h4>
                    <div className="space-y-2">
                      <div className="flex justify-between">
                        <span className="text-sm text-text-secondary">Station ID:</span>
                        <span className="text-sm font-medium text-text-primary">{selectedStation.id}</span>
                      </div>
                      <div className="flex justify-between">
                        <span className="text-sm text-text-secondary">Name:</span>
                        <span className="text-sm font-medium text-text-primary">{selectedStation.name}</span>
                      </div>
                      <div className="flex justify-between">
                        <span className="text-sm text-text-secondary">Parish:</span>
                        <span className="text-sm font-medium text-text-primary">{selectedStation.parish}</span>
                      </div>
                      <div className="flex justify-between">
                        <span className="text-sm text-text-secondary">Address:</span>
                        <span className="text-sm font-medium text-text-primary">{selectedStation.address}</span>
                      </div>
                      <div className="flex justify-between">
                        <span className="text-sm text-text-secondary">Expected Voters:</span>
                        <span className="text-sm font-medium text-text-primary">{selectedStation.expectedVoters.toLocaleString()}</span>
                      </div>
                      <div className="flex justify-between">
                        <span className="text-sm text-text-secondary">Status:</span>
                        <span>{renderStatusBadge(selectedStation.status)}</span>
                      </div>
                    </div>
                  </div>

                  {/* GPS Coordinates */}
                  <div>
                    <h4 className="text-base font-semibold text-text-primary mb-2 flex items-center">
                      <Icon name="MapPin" size={16} className="mr-2" />
                      GPS Location
                    </h4>
                    <div className="space-y-2">
                      <div className="flex justify-between">
                        <span className="text-sm text-text-secondary">Latitude:</span>
                        <span className="text-sm font-medium text-text-primary">{selectedStation.gpsCoordinates?.lat || 'N/A'}</span>
                      </div>
                      <div className="flex justify-between">
                        <span className="text-sm text-text-secondary">Longitude:</span>
                        <span className="text-sm font-medium text-text-primary">{selectedStation.gpsCoordinates?.lng || 'N/A'}</span>
                      </div>
                    </div>
                    <div className="mt-3">
                      <Button
                        variant="outline"
                        size="sm"
                        iconName="ExternalLink"
                        className="w-full"
                      >
                        View on Map
                      </Button>
                    </div>
                  </div>

                  {/* Incidents */}
                  <div>
                    <h4 className="text-base font-semibold text-text-primary mb-2 flex items-center">
                      <Icon name="AlertTriangle" size={16} className="mr-2" />
                      Incident Reports
                    </h4>
                    {selectedStation.incidentsReported > 0 ? (
                      <div className="p-3 bg-warning-50 border border-warning-200 rounded-lg">
                        <div className="flex items-center">
                          <Icon name="AlertTriangle" size={16} className="text-warning mr-2" />
                          <span className="text-sm font-medium text-text-primary">
                            {selectedStation.incidentsReported} {selectedStation.incidentsReported === 1 ? 'incident' : 'incidents'} reported
                          </span>
                        </div>
                        <Button
                          variant="ghost"
                          size="sm"
                          className="w-full mt-2"
                        >
                          View Incident Details
                        </Button>
                      </div>
                    ) : (
                      <div className="p-3 bg-success-50 border border-success-200 rounded-lg">
                        <div className="flex items-center">
                          <Icon name="CheckCircle" size={16} className="text-success mr-2" />
                          <span className="text-sm font-medium text-text-primary">No incidents reported</span>
                        </div>
                      </div>
                    )}
                  </div>
                </div>

                {/* Assigned Observers */}
                <div>
                  <h4 className="text-base font-semibold text-text-primary mb-3 flex items-center">
                    <Icon name="Users" size={16} className="mr-2" />
                    Assigned Observers
                  </h4>
                  
                  {getAssignedObservers(selectedStation.id).length > 0 ? (
                    <div className="space-y-3">
                      {getAssignedObservers(selectedStation.id).map(observer => (
                        <div key={observer.id} className="p-3 bg-surface-secondary border border-border rounded-lg">
                          <div className="flex items-center justify-between">
                            <div className="flex items-center">
                              <div className="w-8 h-8 bg-primary-100 rounded-full flex items-center justify-center mr-3">
                                <Icon name="User" size={16} className="text-primary-600" />
                              </div>
                              <div>
                                <p className="text-sm font-medium text-text-primary">{observer.name}</p>
                                <p className="text-xs text-text-secondary">{observer.role.replace(/-/g, ' ')} • {observer.id}</p>
                              </div>
                            </div>
                            <div>
                              {observer.status === 'active' ? (
                                <span className="inline-flex items-center px-2 py-0.5 rounded-full text-xs font-medium bg-success text-white">
                                  <Icon name="CheckCircle" size={10} className="mr-1" />
                                  Active
                                </span>
                              ) : (
                                <span className="inline-flex items-center px-2 py-0.5 rounded-full text-xs font-medium bg-gray-500 text-white">
                                  <Icon name="XCircle" size={10} className="mr-1" />
                                  Inactive
                                </span>
                              )}
                            </div>
                          </div>
                          <div className="flex mt-2 space-x-2">
                            <Button
                              variant="ghost"
                              size="xs"
                              iconName="MessageSquare"
                            >
                              Message
                            </Button>
                            <Button
                              variant="ghost"
                              size="xs"
                              iconName="FileText"
                            >
                              View Reports
                            </Button>
                          </div>
                        </div>
                      ))}
                      <div className="mt-3">
                        <Button
                          variant="outline"
                          size="sm"
                          iconName="UserPlus"
                          className="w-full"
                        >
                          Assign Additional Observers
                        </Button>
                      </div>
                    </div>
                  ) : (
                    <div className="p-6 bg-surface-secondary border border-border rounded-lg text-center">
                      <Icon name="UserX" size={24} className="mx-auto mb-3 text-text-secondary" />
                      <p className="text-sm text-text-secondary mb-3">No observers assigned to this polling station</p>
                      <Button
                        variant="primary"
                        size="sm"
                        iconName="UserPlus"
                      >
                        Assign Observers
                      </Button>
                    </div>
                  )}
                  
                  <div className="mt-4 pt-4 border-t border-border">
                    <Button
                      variant="outline"
                      size="sm"
                      iconName="Edit"
                      className="w-full"
                    >
                      Edit Station Details
                    </Button>
                  </div>
                </div>
              </div>
            </div>
            <div className="flex justify-end p-6 border-t border-border bg-surface-secondary">
              <Button
                variant="primary"
                size="sm"
                onClick={handleCloseModal}
              >
                Close
              </Button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default PollingStationOverview;