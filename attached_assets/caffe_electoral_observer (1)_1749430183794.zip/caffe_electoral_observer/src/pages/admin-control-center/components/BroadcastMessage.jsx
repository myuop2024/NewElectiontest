// src/pages/admin-control-center/components/BroadcastMessage.jsx
import React, { useState } from 'react';
import Icon from 'components/AppIcon';
import Button from 'components/ui/Button';
import Input from 'components/ui/Input';

const BroadcastMessage = ({ observers }) => {
  const [messageType, setMessageType] = useState('announcement');
  const [priority, setPriority] = useState('normal');
  const [recipients, setRecipients] = useState({ type: 'all', roles: [], parishes: [] });
  const [message, setMessage] = useState('');
  const [title, setTitle] = useState('');
  const [attachmentType, setAttachmentType] = useState('none'); // none, image, document, location
  const [deliveryMethod, setDeliveryMethod] = useState(['app']); // app, sms, email
  const [scheduleSend, setScheduleSend] = useState(false);
  const [scheduleTime, setScheduleTime] = useState('');
  const [isSending, setIsSending] = useState(false);
  const [showConfirmation, setShowConfirmation] = useState(false);

  // Message type options
  const messageTypes = [
    { id: 'announcement', label: 'Announcement', icon: 'Bell', description: 'General announcements and updates' },
    { id: 'alert', label: 'Alert', icon: 'AlertTriangle', description: 'Important alerts requiring attention' },
    { id: 'instruction', label: 'Instruction', icon: 'FileText', description: 'Specific instructions or procedures' },
    { id: 'emergency', label: 'Emergency', icon: 'AlertOctagon', description: 'Critical emergency communications' }
  ];

  // Priority options
  const priorityOptions = [
    { id: 'low', label: 'Low', color: 'bg-info-100 text-info-700' },
    { id: 'normal', label: 'Normal', color: 'bg-primary-100 text-primary-700' },
    { id: 'high', label: 'High', color: 'bg-warning-100 text-warning-700' },
    { id: 'urgent', label: 'Urgent', color: 'bg-error-100 text-error-700' }
  ];

  // Get unique roles and parishes from observers
  const roles = [...new Set(observers.map(o => o.role))];
  const parishes = [...new Set(observers.map(o => o.parish))];

  // Handle checkbox changes for delivery methods
  const handleDeliveryMethodChange = (method) => {
    if (deliveryMethod.includes(method)) {
      setDeliveryMethod(deliveryMethod.filter(m => m !== method));
    } else {
      setDeliveryMethod([...deliveryMethod, method]);
    }
  };

  // Handle recipient type change
  const handleRecipientTypeChange = (type) => {
    setRecipients({ ...recipients, type });
  };

  // Handle role selection
  const handleRoleChange = (role) => {
    const updatedRoles = recipients.roles.includes(role)
      ? recipients.roles.filter(r => r !== role)
      : [...recipients.roles, role];
    setRecipients({ ...recipients, roles: updatedRoles });
  };

  // Handle parish selection
  const handleParishChange = (parish) => {
    const updatedParishes = recipients.parishes.includes(parish)
      ? recipients.parishes.filter(p => p !== parish)
      : [...recipients.parishes, parish];
    setRecipients({ ...recipients, parishes: updatedParishes });
  };

  // Get estimated recipient count
  const getRecipientCount = () => {
    if (recipients.type === 'all') {
      return observers.length;
    }

    if (recipients.type === 'role' && recipients.roles.length > 0) {
      return observers.filter(o => recipients.roles.includes(o.role)).length;
    }

    if (recipients.type === 'parish' && recipients.parishes.length > 0) {
      return observers.filter(o => recipients.parishes.includes(o.parish)).length;
    }

    return 0;
  };

  // Handle message send
  const handleSendMessage = () => {
    if (scheduleSend && !scheduleTime) {
      alert('Please select a schedule time');
      return;
    }

    setShowConfirmation(true);
  };

  // Confirm message send
  const confirmSend = () => {
    setIsSending(true);
    setShowConfirmation(false);

    // Simulate sending process
    setTimeout(() => {
      setIsSending(false);
      alert(`Message ${scheduleSend ? 'scheduled' : 'sent'} to ${getRecipientCount()} recipients.`);
      
      // Reset form in a real app
      // resetForm();
    }, 2000);
  };

  // Function to reset the form (not used yet)
  const resetForm = () => {
    setMessageType('announcement');
    setPriority('normal');
    setRecipients({ type: 'all', roles: [], parishes: [] });
    setMessage('');
    setTitle('');
    setAttachmentType('none');
    setDeliveryMethod(['app']);
    setScheduleSend(false);
    setScheduleTime('');
  };

  return (
    <div className="p-6">
      <div className="flex flex-col lg:flex-row lg:items-center lg:justify-between mb-6">
        <h2 className="text-xl font-semibold text-text-primary mb-4 lg:mb-0">
          Broadcast Message
        </h2>
        <div className="flex flex-col sm:flex-row space-y-3 sm:space-y-0 sm:space-x-3">
          <Button 
            variant="outline" 
            size="sm"
            iconName="MessageSquare"
          >
            Message History
          </Button>
          <Button 
            variant="outline" 
            size="sm"
            iconName="Settings"
          >
            Notification Settings
          </Button>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Left Column - Message Composer */}
        <div className="lg:col-span-2 space-y-6">
          {/* Message Type */}
          <div className="bg-surface border border-border rounded-lg overflow-hidden">
            <div className="p-4 border-b border-border bg-surface-secondary">
              <h3 className="text-base font-semibold text-text-primary flex items-center">
                <Icon name="MessageCircle" size={16} className="mr-2" />
                Message Type & Priority
              </h3>
            </div>
            <div className="p-4">
              <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3 mb-4">
                {messageTypes.map(type => (
                  <div 
                    key={type.id}
                    onClick={() => setMessageType(type.id)}
                    className={`p-3 border rounded-lg cursor-pointer transition-colors duration-150 ${messageType === type.id 
                      ? 'border-primary bg-primary-50' :'border-border bg-surface hover:bg-surface-secondary'
                    }`}
                  >
                    <div className="flex items-center">
                      <div className={`w-8 h-8 rounded-full flex items-center justify-center ${messageType === type.id ? 'bg-primary text-white' : 'bg-surface-secondary text-text-secondary'}`}>
                        <Icon name={type.icon} size={16} />
                      </div>
                      <p className={`ml-2 text-sm font-medium ${messageType === type.id ? 'text-primary' : 'text-text-primary'}`}>
                        {type.label}
                      </p>
                    </div>
                    <p className="text-xs text-text-secondary mt-2">{type.description}</p>
                  </div>
                ))}
              </div>

              <div className="mt-4">
                <label className="block text-sm font-medium text-text-secondary mb-2">
                  Message Priority
                </label>
                <div className="flex flex-wrap gap-2">
                  {priorityOptions.map(option => (
                    <button
                      key={option.id}
                      type="button"
                      onClick={() => setPriority(option.id)}
                      className={`flex items-center px-3 py-2 border rounded-md text-sm transition-colors duration-150 ${priority === option.id 
                        ? `${option.color} border-current` 
                        : 'bg-surface text-text-secondary border-border hover:bg-surface-secondary'
                      }`}
                    >
                      {priority === option.id && <Icon name="Check" size={14} className="mr-1" />}
                      {option.label}
                    </button>
                  ))}
                </div>
              </div>
            </div>
          </div>

          {/* Message Content */}
          <div className="bg-surface border border-border rounded-lg overflow-hidden">
            <div className="p-4 border-b border-border bg-surface-secondary">
              <h3 className="text-base font-semibold text-text-primary flex items-center">
                <Icon name="Edit" size={16} className="mr-2" />
                Message Content
              </h3>
            </div>
            <div className="p-4 space-y-4">
              <div>
                <label htmlFor="message-title" className="block text-sm font-medium text-text-secondary mb-2">
                  Message Title
                </label>
                <Input
                  id="message-title"
                  type="text"
                  placeholder="Enter a clear, concise title"
                  value={title}
                  onChange={(e) => setTitle(e.target.value)}
                />
              </div>

              <div>
                <label htmlFor="message-content" className="block text-sm font-medium text-text-secondary mb-2">
                  Message Content
                </label>
                <textarea
                  id="message-content"
                  rows="6"
                  placeholder="Type your message here..."
                  value={message}
                  onChange={(e) => setMessage(e.target.value)}
                  className="w-full rounded-md border border-input bg-background px-3 py-2 text-base ring-offset-background focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2 md:text-sm"
                />
                <p className="text-xs text-text-secondary mt-1">
                  {message.length} characters ({500 - message.length} remaining)
                </p>
              </div>

              <div>
                <label className="block text-sm font-medium text-text-secondary mb-2">
                  Attachment
                </label>
                <div className="flex flex-wrap gap-2">
                  <button
                    type="button"
                    onClick={() => setAttachmentType('none')}
                    className={`flex items-center px-3 py-2 border rounded-md text-sm ${attachmentType === 'none' ?'bg-primary text-white border-primary' :'bg-surface text-text-secondary border-border hover:bg-surface-secondary'
                    }`}
                  >
                    <Icon name="X" size={14} className="mr-1" />
                    None
                  </button>
                  <button
                    type="button"
                    onClick={() => setAttachmentType('image')}
                    className={`flex items-center px-3 py-2 border rounded-md text-sm ${attachmentType === 'image' ?'bg-primary text-white border-primary' :'bg-surface text-text-secondary border-border hover:bg-surface-secondary'
                    }`}
                  >
                    <Icon name="Image" size={14} className="mr-1" />
                    Image
                  </button>
                  <button
                    type="button"
                    onClick={() => setAttachmentType('document')}
                    className={`flex items-center px-3 py-2 border rounded-md text-sm ${attachmentType === 'document' ?'bg-primary text-white border-primary' :'bg-surface text-text-secondary border-border hover:bg-surface-secondary'
                    }`}
                  >
                    <Icon name="FileText" size={14} className="mr-1" />
                    Document
                  </button>
                  <button
                    type="button"
                    onClick={() => setAttachmentType('location')}
                    className={`flex items-center px-3 py-2 border rounded-md text-sm ${attachmentType === 'location' ?'bg-primary text-white border-primary' :'bg-surface text-text-secondary border-border hover:bg-surface-secondary'
                    }`}
                  >
                    <Icon name="MapPin" size={14} className="mr-1" />
                    Location
                  </button>
                </div>

                {attachmentType !== 'none' && (
                  <div className="mt-3 p-3 border border-dashed border-border rounded-lg bg-surface-secondary text-center">
                    <Icon name={attachmentType === 'image' ? 'Image' : attachmentType === 'document' ? 'FileText' : 'MapPin'} 
                      size={24} 
                      className="mx-auto mb-2 text-text-secondary" 
                    />
                    <p className="text-sm text-text-secondary mb-2">
                      {attachmentType === 'image' ?'Click to upload an image' 
                        : attachmentType === 'document' ?'Click to upload a document' :'Click to select a location'
                      }
                    </p>
                    <Button
                      variant="outline"
                      size="sm"
                    >
                      {attachmentType === 'image' || attachmentType === 'document' 
                        ? 'Upload File' :'Select Location'
                      }
                    </Button>
                  </div>
                )}
              </div>
            </div>
          </div>
        </div>

        {/* Right Column - Recipients & Delivery */}
        <div className="space-y-6">
          {/* Recipients */}
          <div className="bg-surface border border-border rounded-lg overflow-hidden">
            <div className="p-4 border-b border-border bg-surface-secondary">
              <h3 className="text-base font-semibold text-text-primary flex items-center">
                <Icon name="Users" size={16} className="mr-2" />
                Recipients
              </h3>
            </div>
            <div className="p-4">
              <div className="space-y-4">
                <div>
                  <label className="block text-sm font-medium text-text-secondary mb-2">
                    Recipient Selection
                  </label>
                  <div className="flex flex-wrap gap-2">
                    <button
                      type="button"
                      onClick={() => handleRecipientTypeChange('all')}
                      className={`flex items-center px-3 py-2 border rounded-md text-sm ${recipients.type === 'all' ?'bg-primary text-white border-primary' :'bg-surface text-text-secondary border-border hover:bg-surface-secondary'
                      }`}
                    >
                      <Icon name="Globe" size={14} className="mr-1" />
                      All Observers
                    </button>
                    <button
                      type="button"
                      onClick={() => handleRecipientTypeChange('role')}
                      className={`flex items-center px-3 py-2 border rounded-md text-sm ${recipients.type === 'role' ?'bg-primary text-white border-primary' :'bg-surface text-text-secondary border-border hover:bg-surface-secondary'
                      }`}
                    >
                      <Icon name="Users" size={14} className="mr-1" />
                      By Role
                    </button>
                    <button
                      type="button"
                      onClick={() => handleRecipientTypeChange('parish')}
                      className={`flex items-center px-3 py-2 border rounded-md text-sm ${recipients.type === 'parish' ?'bg-primary text-white border-primary' :'bg-surface text-text-secondary border-border hover:bg-surface-secondary'
                      }`}
                    >
                      <Icon name="MapPin" size={14} className="mr-1" />
                      By Parish
                    </button>
                  </div>
                </div>

                {recipients.type === 'role' && (
                  <div>
                    <label className="block text-sm font-medium text-text-secondary mb-2">
                      Select Roles
                    </label>
                    <div className="space-y-2">
                      {roles.map(role => (
                        <label key={role} className="flex items-center">
                          <input
                            type="checkbox"
                            checked={recipients.roles.includes(role)}
                            onChange={() => handleRoleChange(role)}
                            className="rounded border-gray-300 text-primary focus:ring-primary"
                          />
                          <span className="ml-2 text-sm text-text-secondary capitalize">
                            {role.replace(/-/g, ' ')}
                          </span>
                        </label>
                      ))}
                    </div>
                  </div>
                )}

                {recipients.type === 'parish' && (
                  <div>
                    <label className="block text-sm font-medium text-text-secondary mb-2">
                      Select Parishes
                    </label>
                    <div className="space-y-2">
                      {parishes.map(parish => (
                        <label key={parish} className="flex items-center">
                          <input
                            type="checkbox"
                            checked={recipients.parishes.includes(parish)}
                            onChange={() => handleParishChange(parish)}
                            className="rounded border-gray-300 text-primary focus:ring-primary"
                          />
                          <span className="ml-2 text-sm text-text-secondary">{parish}</span>
                        </label>
                      ))}
                    </div>
                  </div>
                )}

                <div className="pt-3 border-t border-border">
                  <div className="flex items-center justify-between">
                    <span className="text-sm text-text-secondary">Estimated Recipients:</span>
                    <span className="text-sm font-medium text-text-primary">{getRecipientCount()}</span>
                  </div>
                </div>
              </div>
            </div>
          </div>

          {/* Delivery Options */}
          <div className="bg-surface border border-border rounded-lg overflow-hidden">
            <div className="p-4 border-b border-border bg-surface-secondary">
              <h3 className="text-base font-semibold text-text-primary flex items-center">
                <Icon name="Send" size={16} className="mr-2" />
                Delivery Options
              </h3>
            </div>
            <div className="p-4">
              <div className="space-y-4">
                <div>
                  <label className="block text-sm font-medium text-text-secondary mb-2">
                    Delivery Methods
                  </label>
                  <div className="space-y-2">
                    <label className="flex items-center">
                      <input
                        type="checkbox"
                        checked={deliveryMethod.includes('app')}
                        onChange={() => handleDeliveryMethodChange('app')}
                        className="rounded border-gray-300 text-primary focus:ring-primary"
                      />
                      <span className="ml-2 text-sm text-text-secondary">In-App Notification</span>
                    </label>
                    <label className="flex items-center">
                      <input
                        type="checkbox"
                        checked={deliveryMethod.includes('sms')}
                        onChange={() => handleDeliveryMethodChange('sms')}
                        className="rounded border-gray-300 text-primary focus:ring-primary"
                      />
                      <span className="ml-2 text-sm text-text-secondary">SMS Message</span>
                    </label>
                    <label className="flex items-center">
                      <input
                        type="checkbox"
                        checked={deliveryMethod.includes('email')}
                        onChange={() => handleDeliveryMethodChange('email')}
                        className="rounded border-gray-300 text-primary focus:ring-primary"
                      />
                      <span className="ml-2 text-sm text-text-secondary">Email</span>
                    </label>
                  </div>
                </div>

                <div>
                  <label className="flex items-center">
                    <input
                      type="checkbox"
                      checked={scheduleSend}
                      onChange={() => setScheduleSend(!scheduleSend)}
                      className="rounded border-gray-300 text-primary focus:ring-primary"
                    />
                    <span className="ml-2 text-sm text-text-secondary">Schedule for later</span>
                  </label>

                  {scheduleSend && (
                    <div className="mt-2">
                      <Input
                        type="datetime-local"
                        value={scheduleTime}
                        onChange={(e) => setScheduleTime(e.target.value)}
                        className="w-full"
                      />
                    </div>
                  )}
                </div>
              </div>

              <div className="mt-6">
                <Button
                  variant={messageType === 'emergency' ? 'danger' : 'primary'}
                  size="md"
                  iconName="Send"
                  loading={isSending}
                  className="w-full"
                  onClick={handleSendMessage}
                  disabled={!title || !message || !deliveryMethod.length || (recipients.type === 'role' && !recipients.roles.length) || (recipients.type === 'parish' && !recipients.parishes.length)}
                >
                  {isSending 
                    ? 'Sending...' 
                    : scheduleSend 
                      ? 'Schedule Message' 
                      : messageType === 'emergency' ?'Send Emergency Message' :'Send Message'
                  }
                </Button>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Confirmation Modal */}
      {showConfirmation && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-4">
          <div className="bg-surface rounded-lg shadow-elevation-3 max-w-md w-full">
            <div className="p-6">
              <h3 className="text-lg font-semibold text-text-primary mb-2">
                Confirm Message {scheduleSend ? 'Schedule' : 'Send'}
              </h3>
              <p className="text-text-secondary mb-4">
                You are about to {scheduleSend ? 'schedule' : 'send'} a {priority} priority {messageType} to {getRecipientCount()} recipients. This action cannot be undone.
              </p>

              {messageType === 'emergency' && (
                <div className="p-3 bg-error-50 border border-error-200 rounded-lg mb-4">
                  <div className="flex items-center">
                    <Icon name="AlertOctagon" size={16} className="text-error mr-2" />
                    <span className="text-sm font-medium text-error">
                      Emergency messages should only be used for critical situations.
                    </span>
                  </div>
                </div>
              )}

              <div className="flex justify-end space-x-3">
                <Button
                  variant="ghost"
                  size="sm"
                  onClick={() => setShowConfirmation(false)}
                >
                  Cancel
                </Button>
                <Button
                  variant={messageType === 'emergency' ? 'danger' : 'primary'}
                  size="sm"
                  iconName="Send"
                  onClick={confirmSend}
                >
                  Confirm
                </Button>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default BroadcastMessage;