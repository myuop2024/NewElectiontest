// src/pages/admin-control-center/components/SystemMetrics.jsx
import React, { useState } from 'react';
import Icon from 'components/AppIcon';
import Button from 'components/ui/Button';

const SystemMetrics = ({ analytics, onRefresh }) => {
  const [timeRange, setTimeRange] = useState('today'); // today, week, month, all

  // If analytics is not available yet, show loading state
  if (!analytics) {
    return (
      <div className="p-6 flex items-center justify-center h-64">
        <div className="text-center">
          <Icon name="Loader" size={24} className="animate-spin mx-auto mb-4 text-primary" />
          <p className="text-text-secondary">Loading system metrics...</p>
        </div>
      </div>
    );
  }

  const { observerActivities, pollingStationCoverage, systemHealth, dataSync } = analytics;

  // Helper function to render progress bar
  const renderProgressBar = (value, maxValue = 100, colorClass = 'bg-primary') => {
    const percentage = Math.min(100, Math.max(0, (value / maxValue) * 100));
    return (
      <div className="w-full h-2 bg-surface-secondary rounded-full overflow-hidden">
        <div 
          className={`h-full ${colorClass}`} 
          style={{ width: `${percentage}%` }}
        />
      </div>
    );
  };

  // Format timestamp
  const formatTimestamp = (timestamp) => {
    if (!timestamp) return 'Unknown';
    return new Date(timestamp).toLocaleString();
  };

  return (
    <div className="p-6">
      <div className="flex flex-col lg:flex-row lg:items-center lg:justify-between mb-6">
        <h2 className="text-xl font-semibold text-text-primary mb-4 lg:mb-0">
          System Metrics & Analytics
        </h2>
        <div className="flex flex-col sm:flex-row space-y-3 sm:space-y-0 sm:space-x-3">
          <div className="flex items-center bg-surface border border-border rounded-lg">
            <button
              onClick={() => setTimeRange('today')}
              className={`px-3 py-1.5 text-xs font-medium rounded-md transition-colors duration-150 ease-out ${timeRange === 'today' ? 'bg-primary text-white' : 'text-text-secondary hover:text-text-primary'}`}
            >
              Today
            </button>
            <button
              onClick={() => setTimeRange('week')}
              className={`px-3 py-1.5 text-xs font-medium rounded-md transition-colors duration-150 ease-out ${timeRange === 'week' ? 'bg-primary text-white' : 'text-text-secondary hover:text-text-primary'}`}
            >
              Week
            </button>
            <button
              onClick={() => setTimeRange('month')}
              className={`px-3 py-1.5 text-xs font-medium rounded-md transition-colors duration-150 ease-out ${timeRange === 'month' ? 'bg-primary text-white' : 'text-text-secondary hover:text-text-primary'}`}
            >
              Month
            </button>
            <button
              onClick={() => setTimeRange('all')}
              className={`px-3 py-1.5 text-xs font-medium rounded-md transition-colors duration-150 ease-out ${timeRange === 'all' ? 'bg-primary text-white' : 'text-text-secondary hover:text-text-primary'}`}
            >
              All Time
            </button>
          </div>
          <Button 
            variant="outline" 
            size="sm"
            iconName="RefreshCw"
            onClick={onRefresh}
          >
            Refresh Data
          </Button>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Observer Activity Metrics */}
        <div className="bg-surface border border-border rounded-lg overflow-hidden">
          <div className="p-4 border-b border-border bg-surface-secondary">
            <h3 className="text-base font-semibold text-text-primary flex items-center">
              <Icon name="Users" size={16} className="mr-2" />
              Observer Activity Metrics
            </h3>
          </div>
          <div className="p-4 space-y-4">
            <div>
              <div className="flex items-center justify-between mb-2">
                <span className="text-sm text-text-secondary">Active Observers</span>
                <span className="text-sm font-medium text-text-primary">{observerActivities.activeObservers} / {observerActivities.totalCheckIns}</span>
              </div>
              {renderProgressBar(observerActivities.activeObservers, observerActivities.totalCheckIns, 'bg-success')}
            </div>

            <div>
              <div className="flex items-center justify-between mb-2">
                <span className="text-sm text-text-secondary">Total Documents Uploaded</span>
                <span className="text-sm font-medium text-text-primary">{observerActivities.totalDocumentsUploaded}</span>
              </div>
              {renderProgressBar(observerActivities.totalDocumentsUploaded, 100, 'bg-primary')}
            </div>

            <div>
              <div className="flex items-center justify-between mb-2">
                <span className="text-sm text-text-secondary">Total Incidents Reported</span>
                <span className="text-sm font-medium text-text-primary">{observerActivities.totalIncidentsReported}</span>
              </div>
              {renderProgressBar(observerActivities.totalIncidentsReported, 20, observerActivities.totalIncidentsReported > 10 ? 'bg-warning' : 'bg-success')}
            </div>

            <div className="pt-3 border-t border-border">
              <h4 className="text-sm font-medium text-text-primary mb-3">Observer Distribution by Parish</h4>
              <div className="space-y-2">
                {Object.entries(observerActivities.observersByParish).map(([parish, count]) => (
                  <div key={parish}>
                    <div className="flex items-center justify-between mb-1">
                      <span className="text-xs text-text-secondary">{parish}</span>
                      <span className="text-xs font-medium text-text-primary">{count}</span>
                    </div>
                    {renderProgressBar(count, Math.max(...Object.values(observerActivities.observersByParish)), 'bg-primary')}
                  </div>
                ))}
              </div>
            </div>
          </div>
        </div>

        {/* Polling Station Coverage */}
        <div className="bg-surface border border-border rounded-lg overflow-hidden">
          <div className="p-4 border-b border-border bg-surface-secondary">
            <h3 className="text-base font-semibold text-text-primary flex items-center">
              <Icon name="MapPin" size={16} className="mr-2" />
              Polling Station Coverage
            </h3>
          </div>
          <div className="p-4 space-y-4">
            <div className="grid grid-cols-2 gap-4">
              <div className="p-3 bg-surface-secondary rounded-lg">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-xs text-text-secondary">Total Stations</p>
                    <p className="text-xl font-bold text-text-primary">{pollingStationCoverage.totalStations}</p>
                  </div>
                  <div className="w-8 h-8 bg-primary-50 rounded-full flex items-center justify-center">
                    <Icon name="MapPin" size={16} className="text-primary" />
                  </div>
                </div>
              </div>

              <div className="p-3 bg-surface-secondary rounded-lg">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-xs text-text-secondary">With Observers</p>
                    <p className="text-xl font-bold text-text-primary">{pollingStationCoverage.stationsWithObservers}</p>
                  </div>
                  <div className="w-8 h-8 bg-success-50 rounded-full flex items-center justify-center">
                    <Icon name="Users" size={16} className="text-success" />
                  </div>
                </div>
              </div>
            </div>

            <div className="pt-3">
              <div className="flex items-center justify-between mb-2">
                <span className="text-sm text-text-secondary">Coverage Percentage</span>
                <span className="text-sm font-medium text-text-primary">{pollingStationCoverage.coveragePercentage}%</span>
              </div>
              {renderProgressBar(pollingStationCoverage.coveragePercentage, 100, pollingStationCoverage.coveragePercentage > 80 ? 'bg-success' : pollingStationCoverage.coveragePercentage > 50 ? 'bg-primary' : 'bg-warning')}
            </div>

            <div>
              <div className="flex items-center justify-between mb-2">
                <span className="text-sm text-text-secondary">Average Incidents per Station</span>
                <span className="text-sm font-medium text-text-primary">{pollingStationCoverage.averageIncidentsPerStation}</span>
              </div>
              {renderProgressBar(pollingStationCoverage.averageIncidentsPerStation, 1, pollingStationCoverage.averageIncidentsPerStation > 0.5 ? 'bg-warning' : 'bg-success')}
            </div>

            <div className="pt-3 border-t border-border">
              <div className="flex justify-center py-3">
                <div className="w-32 h-32 relative">
                  <svg viewBox="0 0 36 36" className="w-full h-full">
                    <path
                      d="M18 2.0845 a 15.9155 15.9155 0 0 1 0 31.831 a 15.9155 15.9155 0 0 1 0 -31.831"
                      fill="none"
                      stroke="#e6e6e6"
                      strokeWidth="3"
                      strokeDasharray="100, 100"
                    />
                    <path
                      d="M18 2.0845 a 15.9155 15.9155 0 0 1 0 31.831 a 15.9155 15.9155 0 0 1 0 -31.831"
                      fill="none"
                      stroke="#4f46e5"
                      strokeWidth="3"
                      strokeDasharray={`${pollingStationCoverage.coveragePercentage}, 100`}
                    />
                  </svg>
                  <div className="absolute inset-0 flex items-center justify-center flex-col">
                    <span className="text-2xl font-bold text-text-primary">{pollingStationCoverage.coveragePercentage}%</span>
                    <span className="text-xs text-text-secondary">Coverage</span>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* System Health */}
        <div className="bg-surface border border-border rounded-lg overflow-hidden">
          <div className="p-4 border-b border-border bg-surface-secondary">
            <h3 className="text-base font-semibold text-text-primary flex items-center">
              <Icon name="Activity" size={16} className="mr-2" />
              System Health & Performance
            </h3>
          </div>
          <div className="p-4 space-y-4">
            <div className="grid grid-cols-2 gap-4">
              <div className="p-3 bg-surface-secondary rounded-lg">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-xs text-text-secondary">Uptime</p>
                    <p className="text-xl font-bold text-text-primary">{systemHealth.uptime}%</p>
                  </div>
                  <div className="w-8 h-8 bg-success-50 rounded-full flex items-center justify-center">
                    <Icon name="Check" size={16} className="text-success" />
                  </div>
                </div>
              </div>

              <div className="p-3 bg-surface-secondary rounded-lg">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-xs text-text-secondary">Error Rate</p>
                    <p className="text-xl font-bold text-text-primary">{systemHealth.errorRate}%</p>
                  </div>
                  <div className="w-8 h-8 bg-error-50 rounded-full flex items-center justify-center">
                    <Icon name="AlertTriangle" size={16} className="text-error" />
                  </div>
                </div>
              </div>
            </div>

            <div>
              <div className="flex items-center justify-between mb-2">
                <span className="text-sm text-text-secondary">Storage Usage</span>
                <span className="text-sm font-medium text-text-primary">{systemHealth.storageUsed}%</span>
              </div>
              {renderProgressBar(systemHealth.storageUsed, 100, systemHealth.storageUsed > 90 ? 'bg-error' : systemHealth.storageUsed > 75 ? 'bg-warning' : 'bg-success')}
            </div>

            <div>
              <div className="flex items-center justify-between mb-2">
                <span className="text-sm text-text-secondary">Average Response Time</span>
                <span className="text-sm font-medium text-text-primary">{systemHealth.averageResponseTime} ms</span>
              </div>
              {renderProgressBar(systemHealth.averageResponseTime, 500, systemHealth.averageResponseTime > 300 ? 'bg-warning' : 'bg-success')}
            </div>

            <div>
              <div className="flex items-center justify-between mb-2">
                <span className="text-sm text-text-secondary">API Calls Today</span>
                <span className="text-sm font-medium text-text-primary">{systemHealth.apiCallsToday.toLocaleString()}</span>
              </div>
              {renderProgressBar(systemHealth.apiCallsToday, 2000, 'bg-primary')}
            </div>
          </div>
        </div>

        {/* Data Synchronization */}
        <div className="bg-surface border border-border rounded-lg overflow-hidden">
          <div className="p-4 border-b border-border bg-surface-secondary">
            <h3 className="text-base font-semibold text-text-primary flex items-center">
              <Icon name="RefreshCw" size={16} className="mr-2" />
              Data Synchronization Status
            </h3>
          </div>
          <div className="p-4 space-y-4">
            <div className="p-3 bg-surface-secondary rounded-lg">
              <div className="flex items-center justify-between mb-1">
                <span className="text-sm text-text-secondary">Last Sync</span>
                <span className="text-sm font-medium text-text-primary">{formatTimestamp(dataSync.lastSyncTime)}</span>
              </div>
              <div className="flex items-center justify-between mb-1">
                <span className="text-sm text-text-secondary">Total Data Synced</span>
                <span className="text-sm font-medium text-text-primary">{dataSync.totalDataSynced}</span>
              </div>
            </div>

            <div>
              <div className="flex items-center justify-between mb-2">
                <span className="text-sm text-text-secondary">Failed Sync Attempts</span>
                <span className="text-sm font-medium text-text-primary">{dataSync.failedSyncAttempts}</span>
              </div>
              {renderProgressBar(dataSync.failedSyncAttempts, 10, dataSync.failedSyncAttempts > 5 ? 'bg-error' : dataSync.failedSyncAttempts > 2 ? 'bg-warning' : 'bg-success')}
            </div>

            <div>
              <div className="flex items-center justify-between mb-2">
                <span className="text-sm text-text-secondary">Documents Awaiting Sync</span>
                <span className="text-sm font-medium text-text-primary">{dataSync.documentsAwaitingSync}</span>
              </div>
              {renderProgressBar(dataSync.documentsAwaitingSync, 20, dataSync.documentsAwaitingSync > 10 ? 'bg-warning' : 'bg-success')}
            </div>

            <div className="pt-3 border-t border-border">
              <div className="flex justify-between">
                <Button
                  variant="outline"
                  size="sm"
                  iconName="RefreshCw"
                  onClick={onRefresh}
                >
                  Sync Now
                </Button>
                <Button
                  variant="outline"
                  size="sm"
                  iconName="Settings"
                >
                  Sync Settings
                </Button>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Additional Actions */}
      <div className="mt-6 grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        <Button
          variant="outline"
          size="sm"
          iconName="Download"
          className="w-full"
        >
          Export Analytics
        </Button>
        <Button
          variant="outline"
          size="sm"
          iconName="BarChart2"
          className="w-full"
        >
          View Detailed Charts
        </Button>
        <Button
          variant="outline"
          size="sm"
          iconName="Clock"
          className="w-full"
        >
          View Historic Data
        </Button>
        <Button
          variant="outline"
          size="sm"
          iconName="Bell"
          className="w-full"
        >
          Configure Alerts
        </Button>
      </div>
    </div>
  );
};

export default SystemMetrics;