// src/pages/admin-control-center/components/DataExportTool.jsx
import React, { useState } from 'react';
import Icon from 'components/AppIcon';
import Button from 'components/ui/Button';
import Input from 'components/ui/Input';

const DataExportTool = ({ observers, stations, incidents }) => {
  const [exportType, setExportType] = useState('observers');
  const [exportFormat, setExportFormat] = useState('csv');
  const [dateRange, setDateRange] = useState({ from: '', to: '' });
  const [filterOptions, setFilterOptions] = useState({ parish: 'all', includeInactive: false });
  const [isExporting, setIsExporting] = useState(false);
  
  const exportTypes = [
    { id: 'observers', label: 'Observers', icon: 'Users', description: 'Export observer data including contact information and assignments' },
    { id: 'stations', label: 'Polling Stations', icon: 'MapPin', description: 'Export polling station data including locations and assigned observers' },
    { id: 'incidents', label: 'Incident Reports', icon: 'AlertTriangle', description: 'Export incident reports with details and resolutions' },
    { id: 'activity', label: 'Observer Activity', icon: 'Activity', description: 'Export observer activity logs and check-in data' },
    { id: 'documents', label: 'Documents', icon: 'FileText', description: 'Export metadata for uploaded documents' },
    { id: 'system', label: 'System Logs', icon: 'Server', description: 'Export system logs and performance metrics' }
  ];
  
  const exportFormats = [
    { id: 'csv', label: 'CSV', icon: 'FileText' },
    { id: 'json', label: 'JSON', icon: 'Code' },
    { id: 'pdf', label: 'PDF Report', icon: 'FileText' },
    { id: 'excel', label: 'Excel', icon: 'Grid' }
  ];
  
  const parishes = [
    'all',
    ...new Set(stations.map(station => station.parish))
  ];
  
  const handleExport = () => {
    setIsExporting(true);
    
    // Simulate export process
    setTimeout(() => {
      setIsExporting(false);
      
      // In a real app, this would trigger a download
      alert(`Exported ${exportType} data in ${exportFormat.toUpperCase()} format`);
    }, 2000);
  };
  
  const handleDateRangeChange = (e) => {
    const { name, value } = e.target;
    setDateRange(prev => ({
      ...prev,
      [name]: value
    }));
  };
  
  const handleFilterOptionsChange = (e) => {
    const { name, value, type, checked } = e.target;
    setFilterOptions(prev => ({
      ...prev,
      [name]: type === 'checkbox' ? checked : value
    }));
  };
  
  // Get estimated record count based on filters
  const getEstimatedRecordCount = () => {
    switch (exportType) {
      case 'observers':
        let filteredObservers = [...observers];
        if (filterOptions.parish !== 'all') {
          filteredObservers = filteredObservers.filter(o => o.parish === filterOptions.parish);
        }
        if (!filterOptions.includeInactive) {
          filteredObservers = filteredObservers.filter(o => o.status === 'active');
        }
        return filteredObservers.length;
        
      case 'stations':
        let filteredStations = [...stations];
        if (filterOptions.parish !== 'all') {
          filteredStations = filteredStations.filter(s => s.parish === filterOptions.parish);
        }
        return filteredStations.length;
        
      case 'incidents':
        return incidents.length;
        
      default:
        return '?';
    }
  };
  
  return (
    <div className="p-6">
      <div className="flex flex-col lg:flex-row lg:items-center lg:justify-between mb-6">
        <h2 className="text-xl font-semibold text-text-primary mb-4 lg:mb-0">
          Data Export Tool
        </h2>
        <div className="flex flex-col sm:flex-row space-y-3 sm:space-y-0 sm:space-x-3">
          <Button 
            variant="outline" 
            size="sm"
            iconName="Clock"
          >
            Scheduled Exports
          </Button>
          <Button 
            variant="outline" 
            size="sm"
            iconName="Settings"
          >
            Export Settings
          </Button>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Left Column - Export Options */}
        <div className="lg:col-span-2 space-y-6">
          {/* Export Type Selection */}
          <div className="bg-surface border border-border rounded-lg overflow-hidden">
            <div className="p-4 border-b border-border bg-surface-secondary">
              <h3 className="text-base font-semibold text-text-primary flex items-center">
                <Icon name="Database" size={16} className="mr-2" />
                Select Data to Export
              </h3>
            </div>
            <div className="p-4 grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3">
              {exportTypes.map(type => (
                <div 
                  key={type.id}
                  onClick={() => setExportType(type.id)}
                  className={`p-3 border rounded-lg cursor-pointer transition-colors duration-150 ${exportType === type.id 
                    ? 'border-primary bg-primary-50' :'border-border bg-surface hover:bg-surface-secondary'
                  }`}
                >
                  <div className="flex items-center">
                    <div className={`w-8 h-8 rounded-full flex items-center justify-center ${exportType === type.id ? 'bg-primary text-white' : 'bg-surface-secondary text-text-secondary'}`}>
                      <Icon name={type.icon} size={16} />
                    </div>
                    <div className="ml-3">
                      <p className={`text-sm font-medium ${exportType === type.id ? 'text-primary' : 'text-text-primary'}`}>{type.label}</p>
                    </div>
                  </div>
                  <p className="text-xs text-text-secondary mt-2">{type.description}</p>
                </div>
              ))}
            </div>
          </div>

          {/* Export Format & Filters */}
          <div className="bg-surface border border-border rounded-lg overflow-hidden">
            <div className="p-4 border-b border-border bg-surface-secondary">
              <h3 className="text-base font-semibold text-text-primary flex items-center">
                <Icon name="Sliders" size={16} className="mr-2" />
                Export Options & Filters
              </h3>
            </div>
            <div className="p-4">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                {/* Format Selection */}
                <div>
                  <label className="block text-sm font-medium text-text-secondary mb-2">
                    Export Format
                  </label>
                  <div className="flex flex-wrap gap-2">
                    {exportFormats.map(format => (
                      <button
                        key={format.id}
                        type="button"
                        onClick={() => setExportFormat(format.id)}
                        className={`flex items-center px-3 py-2 border rounded-md text-sm ${exportFormat === format.id 
                          ? 'bg-primary text-white border-primary' :'bg-surface text-text-secondary border-border hover:bg-surface-secondary'
                        }`}
                      >
                        <Icon name={format.icon} size={14} className="mr-1" />
                        {format.label}
                      </button>
                    ))}
                  </div>
                </div>

                {/* Date Range */}
                <div>
                  <label className="block text-sm font-medium text-text-secondary mb-2">
                    Date Range
                  </label>
                  <div className="grid grid-cols-2 gap-2">
                    <div>
                      <label htmlFor="date-from" className="block text-xs text-text-secondary mb-1">
                        From
                      </label>
                      <Input
                        id="date-from"
                        type="date"
                        name="from"
                        value={dateRange.from}
                        onChange={handleDateRangeChange}
                      />
                    </div>
                    <div>
                      <label htmlFor="date-to" className="block text-xs text-text-secondary mb-1">
                        To
                      </label>
                      <Input
                        id="date-to"
                        type="date"
                        name="to"
                        value={dateRange.to}
                        onChange={handleDateRangeChange}
                      />
                    </div>
                  </div>
                </div>

                {/* Parish Filter */}
                <div>
                  <label htmlFor="parish-filter" className="block text-sm font-medium text-text-secondary mb-2">
                    Parish
                  </label>
                  <select
                    id="parish-filter"
                    name="parish"
                    value={filterOptions.parish}
                    onChange={handleFilterOptionsChange}
                    className="w-full h-10 rounded-md border border-input bg-background px-3 py-2 text-base ring-offset-background focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2 md:text-sm"
                  >
                    {parishes.map(parish => (
                      <option key={parish} value={parish}>
                        {parish === 'all' ? 'All Parishes' : parish}
                      </option>
                    ))}
                  </select>
                </div>

                {/* Additional Filters */}
                <div>
                  <label className="block text-sm font-medium text-text-secondary mb-2">
                    Additional Options
                  </label>
                  <div className="space-y-2">
                    <label className="flex items-center">
                      <input
                        type="checkbox"
                        name="includeInactive"
                        checked={filterOptions.includeInactive}
                        onChange={handleFilterOptionsChange}
                        className="rounded border-gray-300 text-primary focus:ring-primary"
                      />
                      <span className="ml-2 text-sm text-text-secondary">Include inactive records</span>
                    </label>
                    <label className="flex items-center">
                      <input
                        type="checkbox"
                        className="rounded border-gray-300 text-primary focus:ring-primary"
                      />
                      <span className="ml-2 text-sm text-text-secondary">Include attachments (where applicable)</span>
                    </label>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* Right Column - Export Summary & Actions */}
        <div className="space-y-6">
          {/* Export Summary */}
          <div className="bg-surface border border-border rounded-lg overflow-hidden">
            <div className="p-4 border-b border-border bg-surface-secondary">
              <h3 className="text-base font-semibold text-text-primary flex items-center">
                <Icon name="Info" size={16} className="mr-2" />
                Export Summary
              </h3>
            </div>
            <div className="p-4">
              <div className="space-y-3">
                <div className="flex justify-between">
                  <span className="text-sm text-text-secondary">Data Type:</span>
                  <span className="text-sm font-medium text-text-primary capitalize">
                    {exportTypes.find(t => t.id === exportType)?.label || exportType}
                  </span>
                </div>
                <div className="flex justify-between">
                  <span className="text-sm text-text-secondary">Format:</span>
                  <span className="text-sm font-medium text-text-primary uppercase">
                    {exportFormat}
                  </span>
                </div>
                <div className="flex justify-between">
                  <span className="text-sm text-text-secondary">Parish Filter:</span>
                  <span className="text-sm font-medium text-text-primary">
                    {filterOptions.parish === 'all' ? 'All Parishes' : filterOptions.parish}
                  </span>
                </div>
                {dateRange.from && dateRange.to && (
                  <div className="flex justify-between">
                    <span className="text-sm text-text-secondary">Date Range:</span>
                    <span className="text-sm font-medium text-text-primary">
                      {dateRange.from} to {dateRange.to}
                    </span>
                  </div>
                )}
                <div className="flex justify-between pt-2 border-t border-border">
                  <span className="text-sm text-text-secondary">Estimated Records:</span>
                  <span className="text-sm font-medium text-text-primary">
                    {getEstimatedRecordCount()}
                  </span>
                </div>
              </div>

              <div className="mt-4 pt-4 border-t border-border">
                <Button
                  variant="primary"
                  size="md"
                  iconName="Download"
                  loading={isExporting}
                  className="w-full"
                  onClick={handleExport}
                >
                  {isExporting ? 'Preparing Export...' : 'Export Data'}
                </Button>
                <p className="text-xs text-text-secondary mt-2 text-center">
                  Data will be exported according to your user permissions and security settings.
                </p>
              </div>
            </div>
          </div>

          {/* Recent Exports */}
          <div className="bg-surface border border-border rounded-lg overflow-hidden">
            <div className="p-4 border-b border-border bg-surface-secondary">
              <h3 className="text-base font-semibold text-text-primary flex items-center">
                <Icon name="Clock" size={16} className="mr-2" />
                Recent Exports
              </h3>
            </div>
            <div className="p-4">
              <div className="space-y-3">
                <div className="p-3 bg-surface-secondary rounded-lg">
                  <div className="flex items-center justify-between">
                    <div className="flex items-center">
                      <Icon name="FileText" size={14} className="text-text-secondary mr-2" />
                      <div>
                        <p className="text-sm font-medium text-text-primary">Observer List</p>
                        <p className="text-xs text-text-secondary">CSV • 2 hours ago</p>
                      </div>
                    </div>
                    <Button
                      variant="ghost"
                      size="xs"
                      iconName="Download"
                      aria-label="Download again"
                    />
                  </div>
                </div>

                <div className="p-3 bg-surface-secondary rounded-lg">
                  <div className="flex items-center justify-between">
                    <div className="flex items-center">
                      <Icon name="FileText" size={14} className="text-text-secondary mr-2" />
                      <div>
                        <p className="text-sm font-medium text-text-primary">Incident Reports</p>
                        <p className="text-xs text-text-secondary">PDF • Yesterday</p>
                      </div>
                    </div>
                    <Button
                      variant="ghost"
                      size="xs"
                      iconName="Download"
                      aria-label="Download again"
                    />
                  </div>
                </div>

                <div className="p-3 bg-surface-secondary rounded-lg">
                  <div className="flex items-center justify-between">
                    <div className="flex items-center">
                      <Icon name="FileText" size={14} className="text-text-secondary mr-2" />
                      <div>
                        <p className="text-sm font-medium text-text-primary">Station Coverage</p>
                        <p className="text-xs text-text-secondary">Excel • 3 days ago</p>
                      </div>
                    </div>
                    <Button
                      variant="ghost"
                      size="xs"
                      iconName="Download"
                      aria-label="Download again"
                    />
                  </div>
                </div>
              </div>

              <div className="mt-3">
                <Button
                  variant="ghost"
                  size="sm"
                  className="w-full"
                >
                  View All Exports
                </Button>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default DataExportTool;