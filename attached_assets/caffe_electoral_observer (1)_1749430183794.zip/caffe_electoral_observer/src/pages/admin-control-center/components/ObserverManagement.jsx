// src/pages/admin-control-center/components/ObserverManagement.jsx
import React, { useState, useEffect } from 'react';
import Icon from 'components/AppIcon';
import Button from 'components/ui/Button';
import Input from 'components/ui/Input';

const ObserverManagement = ({ observers, pollingStations, onRefresh }) => {
  const [searchTerm, setSearchTerm] = useState('');
  const [filterRole, setFilterRole] = useState('all');
  const [filterStatus, setFilterStatus] = useState('all');
  const [filteredObservers, setFilteredObservers] = useState([]);
  const [selectedObserver, setSelectedObserver] = useState(null);
  const [isEditModalOpen, setIsEditModalOpen] = useState(false);

  // Role options for filtering
  const roleOptions = [
    { value: 'all', label: 'All Roles' },
    { value: 'indoor-agent', label: 'Indoor Agent' },
    { value: 'roving-observer', label: 'Roving Observer' },
    { value: 'parish-coordinator', label: 'Parish Coordinator' }
  ];

  // Status options for filtering
  const statusOptions = [
    { value: 'all', label: 'All Statuses' },
    { value: 'active', label: 'Active' },
    { value: 'inactive', label: 'Inactive' },
    { value: 'pending-check-in', label: 'Pending Check-in' }
  ];

  // Apply filters whenever search term, role filter, or status filter changes
  useEffect(() => {
    let filtered = [...observers];
    
    // Apply search filter
    if (searchTerm) {
      const lowercasedSearch = searchTerm.toLowerCase();
      filtered = filtered.filter(observer => 
        observer.name.toLowerCase().includes(lowercasedSearch) ||
        observer.id.toLowerCase().includes(lowercasedSearch) ||
        observer.email.toLowerCase().includes(lowercasedSearch) ||
        (observer.pollingStation && observer.pollingStation.toLowerCase().includes(lowercasedSearch))
      );
    }
    
    // Apply role filter
    if (filterRole !== 'all') {
      filtered = filtered.filter(observer => observer.role === filterRole);
    }
    
    // Apply status filter
    if (filterStatus !== 'all') {
      filtered = filtered.filter(observer => observer.status === filterStatus);
    }
    
    setFilteredObservers(filtered);
  }, [observers, searchTerm, filterRole, filterStatus]);

  const handleSearchChange = (e) => {
    setSearchTerm(e.target.value);
  };

  const handleRoleFilterChange = (e) => {
    setFilterRole(e.target.value);
  };

  const handleStatusFilterChange = (e) => {
    setFilterStatus(e.target.value);
  };

  const handleObserverSelect = (observer) => {
    setSelectedObserver(observer);
    setIsEditModalOpen(true);
  };

  const handleCloseModal = () => {
    setIsEditModalOpen(false);
    setSelectedObserver(null);
  };

  const handleSaveObserver = (updatedObserver) => {
    // In a real app, this would make an API call to update the observer
    console.log('Saving updated observer:', updatedObserver);
    
    // Mock update in UI
    const updatedObservers = observers.map(obs => 
      obs.id === updatedObserver.id ? updatedObserver : obs
    );
    
    // Refresh data
    onRefresh();
    handleCloseModal();
  };

  // Get polling station name from ID
  const getStationName = (stationId) => {
    if (!stationId) return 'Not Assigned';
    const station = pollingStations.find(s => s.id === stationId);
    return station ? station.name : stationId;
  };

  // Render status badge with appropriate color
  const renderStatusBadge = (status) => {
    const statusConfig = {
      'active': { color: 'bg-success text-white', icon: 'CheckCircle' },
      'inactive': { color: 'bg-error text-white', icon: 'XCircle' },
      'pending-check-in': { color: 'bg-warning text-primary-foreground', icon: 'Clock' }
    };

    const config = statusConfig[status] || { color: 'bg-gray-500 text-white', icon: 'HelpCircle' };

    return (
      <span className={`inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium ${config.color}`}>
        <Icon name={config.icon} size={12} className="mr-1" />
        {status.split('-').map(word => word.charAt(0).toUpperCase() + word.slice(1)).join(' ')}
      </span>
    );
  };

  return (
    <div className="p-6">
      <div className="flex flex-col lg:flex-row lg:items-center lg:justify-between mb-6">
        <h2 className="text-xl font-semibold text-text-primary mb-4 lg:mb-0">
          Observer Management
        </h2>
        <div className="flex flex-col sm:flex-row space-y-3 sm:space-y-0 sm:space-x-3">
          <Button 
            variant="primary" 
            size="sm"
            iconName="UserPlus"
          >
            Add Observer
          </Button>
          <Button 
            variant="secondary" 
            size="sm"
            iconName="Mail"
          >
            Invite Observers
          </Button>
        </div>
      </div>

      {/* Filters */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-6">
        <div>
          <label htmlFor="search" className="block text-sm font-medium text-text-secondary mb-1">
            Search Observers
          </label>
          <div className="relative">
            <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
              <Icon name="Search" size={16} className="text-text-secondary" />
            </div>
            <Input
              id="search"
              type="text"
              placeholder="Name, ID, Email or Station"
              value={searchTerm}
              onChange={handleSearchChange}
              className="pl-10"
            />
          </div>
        </div>

        <div>
          <label htmlFor="role-filter" className="block text-sm font-medium text-text-secondary mb-1">
            Filter by Role
          </label>
          <select
            id="role-filter"
            value={filterRole}
            onChange={handleRoleFilterChange}
            className="w-full h-10 rounded-md border border-input bg-background px-3 py-2 text-base ring-offset-background focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2 md:text-sm"
          >
            {roleOptions.map(option => (
              <option key={option.value} value={option.value}>
                {option.label}
              </option>
            ))}
          </select>
        </div>

        <div>
          <label htmlFor="status-filter" className="block text-sm font-medium text-text-secondary mb-1">
            Filter by Status
          </label>
          <select
            id="status-filter"
            value={filterStatus}
            onChange={handleStatusFilterChange}
            className="w-full h-10 rounded-md border border-input bg-background px-3 py-2 text-base ring-offset-background focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2 md:text-sm"
          >
            {statusOptions.map(option => (
              <option key={option.value} value={option.value}>
                {option.label}
              </option>
            ))}
          </select>
        </div>
      </div>

      {/* Observers Table */}
      <div className="overflow-x-auto bg-surface border border-border rounded-lg">
        <table className="min-w-full divide-y divide-border">
          <thead>
            <tr>
              <th className="px-6 py-3 bg-surface-secondary text-left text-xs font-medium text-text-secondary uppercase tracking-wider">
                Observer ID
              </th>
              <th className="px-6 py-3 bg-surface-secondary text-left text-xs font-medium text-text-secondary uppercase tracking-wider">
                Name
              </th>
              <th className="px-6 py-3 bg-surface-secondary text-left text-xs font-medium text-text-secondary uppercase tracking-wider">
                Role
              </th>
              <th className="px-6 py-3 bg-surface-secondary text-left text-xs font-medium text-text-secondary uppercase tracking-wider">
                Polling Station
              </th>
              <th className="px-6 py-3 bg-surface-secondary text-left text-xs font-medium text-text-secondary uppercase tracking-wider">
                Status
              </th>
              <th className="px-6 py-3 bg-surface-secondary text-left text-xs font-medium text-text-secondary uppercase tracking-wider">
                Last Check-in
              </th>
              <th className="px-6 py-3 bg-surface-secondary text-right text-xs font-medium text-text-secondary uppercase tracking-wider">
                Actions
              </th>
            </tr>
          </thead>
          <tbody className="bg-surface divide-y divide-border">
            {filteredObservers.length > 0 ? (
              filteredObservers.map((observer) => (
                <tr key={observer.id} className="hover:bg-surface-secondary transition-colors duration-150">
                  <td className="px-6 py-4 whitespace-nowrap text-sm font-mono text-text-secondary">
                    {observer.id}
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap">
                    <div className="flex items-center">
                      <div className="flex-shrink-0 h-8 w-8 bg-primary-100 rounded-full flex items-center justify-center">
                        <Icon name="User" size={16} className="text-primary-600" />
                      </div>
                      <div className="ml-3">
                        <p className="text-sm font-medium text-text-primary">{observer.name}</p>
                        <p className="text-xs text-text-secondary">{observer.email}</p>
                      </div>
                    </div>
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap text-sm text-text-primary capitalize">
                    {observer.role.replace(/-/g, ' ')}
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap text-sm text-text-primary">
                    {observer.pollingStation ? (
                      <div className="flex items-center">
                        <Icon name="MapPin" size={14} className="text-text-secondary mr-1" />
                        <span>{getStationName(observer.pollingStation)}</span>
                      </div>
                    ) : (
                      <span className="text-text-secondary">Not Assigned</span>
                    )}
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap">
                    {renderStatusBadge(observer.status)}
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap text-sm text-text-secondary">
                    {observer.lastCheckIn ? (
                      new Date(observer.lastCheckIn).toLocaleString()
                    ) : (
                      <span className="text-text-secondary">Never</span>
                    )}
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap text-sm text-right">
                    <div className="flex justify-end space-x-2">
                      <Button
                        size="xs"
                        variant="ghost"
                        iconName="Edit"
                        onClick={() => handleObserverSelect(observer)}
                        aria-label="Edit observer"
                      />
                      <Button
                        size="xs"
                        variant="ghost"
                        iconName="MessageSquare"
                        aria-label="Message observer"
                      />
                      <Button
                        size="xs"
                        variant="ghost"
                        iconName="MoreVertical"
                        aria-label="More options"
                      />
                    </div>
                  </td>
                </tr>
              ))
            ) : (
              <tr>
                <td colSpan="7" className="px-6 py-12 text-center">
                  <Icon name="Search" size={24} className="mx-auto mb-3 text-text-secondary" />
                  <p className="text-text-secondary">No observers found with the current filters</p>
                  <Button
                    variant="ghost"
                    size="sm"
                    onClick={() => {
                      setSearchTerm('');
                      setFilterRole('all');
                      setFilterStatus('all');
                    }}
                    className="mt-2"
                  >
                    Clear Filters
                  </Button>
                </td>
              </tr>
            )}
          </tbody>
        </table>
      </div>

      {/* Pagination */}
      <div className="flex items-center justify-between mt-6">
        <div className="text-sm text-text-secondary">
          Showing <span className="font-medium">{filteredObservers.length}</span> of <span className="font-medium">{observers.length}</span> observers
        </div>
        <div className="flex items-center space-x-2">
          <Button
            variant="outline"
            size="sm"
            iconName="ChevronLeft"
            disabled
          >
            Previous
          </Button>
          <Button
            variant="outline"
            size="sm"
            iconName="ChevronRight"
            iconPosition="right"
            disabled
          >
            Next
          </Button>
        </div>
      </div>

      {/* Edit Observer Modal */}
      {isEditModalOpen && selectedObserver && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-4">
          <div className="bg-surface rounded-lg shadow-elevation-3 max-w-2xl w-full max-h-[90vh] overflow-y-auto">
            <div className="flex items-center justify-between p-6 border-b border-border">
              <h3 className="text-lg font-semibold text-text-primary">Edit Observer</h3>
              <Button
                variant="ghost"
                size="sm"
                iconName="X"
                onClick={handleCloseModal}
                aria-label="Close modal"
              />
            </div>
            <div className="p-6">
              <ObserverEditForm 
                observer={selectedObserver} 
                pollingStations={pollingStations} 
                onSave={handleSaveObserver}
                onCancel={handleCloseModal}
              />
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

// Helper component for editing an observer
const ObserverEditForm = ({ observer, pollingStations, onSave, onCancel }) => {
  const [formData, setFormData] = useState({
    ...observer
  });

  const handleChange = (e) => {
    const { name, value } = e.target;
    setFormData(prev => ({
      ...prev,
      [name]: value
    }));
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    onSave(formData);
  };

  return (
    <form onSubmit={handleSubmit}>
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        <div>
          <label htmlFor="name" className="block text-sm font-medium text-text-secondary mb-1">
            Full Name
          </label>
          <Input
            id="name"
            name="name"
            value={formData.name}
            onChange={handleChange}
            required
          />
        </div>

        <div>
          <label htmlFor="email" className="block text-sm font-medium text-text-secondary mb-1">
            Email Address
          </label>
          <Input
            id="email"
            name="email"
            type="email"
            value={formData.email}
            onChange={handleChange}
            required
          />
        </div>

        <div>
          <label htmlFor="phone" className="block text-sm font-medium text-text-secondary mb-1">
            Phone Number
          </label>
          <Input
            id="phone"
            name="phone"
            value={formData.phone}
            onChange={handleChange}
            required
          />
        </div>

        <div>
          <label htmlFor="role" className="block text-sm font-medium text-text-secondary mb-1">
            Role
          </label>
          <select
            id="role"
            name="role"
            value={formData.role}
            onChange={handleChange}
            className="w-full h-10 rounded-md border border-input bg-background px-3 py-2 text-base ring-offset-background focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2 md:text-sm"
            required
          >
            <option value="indoor-agent">Indoor Agent</option>
            <option value="roving-observer">Roving Observer</option>
            <option value="parish-coordinator">Parish Coordinator</option>
          </select>
        </div>

        <div>
          <label htmlFor="parish" className="block text-sm font-medium text-text-secondary mb-1">
            Parish
          </label>
          <select
            id="parish"
            name="parish"
            value={formData.parish}
            onChange={handleChange}
            className="w-full h-10 rounded-md border border-input bg-background px-3 py-2 text-base ring-offset-background focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2 md:text-sm"
            required
          >
            <option value="Kingston">Kingston</option>
            <option value="St. Andrew">St. Andrew</option>
            <option value="St. Catherine">St. Catherine</option>
            <option value="St. Thomas">St. Thomas</option>
          </select>
        </div>

        <div>
          <label htmlFor="pollingStation" className="block text-sm font-medium text-text-secondary mb-1">
            Polling Station
          </label>
          <select
            id="pollingStation"
            name="pollingStation"
            value={formData.pollingStation || ''}
            onChange={handleChange}
            className="w-full h-10 rounded-md border border-input bg-background px-3 py-2 text-base ring-offset-background focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2 md:text-sm"
          >
            <option value="">Not Assigned</option>
            {pollingStations.map(station => (
              <option key={station.id} value={station.id}>
                {station.id} - {station.name}
              </option>
            ))}
          </select>
        </div>

        <div>
          <label htmlFor="status" className="block text-sm font-medium text-text-secondary mb-1">
            Status
          </label>
          <select
            id="status"
            name="status"
            value={formData.status}
            onChange={handleChange}
            className="w-full h-10 rounded-md border border-input bg-background px-3 py-2 text-base ring-offset-background focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2 md:text-sm"
            required
          >
            <option value="active">Active</option>
            <option value="inactive">Inactive</option>
            <option value="pending-check-in">Pending Check-in</option>
          </select>
        </div>
      </div>

      <div className="flex justify-between items-center mt-8 pt-4 border-t border-border">
        <Button
          variant="ghost"
          type="button"
          onClick={onCancel}
        >
          Cancel
        </Button>
        <div className="space-x-2">
          <Button
            variant="outline"
            type="button"
            iconName="RotateCcw"
            onClick={() => setFormData({...observer})}
          >
            Reset
          </Button>
          <Button
            variant="primary"
            type="submit"
            iconName="Check"
          >
            Save Changes
          </Button>
        </div>
      </div>
    </form>
  );
};

export default ObserverManagement;