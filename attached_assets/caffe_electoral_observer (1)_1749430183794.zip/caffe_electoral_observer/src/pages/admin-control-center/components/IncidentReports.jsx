// src/pages/admin-control-center/components/IncidentReports.jsx
import React, { useState, useEffect } from 'react';
import Icon from '../../../components/AppIcon';
import Button from '@/components/ui/Button';
import Input from '@/components/ui/Input';

const IncidentReports = ({ incidents = [], stations = [], observers = [], onRefresh }) => {
  const [searchTerm, setSearchTerm] = useState('');
  const [filterCategory, setFilterCategory] = useState('all');
  const [filterStatus, setFilterStatus] = useState('all');
  const [filteredIncidents, setFilteredIncidents] = useState([]);
  const [selectedIncident, setSelectedIncident] = useState(null);
  const [isDetailModalOpen, setIsDetailModalOpen] = useState(false);
  
  // Calculate statistics
  const totalIncidents = incidents?.length || 0;
  const resolvedIncidents = incidents?.filter(inc => inc?.status === 'resolved')?.length || 0;
  const highSeverityIncidents = incidents?.filter(inc => inc?.severity === 'high')?.length || 0;
  const pendingIncidents = incidents?.filter(inc => inc?.status === 'in-progress')?.length || 0;
  
  // Get unique categories for filter
  const incidentCategories = ['all', ...new Set(incidents?.map(inc => inc?.category).filter(Boolean) || [])];

  // Apply filters whenever search term, category filter, or status filter changes
  useEffect(() => {
    if (!incidents || !Array.isArray(incidents)) {
      setFilteredIncidents([]);
      return;
    }

    let filtered = [...incidents];
    
    // Apply search filter
    if (searchTerm) {
      const lowercasedSearch = searchTerm.toLowerCase();
      filtered = filtered.filter(incident => 
        incident?.id?.toLowerCase()?.includes(lowercasedSearch) ||
        incident?.description?.toLowerCase()?.includes(lowercasedSearch) ||
        incident?.pollingStation?.toLowerCase()?.includes(lowercasedSearch) ||
        incident?.reportedBy?.toLowerCase()?.includes(lowercasedSearch)
      );
    }
    
    // Apply category filter
    if (filterCategory !== 'all') {
      filtered = filtered.filter(incident => incident?.category === filterCategory);
    }
    
    // Apply status filter
    if (filterStatus !== 'all') {
      filtered = filtered.filter(incident => incident?.status === filterStatus);
    }
    
    setFilteredIncidents(filtered);
  }, [incidents, searchTerm, filterCategory, filterStatus]);

  const handleSearchChange = (e) => {
    setSearchTerm(e?.target?.value || '');
  };

  const handleCategoryFilterChange = (e) => {
    setFilterCategory(e?.target?.value || 'all');
  };

  const handleStatusFilterChange = (e) => {
    setFilterStatus(e?.target?.value || 'all');
  };

  const handleIncidentSelect = (incident) => {
    setSelectedIncident(incident);
    setIsDetailModalOpen(true);
  };

  const handleCloseModal = () => {
    setIsDetailModalOpen(false);
    setSelectedIncident(null);
  };

  // Get station name from ID
  const getStationName = (stationId) => {
    if (!stationId || !stations || !Array.isArray(stations)) return stationId || 'Unknown';
    const station = stations.find(s => s?.id === stationId);
    return station?.name || stationId;
  };

  // Get observer name from ID
  const getObserverName = (observerId) => {
    if (!observerId || !observers || !Array.isArray(observers)) return observerId || 'Unknown';
    const observer = observers.find(o => o?.id === observerId);
    return observer?.name || observerId;
  };

  // Format timestamp
  const formatTimestamp = (timestamp) => {
    if (!timestamp) return 'Unknown';
    try {
      return new Date(timestamp).toLocaleString();
    } catch (error) {
      return 'Invalid Date';
    }
  };

  // Render severity badge with appropriate color
  const renderSeverityBadge = (severity) => {
    const severityConfig = {
      'high': { color: 'bg-error text-white', icon: 'AlertOctagon' },
      'medium': { color: 'bg-warning text-primary-foreground', icon: 'AlertTriangle' },
      'low': { color: 'bg-info text-white', icon: 'Info' }
    };

    const config = severityConfig[severity] || { color: 'bg-gray-500 text-white', icon: 'HelpCircle' };

    return (
      <span className={`inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium ${config.color}`}>
        <Icon name={config.icon} size={12} className="mr-1" />
        {severity ? severity.charAt(0).toUpperCase() + severity.slice(1) : 'Unknown'} Severity
      </span>
    );
  };

  // Render status badge with appropriate color
  const renderStatusBadge = (status) => {
    const statusConfig = {
      'resolved': { color: 'bg-success text-white', icon: 'CheckCircle' },
      'in-progress': { color: 'bg-primary text-white', icon: 'Clock' },
      'pending': { color: 'bg-warning text-primary-foreground', icon: 'Clock' },
      'escalated': { color: 'bg-error text-white', icon: 'AlertTriangle' }
    };

    const config = statusConfig[status] || { color: 'bg-gray-500 text-white', icon: 'HelpCircle' };

    return (
      <span className={`inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium ${config.color}`}>
        <Icon name={config.icon} size={12} className="mr-1" />
        {status ? status.split('-').map(word => word.charAt(0).toUpperCase() + word.slice(1)).join(' ') : 'Unknown'}
      </span>
    );
  };

  return (
    <div className="p-6">
      <div className="flex flex-col lg:flex-row lg:items-center lg:justify-between mb-6">
        <h2 className="text-xl font-semibold text-text-primary mb-4 lg:mb-0">
          Incident Reports
        </h2>
        <div className="flex flex-col sm:flex-row space-y-3 sm:space-y-0 sm:space-x-3">
          <Button 
            variant="primary" 
            size="sm"
            iconName="FileText"
          >
            Generate Report
          </Button>
          <Button 
            variant="secondary" 
            size="sm"
            iconName="Download"
          >
            Export Data
          </Button>
        </div>
      </div>

      {/* Statistics Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4 mb-6">
        <div className="bg-surface border border-border rounded-lg p-4">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm text-text-secondary">Total Incidents</p>
              <p className="text-2xl font-bold text-text-primary">{totalIncidents}</p>
            </div>
            <div className="w-10 h-10 bg-primary-50 rounded-full flex items-center justify-center">
              <Icon name="FileText" size={20} className="text-primary" />
            </div>
          </div>
        </div>

        <div className="bg-surface border border-border rounded-lg p-4">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm text-text-secondary">Resolved</p>
              <p className="text-2xl font-bold text-text-primary">{resolvedIncidents}</p>
            </div>
            <div className="w-10 h-10 bg-success-50 rounded-full flex items-center justify-center">
              <Icon name="CheckCircle" size={20} className="text-success" />
            </div>
          </div>
        </div>

        <div className="bg-surface border border-border rounded-lg p-4">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm text-text-secondary">High Severity</p>
              <p className="text-2xl font-bold text-text-primary">{highSeverityIncidents}</p>
            </div>
            <div className="w-10 h-10 bg-error-50 rounded-full flex items-center justify-center">
              <Icon name="AlertOctagon" size={20} className="text-error" />
            </div>
          </div>
        </div>

        <div className="bg-surface border border-border rounded-lg p-4">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm text-text-secondary">Pending</p>
              <p className="text-2xl font-bold text-text-primary">{pendingIncidents}</p>
            </div>
            <div className="w-10 h-10 bg-warning-50 rounded-full flex items-center justify-center">
              <Icon name="Clock" size={20} className="text-warning" />
            </div>
          </div>
        </div>
      </div>

      {/* Filters */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-6">
        <div>
          <label htmlFor="search-incident" className="block text-sm font-medium text-text-secondary mb-1">
            Search Incidents
          </label>
          <div className="relative">
            <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
              <Icon name="Search" size={16} className="text-text-secondary" />
            </div>
            <Input
              id="search-incident"
              type="text"
              placeholder="ID, Description, Station or Observer"
              value={searchTerm}
              onChange={handleSearchChange}
              className="pl-10"
            />
          </div>
        </div>

        <div>
          <label htmlFor="category-filter" className="block text-sm font-medium text-text-secondary mb-1">
            Filter by Category
          </label>
          <select
            id="category-filter"
            value={filterCategory}
            onChange={handleCategoryFilterChange}
            className="w-full h-10 rounded-md border border-input bg-background px-3 py-2 text-base ring-offset-background focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2 md:text-sm"
          >
            {incidentCategories.map(category => (
              <option key={category} value={category}>
                {category === 'all' ? 'All Categories' : category?.split('-')?.map(word => word?.charAt(0)?.toUpperCase() + word?.slice(1))?.join(' ') || category}
              </option>
            ))}
          </select>
        </div>

        <div>
          <label htmlFor="status-filter" className="block text-sm font-medium text-text-secondary mb-1">
            Filter by Status
          </label>
          <select
            id="status-filter"
            value={filterStatus}
            onChange={handleStatusFilterChange}
            className="w-full h-10 rounded-md border border-input bg-background px-3 py-2 text-base ring-offset-background focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2 md:text-sm"
          >
            <option value="all">All Statuses</option>
            <option value="resolved">Resolved</option>
            <option value="in-progress">In Progress</option>
            <option value="pending">Pending</option>
            <option value="escalated">Escalated</option>
          </select>
        </div>
      </div>

      {/* Incidents Table */}
      <div className="overflow-x-auto bg-surface border border-border rounded-lg">
        <table className="min-w-full divide-y divide-border">
          <thead>
            <tr>
              <th className="px-6 py-3 bg-surface-secondary text-left text-xs font-medium text-text-secondary uppercase tracking-wider">
                Incident ID
              </th>
              <th className="px-6 py-3 bg-surface-secondary text-left text-xs font-medium text-text-secondary uppercase tracking-wider">
                Description
              </th>
              <th className="px-6 py-3 bg-surface-secondary text-left text-xs font-medium text-text-secondary uppercase tracking-wider">
                Polling Station
              </th>
              <th className="px-6 py-3 bg-surface-secondary text-left text-xs font-medium text-text-secondary uppercase tracking-wider">
                Reported By
              </th>
              <th className="px-6 py-3 bg-surface-secondary text-left text-xs font-medium text-text-secondary uppercase tracking-wider">
                Severity
              </th>
              <th className="px-6 py-3 bg-surface-secondary text-left text-xs font-medium text-text-secondary uppercase tracking-wider">
                Status
              </th>
              <th className="px-6 py-3 bg-surface-secondary text-left text-xs font-medium text-text-secondary uppercase tracking-wider">
                Timestamp
              </th>
              <th className="px-6 py-3 bg-surface-secondary text-right text-xs font-medium text-text-secondary uppercase tracking-wider">
                Actions
              </th>
            </tr>
          </thead>
          <tbody className="bg-surface divide-y divide-border">
            {filteredIncidents?.length > 0 ? (
              filteredIncidents.map((incident) => (
                <tr key={incident?.id} className="hover:bg-surface-secondary transition-colors duration-150">
                  <td className="px-6 py-4 whitespace-nowrap text-sm font-mono text-text-secondary">
                    {incident?.id || 'N/A'}
                  </td>
                  <td className="px-6 py-4 max-w-[200px]">
                    <p className="text-sm text-text-primary truncate">{incident?.description || 'No description'}</p>
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap">
                    <div className="flex items-center">
                      <Icon name="MapPin" size={14} className="text-text-secondary mr-1" />
                      <span className="text-sm text-text-primary">{getStationName(incident?.pollingStation)}</span>
                    </div>
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap">
                    <div className="flex items-center">
                      <div className="w-6 h-6 bg-primary-100 rounded-full flex items-center justify-center mr-2">
                        <Icon name="User" size={12} className="text-primary-600" />
                      </div>
                      <span className="text-sm text-text-primary">{getObserverName(incident?.reportedBy)}</span>
                    </div>
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap">
                    {renderSeverityBadge(incident?.severity)}
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap">
                    {renderStatusBadge(incident?.status)}
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap text-sm text-text-secondary">
                    {formatTimestamp(incident?.timestamp)}
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap text-sm text-right">
                    <div className="flex justify-end space-x-2">
                      <Button
                        size="xs"
                        variant="ghost"
                        iconName="Eye"
                        onClick={() => handleIncidentSelect(incident)}
                        aria-label="View incident details"
                      />
                      <Button
                        size="xs"
                        variant="ghost"
                        iconName="Edit"
                        aria-label="Update incident"
                      />
                      <Button
                        size="xs"
                        variant="ghost"
                        iconName="MoreVertical"
                        aria-label="More options"
                      />
                    </div>
                  </td>
                </tr>
              ))
            ) : (
              <tr>
                <td colSpan="8" className="px-6 py-12 text-center">
                  <Icon name="Search" size={24} className="mx-auto mb-3 text-text-secondary" />
                  <p className="text-text-secondary">No incidents found with the current filters</p>
                  <Button
                    variant="ghost"
                    size="sm"
                    onClick={() => {
                      setSearchTerm('');
                      setFilterCategory('all');
                      setFilterStatus('all');
                    }}
                    className="mt-2"
                  >
                    Clear Filters
                  </Button>
                </td>
              </tr>
            )}
          </tbody>
        </table>
      </div>

      {/* Pagination */}
      <div className="flex items-center justify-between mt-6">
        <div className="text-sm text-text-secondary">
          Showing <span className="font-medium">{filteredIncidents?.length || 0}</span> of <span className="font-medium">{incidents?.length || 0}</span> incidents
        </div>
        <div className="flex items-center space-x-2">
          <Button
            variant="outline"
            size="sm"
            iconName="ChevronLeft"
            disabled
          >
            Previous
          </Button>
          <Button
            variant="outline"
            size="sm"
            iconName="ChevronRight"
            iconPosition="right"
            disabled
          >
            Next
          </Button>
        </div>
      </div>

      {/* Incident Detail Modal */}
      {isDetailModalOpen && selectedIncident && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-4">
          <div className="bg-surface rounded-lg shadow-elevation-3 max-w-3xl w-full max-h-[90vh] overflow-y-auto">
            <div className="flex items-center justify-between p-6 border-b border-border">
              <h3 className="text-lg font-semibold text-text-primary flex items-center">
                {renderSeverityBadge(selectedIncident?.severity)}
                <span className="ml-2">Incident Details</span>
              </h3>
              <Button
                variant="ghost"
                size="sm"
                iconName="X"
                onClick={handleCloseModal}
                aria-label="Close modal"
              />
            </div>
            <div className="p-6">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                {/* Left Column - Incident Details */}
                <div className="space-y-4">
                  <div>
                    <h4 className="text-base font-semibold text-text-primary mb-2 flex items-center">
                      <Icon name="Info" size={16} className="mr-2" />
                      Incident Information
                    </h4>
                    <div className="space-y-2">
                      <div className="flex justify-between">
                        <span className="text-sm text-text-secondary">Incident ID:</span>
                        <span className="text-sm font-medium text-text-primary">{selectedIncident?.id || 'N/A'}</span>
                      </div>
                      <div className="flex justify-between">
                        <span className="text-sm text-text-secondary">Reported:</span>
                        <span className="text-sm font-medium text-text-primary">{formatTimestamp(selectedIncident?.timestamp)}</span>
                      </div>
                      <div className="flex justify-between">
                        <span className="text-sm text-text-secondary">Category:</span>
                        <span className="text-sm font-medium text-text-primary capitalize">
                          {selectedIncident?.category ? selectedIncident.category.replace(/-/g, ' ') : 'N/A'}
                        </span>
                      </div>
                      <div className="flex justify-between">
                        <span className="text-sm text-text-secondary">Severity:</span>
                        <span className="text-sm font-medium text-text-primary capitalize">{selectedIncident?.severity || 'N/A'}</span>
                      </div>
                      <div className="flex justify-between">
                        <span className="text-sm text-text-secondary">Status:</span>
                        <span>{renderStatusBadge(selectedIncident?.status)}</span>
                      </div>
                    </div>
                  </div>
                  
                  <div>
                    <h4 className="text-base font-semibold text-text-primary mb-2">Description</h4>
                    <div className="bg-surface-secondary p-3 rounded-md border border-border">
                      <p className="text-sm text-text-primary">{selectedIncident?.description || 'No description available'}</p>
                    </div>
                  </div>
                  
                  {selectedIncident?.resolution && (
                    <div>
                      <h4 className="text-base font-semibold text-text-primary mb-2">Resolution</h4>
                      <div className="bg-surface-secondary p-3 rounded-md border border-border">
                        <p className="text-sm text-text-primary">{selectedIncident.resolution}</p>
                      </div>
                    </div>
                  )}
                  
                  {selectedIncident?.attachments && selectedIncident.attachments.length > 0 && (
                    <div>
                      <h4 className="text-base font-semibold text-text-primary mb-2">Attachments</h4>
                      <div className="grid grid-cols-2 gap-2">
                        {selectedIncident.attachments.map((attachment, index) => (
                          <div key={index} className="border border-border rounded-md overflow-hidden">
                            <div className="aspect-video bg-black relative">
                              <img 
                                src={attachment} 
                                alt={`Incident attachment ${index + 1}`} 
                                className="w-full h-full object-cover"
                              />
                              <Button
                                variant="ghost"
                                size="xs"
                                iconName="Download"
                                className="absolute bottom-1 right-1 bg-black bg-opacity-50 text-white hover:bg-opacity-70"
                                aria-label="Download attachment"
                              />
                            </div>
                          </div>
                        ))}
                      </div>
                    </div>
                  )}
                </div>
                
                {/* Right Column - Location & Reporter */}
                <div className="space-y-4">
                  <div>
                    <h4 className="text-base font-semibold text-text-primary mb-2 flex items-center">
                      <Icon name="MapPin" size={16} className="mr-2" />
                      Polling Station
                    </h4>
                    <div className="p-3 bg-surface-secondary border border-border rounded-lg">
                      <div className="space-y-2">
                        <div className="flex items-center justify-between">
                          <span className="text-sm text-text-secondary">Station ID:</span>
                          <span className="text-sm font-medium text-text-primary">{selectedIncident?.pollingStation || 'N/A'}</span>
                        </div>
                        <div className="flex items-center justify-between">
                          <span className="text-sm text-text-secondary">Name:</span>
                          <span className="text-sm font-medium text-text-primary">{getStationName(selectedIncident?.pollingStation)}</span>
                        </div>
                        <div className="flex items-center justify-between">
                          <span className="text-sm text-text-secondary">Parish:</span>
                          <span className="text-sm font-medium text-text-primary">
                            {stations?.find(s => s?.id === selectedIncident?.pollingStation)?.parish || 'Unknown'}
                          </span>
                        </div>
                      </div>
                      <div className="mt-2">
                        <Button
                          variant="outline"
                          size="xs"
                          iconName="ExternalLink"
                          className="w-full"
                        >
                          View Station Details
                        </Button>
                      </div>
                    </div>
                  </div>
                  
                  <div>
                    <h4 className="text-base font-semibold text-text-primary mb-2 flex items-center">
                      <Icon name="User" size={16} className="mr-2" />
                      Reported By
                    </h4>
                    <div className="p-3 bg-surface-secondary border border-border rounded-lg">
                      {observers?.find(o => o?.id === selectedIncident?.reportedBy) ? (
                        <div>
                          <div className="flex items-center mb-2">
                            <div className="w-8 h-8 bg-primary-100 rounded-full flex items-center justify-center mr-3">
                              <Icon name="User" size={16} className="text-primary-600" />
                            </div>
                            <div>
                              <p className="text-sm font-medium text-text-primary">
                                {getObserverName(selectedIncident?.reportedBy)}
                              </p>
                              <p className="text-xs text-text-secondary">
                                {observers.find(o => o?.id === selectedIncident?.reportedBy)?.role?.replace(/-/g, ' ') || 'Unknown'}
                              </p>
                            </div>
                          </div>
                          <div className="flex space-x-2 mt-2">
                            <Button
                              variant="outline"
                              size="xs"
                              iconName="Phone"
                              className="flex-1"
                            >
                              Call
                            </Button>
                            <Button
                              variant="outline"
                              size="xs"
                              iconName="MessageSquare"
                              className="flex-1"
                            >
                              Message
                            </Button>
                          </div>
                        </div>
                      ) : (
                        <div className="flex items-center">
                          <Icon name="User" size={16} className="text-text-secondary mr-2" />
                          <span className="text-sm text-text-secondary">{selectedIncident?.reportedBy || 'Unknown'} (Unknown Observer)</span>
                        </div>
                      )}
                    </div>
                  </div>
                  
                  <div>
                    <h4 className="text-base font-semibold text-text-primary mb-2 flex items-center">
                      <Icon name="Activity" size={16} className="mr-2" />
                      Actions
                    </h4>
                    <div className="space-y-2">
                      <Button
                        variant={selectedIncident?.status === 'resolved' ? 'ghost' : 'primary'}
                        size="sm"
                        iconName="CheckCircle"
                        className="w-full"
                        disabled={selectedIncident?.status === 'resolved'}
                      >
                        {selectedIncident?.status === 'resolved' ? 'Already Resolved' : 'Mark as Resolved'}
                      </Button>
                      <Button
                        variant="outline"
                        size="sm"
                        iconName="Send"
                        className="w-full"
                      >
                        Escalate to Management
                      </Button>
                      <Button
                        variant="outline"
                        size="sm"
                        iconName="Edit"
                        className="w-full"
                      >
                        Edit Incident Details
                      </Button>
                      <Button
                        variant="outline"
                        size="sm"
                        iconName="MessageSquare"
                        className="w-full"
                      >
                        Add Comment
                      </Button>
                    </div>
                  </div>
                </div>
              </div>
            </div>
            <div className="flex justify-end p-6 border-t border-border bg-surface-secondary">
              <Button
                variant="primary"
                size="sm"
                onClick={handleCloseModal}
              >
                Close
              </Button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default IncidentReports;