// src/pages/admin-control-center/index.jsx
import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import Header from 'components/ui/Header';
import Sidebar from 'components/ui/Sidebar';
import QuickActionPanel from 'components/ui/QuickActionPanel';
import StatusIndicator from 'components/ui/StatusIndicator';
import Button from 'components/ui/Button';
import Icon from 'components/AppIcon';
import { useSupabase } from 'context/SupabaseContext';
import { getObservers, getPollingStations, getIncidentReports, getSystemAnalytics } from 'utils/supabaseClient';

import ObserverManagement from './components/ObserverManagement';
import PollingStationOverview from './components/PollingStationOverview';
import SystemMetrics from './components/SystemMetrics';
import IncidentReports from './components/IncidentReports';
import DataExportTool from './components/DataExportTool';
import BroadcastMessage from './components/BroadcastMessage';

const AdminControlCenter = () => {
  const navigate = useNavigate();
  const { user } = useSupabase();
  
  const [activeTab, setActiveTab] = useState('observers');
  const [isLoading, setIsLoading] = useState(true);
  const [observers, setObservers] = useState([]);
  const [pollingStations, setPollingStations] = useState([]);
  const [incidentReports, setIncidentReports] = useState([]);
  const [systemAnalytics, setSystemAnalytics] = useState(null);
  const [refreshTrigger, setRefreshTrigger] = useState(0);

  // Tabs for the admin center
  const tabs = [
    { id: 'observers', label: 'Observer Management', icon: 'Users' },
    { id: 'stations', label: 'Polling Stations', icon: 'MapPin' },
    { id: 'incidents', label: 'Incident Reports', icon: 'AlertTriangle' },
    { id: 'system', label: 'System Metrics', icon: 'Activity' },
    { id: 'data', label: 'Data Export', icon: 'Database' },
    { id: 'broadcast', label: 'Broadcast', icon: 'Radio' }
  ];

  useEffect(() => {
    const loadAdminData = async () => {
      setIsLoading(true);
      try {
        // Load all required data
        const { data: observersData } = await getObservers();
        const { data: stationsData } = await getPollingStations();
        const { data: incidentsData } = await getIncidentReports();
        const { data: analyticsData } = await getSystemAnalytics();

        setObservers(observersData || []);
        setPollingStations(stationsData || []);
        setIncidentReports(incidentsData || []);
        setSystemAnalytics(analyticsData);
      } catch (error) {
        console.error('Error loading admin data:', error);
      } finally {
        setIsLoading(false);
      }
    };

    loadAdminData();
  }, [refreshTrigger]);

  const handleRefreshData = () => {
    setRefreshTrigger(prev => prev + 1);
  };

  const renderTabContent = () => {
    switch (activeTab) {
      case 'observers':
        return <ObserverManagement observers={observers} pollingStations={pollingStations} onRefresh={handleRefreshData} />;
      case 'stations':
        return <PollingStationOverview stations={pollingStations} observers={observers} onRefresh={handleRefreshData} />;
      case 'incidents':
        return <IncidentReports incidents={incidentReports} stations={pollingStations} observers={observers} onRefresh={handleRefreshData} />;
      case 'system':
        return <SystemMetrics analytics={systemAnalytics} onRefresh={handleRefreshData} />;
      case 'data':
        return <DataExportTool observers={observers} stations={pollingStations} incidents={incidentReports} />;
      case 'broadcast':
        return <BroadcastMessage observers={observers} />;
      default:
        return <div className="p-6">Select a tab to view content</div>;
    }
  };

  return (
    <div className="min-h-screen bg-background">
      <Header />
      <Sidebar />
      <QuickActionPanel />
      <StatusIndicator />

      {/* Main Content */}
      <main className="lg:ml-64 pt-16 pb-20 lg:pb-6">
        <div className="p-4 lg:p-6 max-w-7xl mx-auto">
          {/* Page Header */}
          <div className="mb-6">
            <div className="flex flex-col lg:flex-row lg:items-center lg:justify-between mb-4">
              <div>
                <h1 className="text-2xl lg:text-3xl font-bold text-text-primary mb-2">
                  Admin Control Center
                </h1>
                <div className="flex items-center space-x-4 text-text-secondary">
                  <span className="flex items-center space-x-1">
                    <Icon name="Shield" size={16} />
                    <span className="text-sm font-medium">Administrative Access</span>
                  </span>
                  <span className="flex items-center space-x-1">
                    <Icon name="Clock" size={16} />
                    <span className="text-sm">{new Date().toLocaleDateString()}</span>
                  </span>
                </div>
              </div>

              <div className="flex items-center space-x-3 mt-4 lg:mt-0">
                <Button 
                  variant="outline" 
                  size="sm"
                  iconName="RefreshCw"
                  onClick={handleRefreshData}
                  loading={isLoading}
                >
                  Refresh Data
                </Button>
                <Button 
                  variant="primary" 
                  size="sm"
                  iconName="Settings"
                >
                  Admin Settings
                </Button>
              </div>
            </div>

            {/* System Status Bar */}
            <div className="flex flex-wrap items-center justify-between p-3 bg-surface border border-border rounded-lg">
              <div className="flex items-center space-x-4">
                <div className="flex items-center space-x-2">
                  <div className="w-2 h-2 rounded-full bg-success animate-pulse" />
                  <span className="text-sm font-medium text-text-primary">
                    System Operational
                  </span>
                </div>
                <div className="flex items-center space-x-2 text-text-secondary">
                  <Icon name="Database" size={14} />
                  <span className="text-xs">
                    Data storage: {systemAnalytics?.systemHealth?.storageUsed || '--'}% used
                  </span>
                </div>
              </div>
              <div className="flex items-center space-x-4 mt-2 sm:mt-0">
                <div className="flex items-center space-x-2 text-text-secondary">
                  <Icon name="Users" size={14} />
                  <span className="text-xs">
                    Active observers: {systemAnalytics?.observerActivities?.activeObservers || '--'}
                  </span>
                </div>
                <div className="flex items-center space-x-2 text-text-secondary">
                  <Icon name="Activity" size={14} />
                  <span className="text-xs">
                    Uptime: {systemAnalytics?.systemHealth?.uptime || '--'}%
                  </span>
                </div>
              </div>
            </div>
          </div>

          {/* Tab Navigation */}
          <div className="mb-6 border-b border-border">
            <div className="flex flex-wrap -mb-px">
              {tabs.map(tab => (
                <button
                  key={tab.id}
                  onClick={() => setActiveTab(tab.id)}
                  className={`inline-flex items-center px-4 py-3 text-sm font-medium border-b-2 ${activeTab === tab.id
                    ? 'text-primary border-primary' :'text-text-secondary hover:text-text-primary border-transparent'
                  }`}
                >
                  <Icon name={tab.icon} size={16} className="mr-2" />
                  {tab.label}
                </button>
              ))}
            </div>
          </div>

          {/* Tab Content */}
          <div className="bg-surface border border-border rounded-lg overflow-hidden">
            {isLoading ? (
              <div className="flex items-center justify-center p-12">
                <Icon name="Loader" size={24} className="animate-spin mr-2" />
                <span>Loading administrative data...</span>
              </div>
            ) : (
              renderTabContent()
            )}
          </div>
        </div>
      </main>
    </div>
  );
};

export default AdminControlCenter;