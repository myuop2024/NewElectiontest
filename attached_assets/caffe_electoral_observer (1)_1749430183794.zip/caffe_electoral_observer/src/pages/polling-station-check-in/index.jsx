// src/pages/polling-station-check-in/index.jsx
import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import Header from 'components/ui/Header';
import Sidebar from 'components/ui/Sidebar';
import QuickActionPanel from 'components/ui/QuickActionPanel';
import StatusIndicator from 'components/ui/StatusIndicator';
import Button from 'components/ui/Button';
import Icon from 'components/AppIcon';

import MapView from './components/MapView';
import StationDetailsCard from './components/StationDetailsCard';
import GpsStatusIndicator from './components/GpsStatusIndicator';
import CameraCapture from './components/CameraCapture';
import CheckInButton from './components/CheckInButton';
import ManualOverride from './components/ManualOverride';
import SuccessConfirmation from './components/SuccessConfirmation';
import SmsStatus from './components/SmsStatus';

const PollingStationCheckIn = () => {
  const navigate = useNavigate();
  const [isOnline, setIsOnline] = useState(navigator.onLine);
  const [gpsStatus, setGpsStatus] = useState('searching'); // searching, accurate, approximate, poor, denied
  const [currentLocation, setCurrentLocation] = useState(null);
  const [locationAccuracy, setLocationAccuracy] = useState(null);
  const [checkInStatus, setCheckInStatus] = useState('pending'); // pending, success, error
  const [capturedPhotos, setCapturedPhotos] = useState([]);
  const [showManualOverride, setShowManualOverride] = useState(false);
  const [showSuccessConfirmation, setShowSuccessConfirmation] = useState(false);
  const [checkInData, setCheckInData] = useState(null);
  const [distanceToStation, setDistanceToStation] = useState(null);
  const [withinRange, setWithinRange] = useState(false);

  // Mock assigned polling station data
  const assignedStation = {
    id: 'PS-001-A',
    name: 'Half Way Tree Primary School',
    address: '123 Main Street, Half Way Tree, Kingston',
    coordinates: {
      latitude: 18.0179,
      longitude: -76.8099
    },
    acceptableRadius: 100, // meters
    checkInRequired: true
  };

  // Observer data
  const observerData = {
    id: 'OBS-2024-001',
    name: 'Michael Rodriguez',
    role: 'indoor-agent'
  };

  // GPS and location effects
  useEffect(() => {
    let watchId;

    const startLocationTracking = () => {
      if (!navigator.geolocation) {
        setGpsStatus('denied');
        return;
      }

      setGpsStatus('searching');

      const options = {
        enableHighAccuracy: true,
        timeout: 10000,
        maximumAge: 60000
      };

      watchId = navigator.geolocation.watchPosition(
        (position) => {
          const { latitude, longitude, accuracy } = position.coords;
          
          setCurrentLocation({ latitude, longitude });
          setLocationAccuracy(accuracy);
          
          // Determine GPS status based on accuracy
          if (accuracy <= 10) {
            setGpsStatus('accurate');
          } else if (accuracy <= 50) {
            setGpsStatus('approximate');
          } else {
            setGpsStatus('poor');
          }

          // Calculate distance to assigned station
          const distance = calculateDistance(
            latitude,
            longitude,
            assignedStation.coordinates.latitude,
            assignedStation.coordinates.longitude
          );
          
          setDistanceToStation(distance);
          setWithinRange(distance <= assignedStation.acceptableRadius);
        },
        (error) => {
          console.error('Location error:', error);
          switch (error.code) {
            case error.PERMISSION_DENIED:
              setGpsStatus('denied');
              break;
            case error.POSITION_UNAVAILABLE:
              setGpsStatus('poor');
              break;
            case error.TIMEOUT:
              setGpsStatus('poor');
              break;
            default:
              setGpsStatus('poor');
              break;
          }
        },
        options
      );
    };

    startLocationTracking();

    return () => {
      if (watchId) {
        navigator.geolocation.clearWatch(watchId);
      }
    };
  }, []);

  // Network status monitoring
  useEffect(() => {
    const handleOnline = () => setIsOnline(true);
    const handleOffline = () => setIsOnline(false);

    window.addEventListener('online', handleOnline);
    window.addEventListener('offline', handleOffline);

    return () => {
      window.removeEventListener('online', handleOnline);
      window.removeEventListener('offline', handleOffline);
    };
  }, []);

  // Helper function to calculate distance between two coordinates
  const calculateDistance = (lat1, lon1, lat2, lon2) => {
    const R = 6371e3; // Earth's radius in meters
    const φ1 = lat1 * Math.PI/180;
    const φ2 = lat2 * Math.PI/180;
    const Δφ = (lat2-lat1) * Math.PI/180;
    const Δλ = (lon2-lon1) * Math.PI/180;

    const a = Math.sin(Δφ/2) * Math.sin(Δφ/2) +
              Math.cos(φ1) * Math.cos(φ2) *
              Math.sin(Δλ/2) * Math.sin(Δλ/2);
    const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1-a));

    return R * c; // Distance in meters
  };

  // Check-in handler
  const handleCheckIn = async () => {
    try {
      const timestamp = new Date();
      const checkInInfo = {
        observerId: observerData.id,
        stationId: assignedStation.id,
        timestamp: timestamp.toISOString(),
        location: currentLocation,
        accuracy: locationAccuracy,
        photos: capturedPhotos,
        distance: distanceToStation,
        method: withinRange ? 'automatic' : 'manual',
        connectionStatus: isOnline ? 'online' : 'offline'
      };

      // Simulate API call
      if (isOnline) {
        // Online check-in
        console.log('Processing online check-in:', checkInInfo);
        
        // Simulate delay
        await new Promise(resolve => setTimeout(resolve, 2000));
        
        setCheckInData({
          ...checkInInfo,
          confirmationCode: `CIN-${Date.now()}`,
          qrCode: `data:image/svg+xml;base64,${btoa('<svg>Mock QR Code</svg>')}`
        });
        
        setCheckInStatus('success');
        setShowSuccessConfirmation(true);
      } else {
        // Offline SMS fallback
        console.log('Processing offline SMS check-in:', checkInInfo);
        
        // Store for later sync
        const pendingCheckIns = JSON.parse(localStorage.getItem('pendingCheckIns') || '[]');
        pendingCheckIns.push(checkInInfo);
        localStorage.setItem('pendingCheckIns', JSON.stringify(pendingCheckIns));
        
        setCheckInData({
          ...checkInInfo,
          confirmationCode: `SMS-${Date.now()}`,
          status: 'pending_sync'
        });
        
        setCheckInStatus('success');
        setShowSuccessConfirmation(true);
      }
    } catch (error) {
      console.error('Check-in error:', error);
      setCheckInStatus('error');
    }
  };

  // Manual override handler
  const handleManualOverride = () => {
    setShowManualOverride(true);
  };

  // Photo capture handler
  const handlePhotoCaptured = (photoData) => {
    setCapturedPhotos(prev => [...prev, {
      id: Date.now(),
      data: photoData,
      timestamp: new Date().toISOString(),
      type: 'station_exterior'
    }]);
  };

  // Navigate back
  const handleGoBack = () => {
    navigate('/observer-dashboard');
  };

  // Navigation to error resolution
  const handleTroubleshooting = () => {
    navigate('/polling-station-check-in-error-resolution');
  };

  return (
    <div className="min-h-screen bg-background">
      <Header />
      <Sidebar />
      <QuickActionPanel />
      <StatusIndicator />

      {/* Main Content */}
      <main className="lg:ml-64 pt-16 pb-20 lg:pb-6">
        <div className="p-4 lg:p-6 max-w-7xl mx-auto">
          {/* Page Header */}
          <div className="mb-6">
            <div className="flex items-center justify-between mb-4">
              <div className="flex items-center space-x-3">
                <Button
                  variant="ghost"
                  size="sm"
                  iconName="ArrowLeft"
                  onClick={handleGoBack}
                  className="lg:hidden"
                />
                <div>
                  <h1 className="text-2xl lg:text-3xl font-bold text-text-primary">
                    Polling Station Check-in
                  </h1>
                  <p className="text-text-secondary mt-1">
                    Verify your location and check in to your assigned station
                  </p>
                </div>
              </div>
              
              <div className="flex items-center space-x-2">
                <Button
                  variant="outline"
                  size="sm"
                  iconName="HelpCircle"
                  onClick={handleTroubleshooting}
                >
                  <span className="hidden md:inline ml-2">Help</span>
                </Button>
              </div>
            </div>

            {/* Connection Status */}
            <div className="flex items-center justify-between p-3 bg-surface border border-border rounded-lg">
              <div className="flex items-center space-x-4">
                <div className="flex items-center space-x-2">
                  <div className={`w-2 h-2 rounded-full ${
                    isOnline ? 'bg-success animate-pulse' : 'bg-error'
                  }`} />
                  <span className="text-sm font-medium text-text-primary">
                    {isOnline ? 'Online Mode' : 'Offline Mode'}
                  </span>
                </div>
                {!isOnline && (
                  <div className="flex items-center space-x-2 text-warning">
                    <Icon name="MessageSquare" size={14} />
                    <span className="text-xs font-medium">SMS Backup Active</span>
                  </div>
                )}
              </div>
              
              <GpsStatusIndicator 
                status={gpsStatus}
                accuracy={locationAccuracy}
              />
            </div>
          </div>

          {/* Main Content Grid */}
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
            {/* Map and Location Section */}
            <div className="lg:col-span-8 space-y-6">
              {/* Map View */}
              <div className="card overflow-hidden">
                <MapView
                  currentLocation={currentLocation}
                  assignedStation={assignedStation}
                  accuracy={locationAccuracy}
                  gpsStatus={gpsStatus}
                  distanceToStation={distanceToStation}
                />
              </div>

              {/* Camera Section */}
              <div className="card p-6">
                <div className="flex items-center justify-between mb-4">
                  <h3 className="text-lg font-semibold text-text-primary">
                    Station Verification Photos
                  </h3>
                  <span className="text-sm text-text-secondary">
                    {capturedPhotos.length} photos captured
                  </span>
                </div>
                
                <CameraCapture
                  onPhotoCaptured={handlePhotoCaptured}
                  capturedPhotos={capturedPhotos}
                />
              </div>
            </div>

            {/* Sidebar - Station Details and Actions */}
            <div className="lg:col-span-4 space-y-6">
              {/* Station Details */}
              <StationDetailsCard
                station={assignedStation}
                observer={observerData}
                distance={distanceToStation}
                withinRange={withinRange}
              />

              {/* Check-in Actions */}
              <div className="card p-6">
                <h3 className="text-lg font-semibold text-text-primary mb-4">
                  Check-in Actions
                </h3>
                
                <div className="space-y-4">
                  <CheckInButton
                    withinRange={withinRange}
                    gpsStatus={gpsStatus}
                    currentLocation={currentLocation}
                    onCheckIn={handleCheckIn}
                    disabled={checkInStatus === 'success'}
                    loading={checkInStatus === 'loading'}
                  />
                  
                  {(!withinRange || gpsStatus === 'poor' || gpsStatus === 'denied') && (
                    <Button
                      variant="outline"
                      fullWidth
                      iconName="Settings"
                      onClick={handleManualOverride}
                      disabled={checkInStatus === 'success'}
                    >
                      Manual Override
                    </Button>
                  )}
                  
                  {!isOnline && (
                    <SmsStatus />
                  )}
                </div>
              </div>

              {/* Location Status */}
              <div className="card p-6">
                <h3 className="text-lg font-semibold text-text-primary mb-4">
                  Location Status
                </h3>
                
                <div className="space-y-3">
                  <div className="flex items-center justify-between">
                    <span className="text-sm text-text-primary">GPS Signal</span>
                    <GpsStatusIndicator status={gpsStatus} accuracy={locationAccuracy} compact />
                  </div>
                  
                  <div className="flex items-center justify-between">
                    <span className="text-sm text-text-primary">Distance to Station</span>
                    <span className={`text-sm font-medium ${
                      withinRange ? 'text-success' : 'text-warning'
                    }`}>
                      {distanceToStation ? `${Math.round(distanceToStation)}m` : 'Calculating...'}
                    </span>
                  </div>
                  
                  <div className="flex items-center justify-between">
                    <span className="text-sm text-text-primary">Within Range</span>
                    <div className="flex items-center space-x-2">
                      <div className={`w-2 h-2 rounded-full ${
                        withinRange ? 'bg-success' : 'bg-warning'
                      }`} />
                      <span className={`text-sm font-medium ${
                        withinRange ? 'text-success' : 'text-warning'
                      }`}>
                        {withinRange ? 'Yes' : 'No'}
                      </span>
                    </div>
                  </div>
                  
                  {currentLocation && (
                    <div className="mt-4 p-3 bg-surface-secondary rounded-lg">
                      <p className="text-xs text-text-secondary mb-1">Current Coordinates</p>
                      <p className="text-xs font-mono text-text-primary">
                        {currentLocation.latitude.toFixed(6)}, {currentLocation.longitude.toFixed(6)}
                      </p>
                      {locationAccuracy && (
                        <p className="text-xs text-text-secondary mt-1">
                          Accuracy: ±{Math.round(locationAccuracy)}m
                        </p>
                      )}
                    </div>
                  )}
                </div>
              </div>
            </div>
          </div>
        </div>
      </main>

      {/* Modals */}
      {showManualOverride && (
        <ManualOverride
          station={assignedStation}
          observer={observerData}
          onClose={() => setShowManualOverride(false)}
          onConfirm={handleCheckIn}
        />
      )}
      
      {showSuccessConfirmation && checkInData && (
        <SuccessConfirmation
          checkInData={checkInData}
          onClose={() => {
            setShowSuccessConfirmation(false);
            navigate('/observer-dashboard');
          }}
        />
      )}
    </div>
  );
};

export default PollingStationCheckIn;