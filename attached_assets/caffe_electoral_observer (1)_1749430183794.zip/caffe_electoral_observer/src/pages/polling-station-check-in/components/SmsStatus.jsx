// src/pages/polling-station-check-in/components/SmsStatus.jsx
import React, { useState, useEffect } from 'react';
import Icon from 'components/AppIcon';

const SmsStatus = () => {
  const [smsStatus, setSmsStatus] = useState('ready'); // ready, sending, sent, error
  const [lastSmsTime, setLastSmsTime] = useState(null);
  const [pendingData, setPendingData] = useState(null);

  useEffect(() => {
    // Check for pending check-ins in localStorage
    const pending = localStorage.getItem('pendingCheckIns');
    if (pending) {
      try {
        const pendingArray = JSON.parse(pending);
        setPendingData(pendingArray);
      } catch (error) {
        console.error('Error parsing pending check-ins:', error);
      }
    }
  }, []);

  const getStatusConfig = () => {
    switch (smsStatus) {
      case 'ready':
        return {
          icon: 'MessageSquare',
          color: 'text-primary',
          bgColor: 'bg-primary-50',
          borderColor: 'border-primary-200',
          text: 'SMS Backup Ready',
          description: 'Check-in data will be sent via SMS when you proceed'
        };
      case 'sending':
        return {
          icon: 'Send',
          color: 'text-warning',
          bgColor: 'bg-warning-50',
          borderColor: 'border-warning-200',
          text: 'Sending SMS...',
          description: 'Transmitting check-in data via SMS backup'
        };
      case 'sent':
        return {
          icon: 'CheckCircle',
          color: 'text-success',
          bgColor: 'bg-success-50',
          borderColor: 'border-success-200',
          text: 'SMS Sent Successfully',
          description: 'Check-in data transmitted and will sync when online'
        };
      case 'error':
        return {
          icon: 'AlertTriangle',
          color: 'text-error',
          bgColor: 'bg-error-50',
          borderColor: 'border-error-200',
          text: 'SMS Failed',
          description: 'Unable to send SMS backup - try again or contact support'
        };
      default:
        return {
          icon: 'MessageSquare',
          color: 'text-text-secondary',
          bgColor: 'bg-surface-secondary',
          borderColor: 'border-border',
          text: 'SMS Status Unknown',
          description: 'SMS backup status is unclear'
        };
    }
  };

  const config = getStatusConfig();

  const simulateSmsProcess = () => {
    setSmsStatus('sending');
    
    // Simulate SMS sending process
    setTimeout(() => {
      // 80% success rate for demo
      const success = Math.random() > 0.2;
      
      if (success) {
        setSmsStatus('sent');
        setLastSmsTime(new Date());
      } else {
        setSmsStatus('error');
      }
    }, 3000);
  };

  const retrySmsSend = () => {
    simulateSmsProcess();
  };

  return (
    <div className={`p-4 rounded-lg border ${config.bgColor} ${config.borderColor}`}>
      {/* Status Header */}
      <div className="flex items-center space-x-3 mb-3">
        <Icon 
          name={config.icon} 
          size={20} 
          className={`${config.color} ${
            smsStatus === 'sending' ? 'animate-pulse' : ''
          }`} 
        />
        <div className="flex-1">
          <h4 className={`font-medium ${config.color}`}>
            {config.text}
          </h4>
          <p className="text-sm text-text-secondary mt-1">
            {config.description}
          </p>
        </div>
      </div>

      {/* SMS Details */}
      <div className="space-y-3">
        {/* Network Status */}
        <div className="flex items-center justify-between text-sm">
          <span className="text-text-secondary">Network Status</span>
          <div className="flex items-center space-x-2">
            <div className="w-2 h-2 bg-error rounded-full" />
            <span className="text-error font-medium">Offline</span>
          </div>
        </div>

        {/* SMS Backup Status */}
        <div className="flex items-center justify-between text-sm">
          <span className="text-text-secondary">SMS Backup</span>
          <div className="flex items-center space-x-2">
            <div className={`w-2 h-2 rounded-full ${
              smsStatus === 'ready' || smsStatus === 'sent' ? 'bg-success' :
              smsStatus === 'sending' ? 'bg-warning animate-pulse' : 'bg-error'
            }`} />
            <span className={`font-medium ${
              smsStatus === 'ready' || smsStatus === 'sent' ? 'text-success' :
              smsStatus === 'sending' ? 'text-warning' : 'text-error'
            }`}>
              {smsStatus === 'ready' ? 'Active' :
               smsStatus === 'sending' ? 'Sending' :
               smsStatus === 'sent' ? 'Sent' : 'Failed'}
            </span>
          </div>
        </div>

        {/* Last SMS Time */}
        {lastSmsTime && (
          <div className="flex items-center justify-between text-sm">
            <span className="text-text-secondary">Last SMS</span>
            <span className="text-text-primary font-mono">
              {lastSmsTime.toLocaleTimeString()}
            </span>
          </div>
        )}

        {/* Pending Data Count */}
        {pendingData && pendingData.length > 0 && (
          <div className="flex items-center justify-between text-sm">
            <span className="text-text-secondary">Pending Sync</span>
            <span className="text-warning font-medium">
              {pendingData.length} item{pendingData.length !== 1 ? 's' : ''}
            </span>
          </div>
        )}
      </div>

      {/* Action Buttons */}
      {smsStatus === 'error' && (
        <div className="mt-4">
          <button
            onClick={retrySmsSend}
            className="w-full flex items-center justify-center space-x-2 py-2 px-3 bg-error text-white rounded-lg hover:bg-error-600 transition-colors"
          >
            <Icon name="RefreshCw" size={16} />
            <span className="text-sm font-medium">Retry SMS</span>
          </button>
        </div>
      )}

      {/* Information Box */}
      <div className="mt-4 p-3 bg-white bg-opacity-50 rounded border border-white border-opacity-30">
        <div className="flex items-start space-x-2">
          <Icon name="Info" size={16} className="text-text-secondary mt-0.5" />
          <div className="text-xs text-text-secondary">
            <p className="font-medium mb-1">SMS Backup Information</p>
            <ul className="space-y-1">
              <li>• Check-in data will be transmitted via SMS</li>
              <li>• Data automatically syncs when connection restores</li>
              <li>• SMS charges may apply from your carrier</li>
              <li>• Confirmation codes remain valid</li>
            </ul>
          </div>
        </div>
      </div>

      {/* Test SMS Button (for demo purposes) */}
      <div className="mt-3">
        <button
          onClick={simulateSmsProcess}
          disabled={smsStatus === 'sending'}
          className="w-full text-xs text-text-secondary hover:text-text-primary transition-colors py-1"
        >
          Test SMS Connection
        </button>
      </div>
    </div>
  );
};

export default SmsStatus;