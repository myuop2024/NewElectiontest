// src/pages/polling-station-check-in/components/StationDetailsCard.jsx
import React from 'react';
import Icon from 'components/AppIcon';

const StationDetailsCard = ({ station, observer, distance, withinRange }) => {
  const formatCoordinates = (lat, lng) => {
    return `${lat?.toFixed(6)}, ${lng?.toFixed(6)}`;
  };

  return (
    <div className="card p-6">
      <div className="flex items-center justify-between mb-4">
        <h3 className="text-lg font-semibold text-text-primary">
          Station Assignment
        </h3>
        <div className={`flex items-center space-x-1 px-2 py-1 rounded-full text-xs font-medium ${
          withinRange ? 'bg-success-50 text-success' : 'bg-warning-50 text-warning'
        }`}>
          <div className={`w-1.5 h-1.5 rounded-full ${
            withinRange ? 'bg-success' : 'bg-warning'
          }`} />
          <span>{withinRange ? 'In Range' : 'Out of Range'}</span>
        </div>
      </div>

      <div className="space-y-4">
        {/* Station Information */}
        <div className="bg-surface-secondary rounded-lg p-4">
          <div className="flex items-start space-x-3">
            <div className="w-10 h-10 bg-primary-100 rounded-lg flex items-center justify-center flex-shrink-0">
              <Icon name="Building" size={20} className="text-primary" />
            </div>
            <div className="flex-1 min-w-0">
              <h4 className="font-semibold text-text-primary truncate">
                {station?.name}
              </h4>
              <p className="text-sm text-text-secondary mt-1">
                ID: {station?.id}
              </p>
              <div className="flex items-start space-x-1 mt-2">
                <Icon name="MapPin" size={14} className="text-text-tertiary mt-0.5 flex-shrink-0" />
                <p className="text-sm text-text-secondary">
                  {station?.address}
                </p>
              </div>
            </div>
          </div>
        </div>

        {/* Observer Assignment */}
        <div className="bg-surface-secondary rounded-lg p-4">
          <div className="flex items-start space-x-3">
            <div className="w-10 h-10 bg-secondary-100 rounded-lg flex items-center justify-center flex-shrink-0">
              <Icon name="User" size={20} className="text-secondary" />
            </div>
            <div className="flex-1 min-w-0">
              <h4 className="font-semibold text-text-primary">
                {observer?.name}
              </h4>
              <p className="text-sm text-text-secondary mt-1">
                ID: {observer?.id}
              </p>
              <p className="text-sm text-text-secondary capitalize">
                Role: {observer?.role?.replace('-', ' ')}
              </p>
            </div>
          </div>
        </div>

        {/* Location Details */}
        <div className="space-y-3">
          <h5 className="font-medium text-text-primary">Location Details</h5>
          
          <div className="grid grid-cols-1 gap-3">
            <div className="flex items-center justify-between py-2 border-b border-border">
              <span className="text-sm text-text-secondary">Expected Coordinates</span>
              <span className="text-sm font-mono text-text-primary">
                {formatCoordinates(station?.coordinates?.latitude, station?.coordinates?.longitude)}
              </span>
            </div>
            
            <div className="flex items-center justify-between py-2 border-b border-border">
              <span className="text-sm text-text-secondary">Acceptable Radius</span>
              <span className="text-sm font-medium text-text-primary">
                {station?.acceptableRadius}m
              </span>
            </div>
            
            {distance !== null && (
              <div className="flex items-center justify-between py-2 border-b border-border">
                <span className="text-sm text-text-secondary">Current Distance</span>
                <span className={`text-sm font-medium ${
                  withinRange ? 'text-success' : 'text-warning'
                }`}>
                  {Math.round(distance)}m
                </span>
              </div>
            )}
            
            <div className="flex items-center justify-between py-2">
              <span className="text-sm text-text-secondary">Check-in Required</span>
              <div className="flex items-center space-x-2">
                <div className={`w-2 h-2 rounded-full ${
                  station?.checkInRequired ? 'bg-warning' : 'bg-success'
                }`} />
                <span className="text-sm font-medium text-text-primary">
                  {station?.checkInRequired ? 'Yes' : 'No'}
                </span>
              </div>
            </div>
          </div>
        </div>

        {/* Quick Actions */}
        <div className="flex space-x-2">
          <button className="flex-1 flex items-center justify-center space-x-2 py-2 px-3 bg-primary-50 text-primary rounded-lg hover:bg-primary-100 transition-colors">
            <Icon name="Navigation" size={14} />
            <span className="text-sm font-medium">Directions</span>
          </button>
          
          <button className="flex-1 flex items-center justify-center space-x-2 py-2 px-3 bg-secondary-50 text-secondary rounded-lg hover:bg-secondary-100 transition-colors">
            <Icon name="Phone" size={14} />
            <span className="text-sm font-medium">Contact</span>
          </button>
        </div>
      </div>
    </div>
  );
};

export default StationDetailsCard;