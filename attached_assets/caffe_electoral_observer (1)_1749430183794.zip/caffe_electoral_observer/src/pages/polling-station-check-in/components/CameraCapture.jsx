// src/pages/polling-station-check-in/components/CameraCapture.jsx
import React, { useState, useRef } from 'react';
import Icon from 'components/AppIcon';
import Button from 'components/ui/Button';

const CameraCapture = ({ onPhotoCaptured, capturedPhotos }) => {
  const [isCapturing, setIsCapturing] = useState(false);
  const [showCamera, setShowCamera] = useState(false);
  const [cameraError, setCameraError] = useState(null);
  const [selectedPhoto, setSelectedPhoto] = useState(null);
  const fileInputRef = useRef(null);
  const videoRef = useRef(null);
  const canvasRef = useRef(null);
  const streamRef = useRef(null);

  const startCamera = async () => {
    try {
      setCameraError(null);
      setShowCamera(true);
      
      const stream = await navigator.mediaDevices.getUserMedia({
        video: {
          facingMode: 'environment', // Use back camera
          width: { ideal: 1920 },
          height: { ideal: 1080 }
        }
      });
      
      streamRef.current = stream;
      if (videoRef.current) {
        videoRef.current.srcObject = stream;
      }
    } catch (error) {
      console.error('Camera access error:', error);
      setCameraError(error.message);
      setShowCamera(false);
    }
  };

  const stopCamera = () => {
    if (streamRef.current) {
      streamRef.current.getTracks().forEach(track => track.stop());
      streamRef.current = null;
    }
    setShowCamera(false);
  };

  const capturePhoto = () => {
    if (!videoRef.current || !canvasRef.current) return;
    
    setIsCapturing(true);
    
    const video = videoRef.current;
    const canvas = canvasRef.current;
    const context = canvas.getContext('2d');
    
    canvas.width = video.videoWidth;
    canvas.height = video.videoHeight;
    
    context.drawImage(video, 0, 0);
    
    canvas.toBlob((blob) => {
      const photoData = {
        blob,
        dataUrl: canvas.toDataURL('image/jpeg', 0.8),
        timestamp: new Date().toISOString(),
        type: 'camera_capture'
      };
      
      onPhotoCaptured?.(photoData);
      setIsCapturing(false);
      
      // Optional: Stop camera after capture
      stopCamera();
    }, 'image/jpeg', 0.8);
  };

  const handleFileUpload = (event) => {
    const file = event.target.files?.[0];
    if (!file) return;
    
    const reader = new FileReader();
    reader.onload = (e) => {
      const photoData = {
        blob: file,
        dataUrl: e.target?.result,
        timestamp: new Date().toISOString(),
        type: 'file_upload'
      };
      
      onPhotoCaptured?.(photoData);
    };
    reader.readAsDataURL(file);
  };

  const deletePhoto = (index) => {
    // This would typically call a parent function to remove the photo
    console.log('Delete photo at index:', index);
  };

  const viewPhoto = (photo) => {
    setSelectedPhoto(photo);
  };

  return (
    <div className="space-y-4">
      {/* Camera Controls */}
      <div className="flex flex-wrap gap-3">
        {!showCamera ? (
          <>
            <Button
              variant="primary"
              iconName="Camera"
              onClick={startCamera}
              className="flex-1 min-w-0"
            >
              Take Photo
            </Button>
            
            <Button
              variant="outline"
              iconName="Upload"
              onClick={() => fileInputRef.current?.click()}
              className="flex-1 min-w-0"
            >
              Upload Photo
            </Button>
          </>
        ) : (
          <>
            <Button
              variant="success"
              iconName="Camera"
              onClick={capturePhoto}
              disabled={isCapturing}
              loading={isCapturing}
              className="flex-1 min-w-0"
            >
              {isCapturing ? 'Capturing...' : 'Capture'}
            </Button>
            
            <Button
              variant="outline"
              iconName="X"
              onClick={stopCamera}
              className="flex-1 min-w-0"
            >
              Cancel
            </Button>
          </>
        )}
      </div>

      {/* Hidden file input */}
      <input
        ref={fileInputRef}
        type="file"
        accept="image/*"
        capture="environment"
        onChange={handleFileUpload}
        className="hidden"
      />

      {/* Camera Error */}
      {cameraError && (
        <div className="p-4 bg-error-50 border border-error-200 rounded-lg">
          <div className="flex items-center space-x-2">
            <Icon name="AlertTriangle" size={16} className="text-error" />
            <span className="text-sm font-medium text-error">Camera Error</span>
          </div>
          <p className="text-sm text-error mt-1">
            {cameraError}
          </p>
          <p className="text-xs text-text-secondary mt-2">
            Try using the upload button to select photos from your device.
          </p>
        </div>
      )}

      {/* Camera View */}
      {showCamera && (
        <div className="relative bg-black rounded-lg overflow-hidden">
          <video
            ref={videoRef}
            autoPlay
            playsInline
            className="w-full h-64 object-cover"
          />
          
          {/* Camera overlay */}
          <div className="absolute inset-0 flex items-center justify-center pointer-events-none">
            <div className="border-2 border-white border-dashed rounded-lg w-48 h-32 opacity-50" />
          </div>
          
          {/* Camera instructions */}
          <div className="absolute bottom-4 left-4 right-4">
            <div className="bg-black bg-opacity-50 text-white p-3 rounded-lg">
              <p className="text-sm font-medium">Position the station entrance in the frame</p>
              <p className="text-xs opacity-75 mt-1">
                Ensure good lighting and the station sign is visible
              </p>
            </div>
          </div>
        </div>
      )}

      {/* Hidden canvas for photo capture */}
      <canvas ref={canvasRef} className="hidden" />

      {/* Captured Photos Gallery */}
      {capturedPhotos?.length > 0 && (
        <div className="space-y-3">
          <h4 className="font-medium text-text-primary">
            Captured Photos ({capturedPhotos.length})
          </h4>
          
          <div className="grid grid-cols-2 md:grid-cols-3 gap-3">
            {capturedPhotos.map((photo, index) => (
              <div key={photo.id || index} className="relative group">
                <div className="aspect-video bg-surface-secondary rounded-lg overflow-hidden">
                  <img
                    src={photo.dataUrl || photo.data?.dataUrl}
                    alt={`Station photo ${index + 1}`}
                    className="w-full h-full object-cover cursor-pointer hover:opacity-80 transition-opacity"
                    onClick={() => viewPhoto(photo)}
                  />
                </div>
                
                {/* Photo overlay */}
                <div className="absolute inset-0 bg-black bg-opacity-0 group-hover:bg-opacity-20 transition-all duration-200 rounded-lg flex items-center justify-center">
                  <div className="opacity-0 group-hover:opacity-100 transition-opacity flex space-x-2">
                    <button
                      onClick={() => viewPhoto(photo)}
                      className="w-8 h-8 bg-white rounded-full flex items-center justify-center shadow-md hover:bg-surface-secondary transition-colors"
                    >
                      <Icon name="Eye" size={14} className="text-text-primary" />
                    </button>
                    <button
                      onClick={() => deletePhoto(index)}
                      className="w-8 h-8 bg-white rounded-full flex items-center justify-center shadow-md hover:bg-error-50 transition-colors"
                    >
                      <Icon name="Trash2" size={14} className="text-error" />
                    </button>
                  </div>
                </div>
                
                {/* Photo timestamp */}
                <div className="absolute bottom-2 left-2 bg-black bg-opacity-50 text-white px-2 py-1 rounded text-xs">
                  {new Date(photo.timestamp || photo.data?.timestamp).toLocaleTimeString()}
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Photo Viewer Modal */}
      {selectedPhoto && (
        <div className="fixed inset-0 z-500 bg-black bg-opacity-75 flex items-center justify-center p-4">
          <div className="relative max-w-4xl max-h-full">
            <img
              src={selectedPhoto.dataUrl || selectedPhoto.data?.dataUrl}
              alt="Station photo"
              className="max-w-full max-h-full object-contain"
            />
            
            <button
              onClick={() => setSelectedPhoto(null)}
              className="absolute top-4 right-4 w-10 h-10 bg-white rounded-full flex items-center justify-center shadow-lg hover:bg-surface-secondary transition-colors"
            >
              <Icon name="X" size={20} className="text-text-primary" />
            </button>
            
            <div className="absolute bottom-4 left-4 right-4 bg-black bg-opacity-50 text-white p-4 rounded-lg">
              <p className="font-medium">
                Captured: {new Date(selectedPhoto.timestamp || selectedPhoto.data?.timestamp).toLocaleString()}
              </p>
              <p className="text-sm opacity-75 mt-1">
                Type: {selectedPhoto.type || selectedPhoto.data?.type || 'Unknown'}
              </p>
            </div>
          </div>
        </div>
      )}

      {/* Instructions */}
      {capturedPhotos?.length === 0 && (
        <div className="p-4 bg-primary-50 border border-primary-200 rounded-lg">
          <div className="flex items-start space-x-3">
            <Icon name="Info" size={16} className="text-primary mt-0.5" />
            <div>
              <p className="text-sm font-medium text-primary">Photo Guidelines</p>
              <ul className="text-xs text-primary-700 mt-2 space-y-1">
                <li>• Capture the main entrance of the polling station</li>
                <li>• Ensure the station name/number is clearly visible</li>
                <li>• Take photos from different angles if needed</li>
                <li>• Good lighting helps with verification</li>
              </ul>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default CameraCapture;