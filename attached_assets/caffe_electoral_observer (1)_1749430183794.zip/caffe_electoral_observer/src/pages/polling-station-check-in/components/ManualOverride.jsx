// src/pages/polling-station-check-in/components/ManualOverride.jsx
import React, { useState } from 'react';
import Button from 'components/ui/Button';
import Icon from 'components/AppIcon';

const ManualOverride = ({ station, observer, onClose, onConfirm }) => {
  const [step, setStep] = useState(1);
  const [reason, setReason] = useState('');
  const [verification, setVerification] = useState({
    stationName: '',
    observerConfirmation: false,
    supervisorContact: '',
    additionalNotes: ''
  });
  const [isSubmitting, setIsSubmitting] = useState(false);

  const reasons = [
    { id: 'gps_poor', label: 'Poor GPS signal', description: 'GPS accuracy is insufficient for automatic check-in' },
    { id: 'gps_denied', label: 'Location access denied', description: 'Unable to access device location services' },
    { id: 'location_error', label: 'Location service error', description: 'Technical issues with location detection' },
    { id: 'urgent_checkin', label: 'Urgent check-in required', description: 'Emergency or time-sensitive situation' },
    { id: 'other', label: 'Other reason', description: 'Specify in additional notes below' }
  ];

  const handleReasonSelect = (reasonId) => {
    setReason(reasonId);
    setStep(2);
  };

  const handleVerificationChange = (field, value) => {
    setVerification(prev => ({ ...prev, [field]: value }));
  };

  const isStep2Valid = () => {
    return (
      verification.stationName.toLowerCase().includes(station?.name?.toLowerCase().split(' ')[0] || '') &&
      verification.observerConfirmation &&
      verification.supervisorContact.length >= 5
    );
  };

  const handleSubmit = async () => {
    if (!isStep2Valid()) return;

    setIsSubmitting(true);
    
    try {
      // Simulate processing delay
      await new Promise(resolve => setTimeout(resolve, 2000));
      
      // Call the parent's confirm handler with manual override data
      await onConfirm({
        type: 'manual_override',
        reason,
        verification,
        timestamp: new Date().toISOString(),
        requiresSupervisorReview: true
      });
      
      onClose();
    } catch (error) {
      console.error('Manual override error:', error);
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <div className="fixed inset-0 z-500 bg-black bg-opacity-50 flex items-center justify-center p-4">
      <div className="bg-surface rounded-lg shadow-elevation-4 w-full max-w-2xl max-h-full overflow-y-auto">
        {/* Header */}
        <div className="p-6 border-b border-border">
          <div className="flex items-center justify-between">
            <div>
              <h2 className="text-xl font-bold text-text-primary">
                Manual Check-in Override
              </h2>
              <p className="text-text-secondary mt-1">
                Complete manual verification for check-in
              </p>
            </div>
            <button
              onClick={onClose}
              className="w-10 h-10 rounded-lg hover:bg-surface-secondary transition-colors flex items-center justify-center"
            >
              <Icon name="X" size={20} className="text-text-secondary" />
            </button>
          </div>
          
          {/* Progress indicator */}
          <div className="flex items-center space-x-2 mt-4">
            <div className={`w-8 h-8 rounded-full flex items-center justify-center text-sm font-medium ${
              step >= 1 ? 'bg-primary text-white' : 'bg-surface-secondary text-text-secondary'
            }`}>
              1
            </div>
            <div className={`flex-1 h-1 rounded ${
              step >= 2 ? 'bg-primary' : 'bg-surface-secondary'
            }`} />
            <div className={`w-8 h-8 rounded-full flex items-center justify-center text-sm font-medium ${
              step >= 2 ? 'bg-primary text-white' : 'bg-surface-secondary text-text-secondary'
            }`}>
              2
            </div>
          </div>
        </div>

        {/* Content */}
        <div className="p-6">
          {step === 1 && (
            <div className="space-y-6">
              <div>
                <h3 className="text-lg font-semibold text-text-primary mb-2">
                  Select Override Reason
                </h3>
                <p className="text-text-secondary text-sm">
                  Please specify why manual override is required for this check-in.
                </p>
              </div>

              <div className="space-y-3">
                {reasons.map((reasonOption) => (
                  <button
                    key={reasonOption.id}
                    onClick={() => handleReasonSelect(reasonOption.id)}
                    className="w-full text-left p-4 border border-border rounded-lg hover:bg-surface-secondary hover:border-primary transition-all"
                  >
                    <div className="flex items-start space-x-3">
                      <div className="w-5 h-5 border-2 border-border rounded-full mt-0.5" />
                      <div>
                        <p className="font-medium text-text-primary">
                          {reasonOption.label}
                        </p>
                        <p className="text-sm text-text-secondary mt-1">
                          {reasonOption.description}
                        </p>
                      </div>
                    </div>
                  </button>
                ))}
              </div>
            </div>
          )}

          {step === 2 && (
            <div className="space-y-6">
              <div>
                <h3 className="text-lg font-semibold text-text-primary mb-2">
                  Verification Required
                </h3>
                <p className="text-text-secondary text-sm">
                  Complete the following verification steps to proceed with manual check-in.
                </p>
              </div>

              {/* Station Name Verification */}
              <div className="space-y-2">
                <label className="block text-sm font-medium text-text-primary">
                  Confirm Station Name *
                </label>
                <input
                  type="text"
                  value={verification.stationName}
                  onChange={(e) => handleVerificationChange('stationName', e.target.value)}
                  placeholder={`Type "${station?.name}" to confirm`}
                  className="w-full px-3 py-2 border border-border rounded-lg focus:ring-2 focus:ring-primary focus:border-primary"
                />
                <p className="text-xs text-text-secondary">
                  Expected: {station?.name}
                </p>
              </div>

              {/* Observer Confirmation */}
              <div className="space-y-2">
                <label className="flex items-start space-x-3">
                  <input
                    type="checkbox"
                    checked={verification.observerConfirmation}
                    onChange={(e) => handleVerificationChange('observerConfirmation', e.target.checked)}
                    className="mt-1 w-4 h-4 text-primary border-border rounded focus:ring-primary"
                  />
                  <div>
                    <span className="text-sm font-medium text-text-primary">
                      Observer Confirmation *
                    </span>
                    <p className="text-xs text-text-secondary mt-1">
                      I confirm that I am physically present at the assigned polling station and have verified the location despite GPS issues.
                    </p>
                  </div>
                </label>
              </div>

              {/* Supervisor Contact */}
              <div className="space-y-2">
                <label className="block text-sm font-medium text-text-primary">
                  Supervisor Contact/Reference *
                </label>
                <input
                  type="text"
                  value={verification.supervisorContact}
                  onChange={(e) => handleVerificationChange('supervisorContact', e.target.value)}
                  placeholder="Enter supervisor name, phone, or reference number"
                  className="w-full px-3 py-2 border border-border rounded-lg focus:ring-2 focus:ring-primary focus:border-primary"
                />
                <p className="text-xs text-text-secondary">
                  Provide contact information or reference for verification purposes.
                </p>
              </div>

              {/* Additional Notes */}
              <div className="space-y-2">
                <label className="block text-sm font-medium text-text-primary">
                  Additional Notes
                </label>
                <textarea
                  value={verification.additionalNotes}
                  onChange={(e) => handleVerificationChange('additionalNotes', e.target.value)}
                  placeholder="Any additional information about the manual override..."
                  rows={3}
                  className="w-full px-3 py-2 border border-border rounded-lg focus:ring-2 focus:ring-primary focus:border-primary"
                />
              </div>

              {/* Warning Notice */}
              <div className="bg-warning-50 border border-warning-200 rounded-lg p-4">
                <div className="flex items-start space-x-3">
                  <Icon name="AlertTriangle" size={20} className="text-warning mt-0.5" />
                  <div>
                    <p className="font-medium text-warning-700">
                      Manual Override Notice
                    </p>
                    <p className="text-sm text-warning-600 mt-1">
                      This manual check-in will be flagged for supervisor review. Ensure all information is accurate and you are physically present at the correct location.
                    </p>
                  </div>
                </div>
              </div>
            </div>
          )}
        </div>

        {/* Footer */}
        <div className="p-6 border-t border-border bg-surface-secondary">
          <div className="flex justify-between">
            <Button
              variant="outline"
              onClick={step === 1 ? onClose : () => setStep(1)}
              disabled={isSubmitting}
            >
              {step === 1 ? 'Cancel' : 'Back'}
            </Button>
            
            {step === 2 && (
              <Button
                variant="warning"
                onClick={handleSubmit}
                disabled={!isStep2Valid() || isSubmitting}
                loading={isSubmitting}
                iconName="AlertTriangle"
              >
                {isSubmitting ? 'Processing...' : 'Confirm Manual Check-in'}
              </Button>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};

export default ManualOverride;