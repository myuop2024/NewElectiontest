// src/pages/polling-station-check-in/components/SuccessConfirmation.jsx
import React, { useState } from 'react';
import Button from 'components/ui/Button';
import Icon from 'components/AppIcon';

const SuccessConfirmation = ({ checkInData, onClose }) => {
  const [showDetails, setShowDetails] = useState(false);
  const [copySuccess, setCopySuccess] = useState(false);

  const formatTimestamp = (timestamp) => {
    return new Date(timestamp).toLocaleString('en-US', {
      weekday: 'long',
      year: 'numeric',
      month: 'long',
      day: 'numeric',
      hour: '2-digit',
      minute: '2-digit',
      second: '2-digit'
    });
  };

  const formatCoordinates = (location) => {
    if (!location) return 'Not available';
    return `${location.latitude?.toFixed(6)}, ${location.longitude?.toFixed(6)}`;
  };

  const copyToClipboard = async (text) => {
    try {
      await navigator.clipboard.writeText(text);
      setCopySuccess(true);
      setTimeout(() => setCopySuccess(false), 2000);
    } catch (error) {
      console.error('Failed to copy:', error);
    }
  };

  const generateQRCode = () => {
    // Mock QR code generation - in real implementation, this would generate actual QR code
    const qrData = {
      confirmationCode: checkInData.confirmationCode,
      timestamp: checkInData.timestamp,
      stationId: checkInData.stationId,
      observerId: checkInData.observerId
    };
    
    // This would be replaced with actual QR code library
    return `data:image/svg+xml;base64,${btoa(`
      <svg width="120" height="120" xmlns="http://www.w3.org/2000/svg">
        <rect width="120" height="120" fill="white"/>
        <g fill="black">
          ${Array.from({length: 10}, (_, i) => 
            Array.from({length: 10}, (_, j) => 
              Math.random() > 0.5 ? `<rect x="${j*12}" y="${i*12}" width="12" height="12"/>` : '' ).join('')
          ).join('')}
        </g>
        <text x="60" y="135" text-anchor="middle" font-size="8" fill="black">
          Check-in Verification
        </text>
      </svg>
    `)}`;
  };

  return (
    <div className="fixed inset-0 z-500 bg-black bg-opacity-50 flex items-center justify-center p-4">
      <div className="bg-surface rounded-lg shadow-elevation-4 w-full max-w-lg max-h-full overflow-y-auto">
        {/* Header */}
        <div className="p-6 text-center border-b border-border">
          <div className="w-16 h-16 bg-success rounded-full flex items-center justify-center mx-auto mb-4">
            <Icon name="CheckCircle" size={32} className="text-white" />
          </div>
          <h2 className="text-2xl font-bold text-text-primary mb-2">
            Check-in Successful!
          </h2>
          <p className="text-text-secondary">
            You have been successfully checked in to your assigned polling station.
          </p>
        </div>

        {/* Main Content */}
        <div className="p-6 space-y-6">
          {/* Confirmation Details */}
          <div className="bg-success-50 border border-success-200 rounded-lg p-4">
            <div className="text-center">
              <h3 className="font-semibold text-success-700 mb-3">
                Confirmation Code
              </h3>
              <div className="bg-white border border-success-300 rounded-lg p-3 mb-3">
                <code className="text-lg font-mono font-bold text-text-primary">
                  {checkInData.confirmationCode}
                </code>
              </div>
              <button
                onClick={() => copyToClipboard(checkInData.confirmationCode)}
                className="flex items-center space-x-2 mx-auto text-success-600 hover:text-success-700 transition-colors"
              >
                <Icon name={copySuccess ? "Check" : "Copy"} size={16} />
                <span className="text-sm font-medium">
                  {copySuccess ? 'Copied!' : 'Copy Code'}
                </span>
              </button>
            </div>
          </div>

          {/* QR Code */}
          <div className="text-center">
            <h3 className="font-semibold text-text-primary mb-3">
              Verification QR Code
            </h3>
            <div className="bg-white border border-border rounded-lg p-4 inline-block">
              <img
                src={generateQRCode()}
                alt="Check-in verification QR code"
                className="w-32 h-32 mx-auto"
              />
            </div>
            <p className="text-xs text-text-secondary mt-2">
              Show this QR code for End-of-Journey verification
            </p>
          </div>

          {/* Summary Information */}
          <div className="space-y-3">
            <div className="flex items-center justify-between py-2 border-b border-border">
              <span className="text-sm text-text-secondary">Check-in Time</span>
              <span className="text-sm font-medium text-text-primary">
                {formatTimestamp(checkInData.timestamp)}
              </span>
            </div>
            
            <div className="flex items-center justify-between py-2 border-b border-border">
              <span className="text-sm text-text-secondary">Station ID</span>
              <span className="text-sm font-medium text-text-primary">
                {checkInData.stationId}
              </span>
            </div>
            
            <div className="flex items-center justify-between py-2 border-b border-border">
              <span className="text-sm text-text-secondary">Observer ID</span>
              <span className="text-sm font-medium text-text-primary">
                {checkInData.observerId}
              </span>
            </div>
            
            <div className="flex items-center justify-between py-2 border-b border-border">
              <span className="text-sm text-text-secondary">Method</span>
              <span className={`text-sm font-medium ${
                checkInData.method === 'automatic' ? 'text-success' : 'text-warning'
              }`}>
                {checkInData.method === 'automatic' ? 'Automatic (GPS)' : 'Manual Override'}
              </span>
            </div>
            
            <div className="flex items-center justify-between py-2">
              <span className="text-sm text-text-secondary">Connection Status</span>
              <span className={`text-sm font-medium ${
                checkInData.connectionStatus === 'online' ? 'text-success' : 'text-warning'
              }`}>
                {checkInData.connectionStatus === 'online' ? 'Online' : 'Offline (SMS Sent)'}
              </span>
            </div>
          </div>

          {/* Detailed Information Toggle */}
          <button
            onClick={() => setShowDetails(!showDetails)}
            className="w-full flex items-center justify-between p-3 border border-border rounded-lg hover:bg-surface-secondary transition-colors"
          >
            <span className="text-sm font-medium text-text-primary">
              {showDetails ? 'Hide' : 'Show'} Detailed Information
            </span>
            <Icon 
              name={showDetails ? "ChevronUp" : "ChevronDown"} 
              size={16} 
              className="text-text-secondary" 
            />
          </button>

          {/* Detailed Information */}
          {showDetails && (
            <div className="bg-surface-secondary rounded-lg p-4 space-y-3">
              <div className="flex items-center justify-between py-1">
                <span className="text-xs text-text-secondary">GPS Coordinates</span>
                <span className="text-xs font-mono text-text-primary">
                  {formatCoordinates(checkInData.location)}
                </span>
              </div>
              
              {checkInData.accuracy && (
                <div className="flex items-center justify-between py-1">
                  <span className="text-xs text-text-secondary">GPS Accuracy</span>
                  <span className="text-xs text-text-primary">
                    ±{Math.round(checkInData.accuracy)}m
                  </span>
                </div>
              )}
              
              {checkInData.distance && (
                <div className="flex items-center justify-between py-1">
                  <span className="text-xs text-text-secondary">Distance to Station</span>
                  <span className="text-xs text-text-primary">
                    {Math.round(checkInData.distance)}m
                  </span>
                </div>
              )}
              
              <div className="flex items-center justify-between py-1">
                <span className="text-xs text-text-secondary">Photos Captured</span>
                <span className="text-xs text-text-primary">
                  {checkInData.photos?.length || 0} photos
                </span>
              </div>
              
              {checkInData.status === 'pending_sync' && (
                <div className="mt-3 p-2 bg-warning-50 border border-warning-200 rounded">
                  <p className="text-xs text-warning-700">
                    <Icon name="Info" size={12} className="inline mr-1" />
                    Data will sync automatically when connection is restored.
                  </p>
                </div>
              )}
            </div>
          )}

          {/* Next Steps */}
          <div className="bg-primary-50 border border-primary-200 rounded-lg p-4">
            <h4 className="font-medium text-primary-700 mb-2">
              Next Steps
            </h4>
            <ul className="text-sm text-primary-600 space-y-1">
              <li>• Save your confirmation code for records</li>
              <li>• Begin your observation duties</li>
              <li>• Use the dashboard to report incidents or upload documents</li>
              <li>• Keep the QR code accessible for end-of-day verification</li>
            </ul>
          </div>
        </div>

        {/* Footer */}
        <div className="p-6 border-t border-border">
          <div className="flex space-x-3">
            <Button
              variant="outline"
              onClick={() => copyToClipboard(`Check-in Confirmation: ${checkInData.confirmationCode}\nTime: ${formatTimestamp(checkInData.timestamp)}\nStation: ${checkInData.stationId}`)}
              iconName="Share"
              className="flex-1"
            >
              Share Details
            </Button>
            
            <Button
              variant="primary"
              onClick={onClose}
              iconName="ArrowRight"
              className="flex-1"
            >
              Go to Dashboard
            </Button>
          </div>
        </div>
      </div>
    </div>
  );
};

export default SuccessConfirmation;