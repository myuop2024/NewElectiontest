// src/pages/polling-station-check-in/components/MapView.jsx
import React, { useEffect, useRef, useState } from 'react';
import Icon from 'components/AppIcon';

const MapView = ({ 
  currentLocation, 
  assignedStation, 
  accuracy, 
  gpsStatus, 
  distanceToStation 
}) => {
  const mapRef = useRef(null);
  const [mapError, setMapError] = React.useState(false);
  const [isLoading, setIsLoading] = React.useState(true);

  useEffect(() => {
    // Simulate map loading
    const timer = setTimeout(() => {
      setIsLoading(false);
    }, 1500);

    return () => clearTimeout(timer);
  }, []);

  const getStatusColor = () => {
    switch (gpsStatus) {
      case 'accurate': return 'text-success';
      case 'approximate': return 'text-warning';
      case 'poor': return 'text-error';
      case 'denied': return 'text-error';
      default: return 'text-text-secondary';
    }
  };

  const getStatusText = () => {
    switch (gpsStatus) {
      case 'searching': return 'Searching for GPS signal...';
      case 'accurate': return 'GPS signal is accurate';
      case 'approximate': return 'GPS signal is approximate';
      case 'poor': return 'GPS signal is poor';
      case 'denied': return 'GPS access denied';
      default: return 'GPS status unknown';
    }
  };

  if (isLoading) {
    return (
      <div className="h-96 bg-surface-secondary rounded-lg flex items-center justify-center">
        <div className="text-center">
          <div className="animate-spin w-8 h-8 border-2 border-primary border-t-transparent rounded-full mx-auto mb-4"></div>
          <p className="text-text-secondary">Loading map...</p>
        </div>
      </div>
    );
  }

  if (mapError || gpsStatus === 'denied') {
    return (
      <div className="h-96 bg-surface-secondary rounded-lg flex items-center justify-center p-6">
        <div className="text-center max-w-md">
          <Icon name="MapPin" size={48} className="text-text-tertiary mx-auto mb-4" />
          <h3 className="text-lg font-semibold text-text-primary mb-2">
            {gpsStatus === 'denied' ? 'Location Access Denied' : 'Map Unavailable'}
          </h3>
          <p className="text-text-secondary mb-4">
            {gpsStatus === 'denied' ?'Please enable location services to view the map and check in.' :'Unable to load map view. You can still proceed with manual check-in.'}
          </p>
          <button 
            onClick={() => window.location.reload()}
            className="text-primary hover:text-primary-700 font-medium"
          >
            Try Again
          </button>
        </div>
      </div>
    );
  }

  return (
    <div className="relative">
      {/* Map Header */}
      <div className="p-4 border-b border-border">
        <div className="flex items-center justify-between">
          <h3 className="text-lg font-semibold text-text-primary">Location Map</h3>
          <div className="flex items-center space-x-2">
            <div className={`w-2 h-2 rounded-full ${
              gpsStatus === 'accurate' ? 'bg-success' : 
              gpsStatus === 'approximate' ? 'bg-warning' : 'bg-error'
            }`} />
            <span className={`text-sm ${getStatusColor()}`}>
              {gpsStatus.charAt(0).toUpperCase() + gpsStatus.slice(1)}
            </span>
          </div>
        </div>
        <p className="text-sm text-text-secondary mt-1">
          {getStatusText()}
        </p>
      </div>

      {/* Map Container */}
      <div className="relative h-96 bg-gradient-to-br from-primary-50 to-secondary-50">
        {/* Mock Map Background */}
        <div className="absolute inset-0 opacity-20">
          <svg viewBox="0 0 400 300" className="w-full h-full">
            {/* Grid lines */}
            <defs>
              <pattern id="grid" width="20" height="20" patternUnits="userSpaceOnUse">
                <path d="M 20 0 L 0 0 0 20" fill="none" stroke="currentColor" strokeWidth="0.5" opacity="0.3"/>
              </pattern>
            </defs>
            <rect width="100%" height="100%" fill="url(#grid)" />
            
            {/* Mock roads */}
            <path d="M0,150 Q100,120 200,150 T400,150" stroke="currentColor" strokeWidth="3" fill="none" opacity="0.4" />
            <path d="M200,0 Q180,100 200,200 T200,300" stroke="currentColor" strokeWidth="2" fill="none" opacity="0.3" />
          </svg>
        </div>

        {/* Station Marker */}
        <div className="absolute top-1/2 left-1/2 transform -translate-x-1/2 -translate-y-1/2">
          <div className="relative">
            {/* Station marker */}
            <div className="w-8 h-8 bg-primary rounded-full border-2 border-white shadow-lg flex items-center justify-center">
              <Icon name="Building" size={16} className="text-white" />
            </div>
            {/* Station label */}
            <div className="absolute top-10 left-1/2 transform -translate-x-1/2 bg-white border border-border rounded-lg px-2 py-1 shadow-md whitespace-nowrap">
              <p className="text-xs font-medium text-text-primary">{assignedStation?.name}</p>
              <p className="text-xs text-text-secondary">Target Location</p>
            </div>
          </div>
        </div>

        {/* Current Location Marker */}
        {currentLocation && (
          <div className="absolute" style={{
            top: `${50 + (Math.random() - 0.5) * 20}%`,
            left: `${50 + (Math.random() - 0.5) * 20}%`,
            transform: 'translate(-50%, -50%)'
          }}>
            <div className="relative">
              {/* Accuracy circle */}
              {accuracy && (
                <div 
                  className={`absolute rounded-full border-2 opacity-30 ${
                    gpsStatus === 'accurate' ? 'border-success bg-success' :
                    gpsStatus === 'approximate' ? 'border-warning bg-warning' : 'border-error bg-error'
                  }`}
                  style={{
                    width: `${Math.min(accuracy / 5, 100)}px`,
                    height: `${Math.min(accuracy / 5, 100)}px`,
                    top: '50%',
                    left: '50%',
                    transform: 'translate(-50%, -50%)'
                  }}
                />
              )}
              
              {/* Current location dot */}
              <div className={`w-4 h-4 rounded-full border-2 border-white shadow-lg animate-pulse ${
                gpsStatus === 'accurate' ? 'bg-success' :
                gpsStatus === 'approximate' ? 'bg-warning' : 'bg-error'
              }`} />
              
              {/* Location label */}
              <div className="absolute top-6 left-1/2 transform -translate-x-1/2 bg-white border border-border rounded-lg px-2 py-1 shadow-md whitespace-nowrap">
                <p className="text-xs font-medium text-text-primary">Your Location</p>
                {distanceToStation && (
                  <p className="text-xs text-text-secondary">
                    {Math.round(distanceToStation)}m from station
                  </p>
                )}
              </div>
            </div>
          </div>
        )}

        {/* Map Controls */}
        <div className="absolute top-4 right-4 flex flex-col space-y-2">
          <button className="w-10 h-10 bg-white border border-border rounded-lg shadow-md flex items-center justify-center hover:bg-surface-secondary transition-colors">
            <Icon name="Plus" size={16} className="text-text-primary" />
          </button>
          <button className="w-10 h-10 bg-white border border-border rounded-lg shadow-md flex items-center justify-center hover:bg-surface-secondary transition-colors">
            <Icon name="Minus" size={16} className="text-text-primary" />
          </button>
          <button className="w-10 h-10 bg-white border border-border rounded-lg shadow-md flex items-center justify-center hover:bg-surface-secondary transition-colors">
            <Icon name="Navigation" size={16} className="text-text-primary" />
          </button>
        </div>

        {/* Distance indicator */}
        {distanceToStation && (
          <div className="absolute bottom-4 left-4 bg-white border border-border rounded-lg px-3 py-2 shadow-md">
            <div className="flex items-center space-x-2">
              <Icon name="Navigation" size={14} className={`${
                distanceToStation <= assignedStation?.acceptableRadius ? 'text-success' : 'text-warning'
              }`} />
              <span className="text-sm font-medium text-text-primary">
                {Math.round(distanceToStation)}m
              </span>
              <span className="text-xs text-text-secondary">
                {distanceToStation <= assignedStation?.acceptableRadius ? 'In range' : 'Too far'}
              </span>
            </div>
          </div>
        )}
      </div>

      {/* Map Footer */}
      <div className="p-4 border-t border-border bg-surface-secondary">
        <div className="flex items-center justify-between text-sm">
          <div className="flex items-center space-x-4">
            <div className="flex items-center space-x-2">
              <div className="w-3 h-3 bg-primary rounded-full" />
              <span className="text-text-secondary">Assigned Station</span>
            </div>
            <div className="flex items-center space-x-2">
              <div className={`w-3 h-3 rounded-full ${
                gpsStatus === 'accurate' ? 'bg-success' :
                gpsStatus === 'approximate' ? 'bg-warning' : 'bg-error'
              }`} />
              <span className="text-text-secondary">Your Location</span>
            </div>
          </div>
          
          <button className="text-primary hover:text-primary-700 font-medium text-sm">
            View Full Screen
          </button>
        </div>
      </div>
    </div>
  );
};

export default MapView;