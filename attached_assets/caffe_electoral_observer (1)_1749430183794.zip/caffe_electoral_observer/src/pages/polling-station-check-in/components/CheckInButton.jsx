// src/pages/polling-station-check-in/components/CheckInButton.jsx
import React from 'react';
import Button from 'components/ui/Button';
import Icon from 'components/AppIcon';

const CheckInButton = ({ 
  withinRange, 
  gpsStatus, 
  currentLocation, 
  onCheckIn, 
  disabled, 
  loading 
}) => {
  const getButtonState = () => {
    if (disabled) {
      return {
        variant: 'ghost',
        text: 'Already Checked In',
        icon: 'CheckCircle',
        canCheckIn: false,
        message: 'You have successfully checked in to this station.'
      };
    }

    if (loading) {
      return {
        variant: 'primary',
        text: 'Checking In...',
        icon: 'RefreshCw',
        canCheckIn: false,
        message: 'Processing your check-in request...'
      };
    }

    if (!currentLocation) {
      return {
        variant: 'outline',
        text: 'Waiting for Location',
        icon: 'MapPin',
        canCheckIn: false,
        message: 'Waiting for GPS location. Please ensure location services are enabled.'
      };
    }

    if (gpsStatus === 'denied') {
      return {
        variant: 'outline',
        text: 'Location Access Denied',
        icon: 'XCircle',
        canCheckIn: false,
        message: 'Location access is required for check-in. Please enable location services and refresh.'
      };
    }

    if (gpsStatus === 'poor') {
      return {
        variant: 'warning',
        text: 'GPS Signal Poor',
        icon: 'AlertTriangle',
        canCheckIn: false,
        message: 'GPS signal is too weak for accurate check-in. Try moving to an open area or use manual override.'
      };
    }

    if (withinRange && (gpsStatus === 'accurate' || gpsStatus === 'approximate')) {
      return {
        variant: 'success',
        text: 'Check In Now',
        icon: 'CheckCircle',
        canCheckIn: true,
        message: 'You are within range of your assigned polling station. Ready to check in!'
      };
    }

    if (!withinRange) {
      return {
        variant: 'warning',
        text: 'Not in Range',
        icon: 'Navigation',
        canCheckIn: false,
        message: 'You need to be within the acceptable radius of your assigned station to check in.'
      };
    }

    return {
      variant: 'outline',
      text: 'Check Location',
      icon: 'MapPin',
      canCheckIn: false,
      message: 'Verifying your location...'
    };
  };

  const buttonState = getButtonState();

  const handleClick = () => {
    if (buttonState.canCheckIn && onCheckIn) {
      onCheckIn();
    }
  };

  return (
    <div className="space-y-3">
      {/* Main Check-in Button */}
      <Button
        variant={buttonState.variant}
        fullWidth
        size="lg"
        iconName={buttonState.icon}
        onClick={handleClick}
        disabled={!buttonState.canCheckIn || loading}
        loading={loading}
        className={`transition-all duration-200 ${buttonState.canCheckIn ? 'animate-pulse' : ''}`}
      >
        {buttonState.text}
      </Button>

      {/* Status Message */}
      <div className={`p-3 rounded-lg border ${
        buttonState.canCheckIn 
          ? 'bg-success-50 border-success-200 text-success-700'
          : buttonState.variant === 'warning' ?'bg-warning-50 border-warning-200 text-warning-700'
          : buttonState.variant === 'outline'&& gpsStatus === 'denied' ?'bg-error-50 border-error-200 text-error-700' :'bg-surface-secondary border-border text-text-secondary'
      }`}>
        <div className="flex items-start space-x-2">
          <Icon 
            name={buttonState.canCheckIn ? 'Info' : 'AlertTriangle'} 
            size={16} 
            className="mt-0.5 flex-shrink-0" 
          />
          <p className="text-sm">
            {buttonState.message}
          </p>
        </div>
      </div>

      {/* Additional Information */}
      {buttonState.canCheckIn && (
        <div className="bg-primary-50 border border-primary-200 rounded-lg p-3">
          <div className="flex items-start space-x-2">
            <Icon name="Clock" size={16} className="text-primary mt-0.5" />
            <div className="text-sm text-primary-700">
              <p className="font-medium">Ready for Check-in</p>
              <p className="mt-1">
                Your check-in will be timestamped with your current location and submitted automatically.
              </p>
            </div>
          </div>
        </div>
      )}

      {/* Troubleshooting Tips */}
      {!buttonState.canCheckIn && !disabled && (
        <div className="bg-surface-secondary border border-border rounded-lg p-3">
          <div className="flex items-start space-x-2">
            <Icon name="HelpCircle" size={16} className="text-text-secondary mt-0.5" />
            <div className="text-sm text-text-secondary">
              <p className="font-medium mb-2">Need Help?</p>
              <ul className="space-y-1 text-xs">
                {gpsStatus === 'denied' && (
                  <li>• Enable location services in your browser settings</li>
                )}
                {gpsStatus === 'poor' && (
                  <>
                    <li>• Move to an area with better GPS reception</li>
                    <li>• Ensure you're outdoors or near a window</li>
                  </>
                )}
                {!withinRange && currentLocation && (
                  <>
                    <li>• Move closer to your assigned polling station</li>
                    <li>• Verify you're at the correct location</li>
                  </>
                )}
                <li>• Use Manual Override if location issues persist</li>
                <li>• Contact your supervisor for assistance</li>
              </ul>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default CheckInButton;