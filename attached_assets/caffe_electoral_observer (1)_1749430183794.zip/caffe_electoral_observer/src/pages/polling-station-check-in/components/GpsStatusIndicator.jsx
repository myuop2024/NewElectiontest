// src/pages/polling-station-check-in/components/GpsStatusIndicator.jsx
import React from 'react';
import Icon from 'components/AppIcon';

const GpsStatusIndicator = ({ status, accuracy, compact = false }) => {
  const getStatusConfig = () => {
    switch (status) {
      case 'searching':
        return {
          icon: 'Search',
          color: 'text-text-secondary',
          bgColor: 'bg-surface-secondary',
          text: 'Searching',
          description: 'Looking for GPS signal...'
        };
      case 'accurate':
        return {
          icon: 'MapPin',
          color: 'text-success',
          bgColor: 'bg-success-50',
          text: 'Accurate',
          description: 'GPS signal is strong and accurate'
        };
      case 'approximate':
        return {
          icon: 'MapPin',
          color: 'text-warning',
          bgColor: 'bg-warning-50',
          text: 'Approximate',
          description: 'GPS signal is acceptable but not precise'
        };
      case 'poor':
        return {
          icon: 'MapPin',
          color: 'text-error',
          bgColor: 'bg-error-50',
          text: 'Poor Signal',
          description: 'GPS signal is weak or unreliable'
        };
      case 'denied':
        return {
          icon: 'XCircle',
          color: 'text-error',
          bgColor: 'bg-error-50',
          text: 'Denied',
          description: 'Location access has been denied'
        };
      default:
        return {
          icon: 'MapPin',
          color: 'text-text-secondary',
          bgColor: 'bg-surface-secondary',
          text: 'Unknown',
          description: 'GPS status is unknown'
        };
    }
  };

  const config = getStatusConfig();

  if (compact) {
    return (
      <div className="flex items-center space-x-2">
        <div className={`w-2 h-2 rounded-full ${
          config.color.replace('text-', 'bg-')
        } ${status === 'searching' ? 'animate-pulse' : ''}`} />
        <span className={`text-sm font-medium ${config.color}`}>
          {config.text}
        </span>
        {accuracy && accuracy <= 50 && (
          <span className="text-xs text-text-secondary">
            (±{Math.round(accuracy)}m)
          </span>
        )}
      </div>
    );
  }

  return (
    <div className={`flex items-center space-x-3 px-3 py-2 rounded-lg ${config.bgColor}`}>
      <div className="flex items-center space-x-2">
        <Icon 
          name={config.icon} 
          size={16} 
          className={`${config.color} ${
            status === 'searching' ? 'animate-pulse' : ''
          }`} 
        />
        <div>
          <span className={`text-sm font-medium ${config.color}`}>
            {config.text}
          </span>
          {accuracy && (
            <span className="text-xs text-text-secondary ml-2">
              ±{Math.round(accuracy)}m
            </span>
          )}
        </div>
      </div>
      
      {!compact && (
        <div className="hidden md:block">
          <p className="text-xs text-text-secondary">
            {config.description}
          </p>
        </div>
      )}
    </div>
  );
};

export default GpsStatusIndicator;