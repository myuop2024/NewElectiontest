import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import Header from 'components/ui/Header';
import Sidebar from 'components/ui/Sidebar';
import QuickActionPanel from 'components/ui/QuickActionPanel';
import StatusIndicator from 'components/ui/StatusIndicator';
import Icon from 'components/AppIcon';

import StatusCard from './components/StatusCard';
import QuickActionTile from './components/QuickActionTile';
import NewsCard from './components/NewsCard';
import NotificationCenter from './components/NotificationCenter';
import TeamOverview from './components/TeamOverview';
import RecentActivity from './components/RecentActivity';

const ObserverDashboard = () => {
  const navigate = useNavigate();
  const [observerRole, setObserverRole] = useState('indoor-agent'); // indoor-agent, roving-observer, parish-coordinator
  const [isOnline, setIsOnline] = useState(true);
  const [lastSyncTime, setLastSyncTime] = useState(new Date());

  // Mock observer data
  const observerData = {
    id: 'OBS-2024-001',
    name: 'Michael Rodriguez',
    role: observerRole,
    station: observerRole === 'indoor-agent' ? 'PS-001-A' : null,
    parish: 'Kingston',
    checkInStatus: 'checked-in',
    avatar: 'https://randomuser.me/api/portraits/men/32.jpg'
  };

  // Mock dashboard data based on role
  const getDashboardData = () => {
    const baseData = {
      quickActions: [
        {
          id: 'check-in',
          title: 'Station Check-in',
          description: 'Verify location and check-in',
          icon: 'MapPin',
          route: '/polling-station-check-in',
          color: 'bg-primary',
          urgent: observerData.checkInStatus !== 'checked-in'
        },
        {
          id: 'document-upload',
          title: 'Document Upload',
          description: 'Capture and process documents',
          icon: 'Upload',
          route: '/document-upload-ocr-processing',
          color: 'bg-secondary'
        },
        {
          id: 'communication',
          title: 'Live Chat',
          description: 'Connect with team members',
          icon: 'MessageSquare',
          route: '/live-communication-hub',
          color: 'bg-accent',
          badge: 3
        },
        {
          id: 'training',
          title: 'Training Portal',
          description: 'Access learning modules',
          icon: 'GraduationCap',
          route: '/training-certification-portal',
          color: 'bg-warning'
        }
      ],
      statusCards: [],
      notifications: [
        {
          id: 1,
          type: 'alert',
          title: 'System Update',
          message: 'New features available in the communication hub',
          timestamp: new Date(Date.now() - 300000),
          read: false
        },
        {
          id: 2,
          type: 'message',
          title: 'Team Message',
          message: 'Parish Coordinator has shared new guidelines',
          timestamp: new Date(Date.now() - 600000),
          read: false
        },
        {
          id: 3,
          type: 'reminder',
          title: 'Training Reminder',
          message: 'Complete your monthly certification by Friday',
          timestamp: new Date(Date.now() - 900000),
          read: true
        }
      ],
      newsItems: [
        {
          id: 1,
          title: 'CAFFE Announces Enhanced Digital Observer Training Program',
          summary: 'New comprehensive training modules now available for all observer categories with interactive assessments and digital certification.',
          image: 'https://images.unsplash.com/photo-1560472354-b33ff0c44a43?w=400&h=200&fit=crop',
          timestamp: new Date(Date.now() - 3600000),
          category: 'Training'
        },
        {
          id: 2,
          title: 'Election Observation Guidelines Updated for 2024',
          summary: 'Latest protocols and procedures for electoral observation have been updated to reflect current best practices and legal requirements.',
          image: 'https://images.pexels.com/photos/6077326/pexels-photo-6077326.jpeg?w=400&h=200&fit=crop',
          timestamp: new Date(Date.now() - 7200000),
          category: 'Guidelines'
        },
        {
          id: 3,
          title: 'Technology Integration Success Stories from Recent Elections',
          summary: 'Digital observation tools have significantly improved data accuracy and real-time reporting capabilities across multiple constituencies.',
          image: 'https://images.pixabay.com/photo/2018/05/08/08/44/artificial-intelligence-3382507_1280.jpg?w=400&h=200&fit=crop',
          timestamp: new Date(Date.now() - 10800000),
          category: 'Technology'
        }
      ]
    };

    // Role-specific customizations
    switch (observerRole) {
      case 'indoor-agent':
        baseData.statusCards = [
          {
            title: 'Station Assignment',
            value: 'PS-001-A',
            subtitle: 'Half Way Tree Primary',
            icon: 'MapPin',
            status: 'active',
            action: () => navigate('/polling-station-check-in')
          },
          {
            title: 'Check-in Status',
            value: observerData.checkInStatus === 'checked-in' ? 'Checked In' : 'Pending',
            subtitle: `Last: ${new Date().toLocaleTimeString()}`,
            icon: 'CheckCircle',
            status: observerData.checkInStatus === 'checked-in' ? 'success' : 'warning'
          },
          {
            title: 'Documents Uploaded',
            value: '12',
            subtitle: 'Today',
            icon: 'FileText',
            status: 'info'
          },
          {
            title: 'Incidents Reported',
            value: '0',
            subtitle: 'No issues today',
            icon: 'AlertTriangle',
            status: 'success'
          }
        ];
        break;

      case 'roving-observer':
        baseData.statusCards = [
          {
            title: 'Assigned Stations',
            value: '8',
            subtitle: '3 visited today',
            icon: 'Route',
            status: 'active',
            action: () => navigate('/roving-observer-route-management')
          },
          {
            title: 'Current Route',
            value: 'Route A-1',
            subtitle: 'Kingston Central',
            icon: 'Navigation',
            status: 'info'
          },
          {
            title: 'Distance Traveled',
            value: '45.2 km',
            subtitle: 'Today',
            icon: 'MapPin',
            status: 'info'
          },
          {
            title: 'Next Station',
            value: 'PS-003-B',
            subtitle: 'ETA: 15 mins',
            icon: 'Clock',
            status: 'warning'
          }
        ];
        baseData.quickActions.unshift({
          id: 'route-management',
          title: 'Route Management',
          description: 'Plan and navigate routes',
          icon: 'Route',
          route: '/roving-observer-route-management',
          color: 'bg-purple-600'
        });
        break;

      case 'parish-coordinator':
        baseData.statusCards = [
          {
            title: 'Active Observers',
            value: '24',
            subtitle: '22 checked in',
            icon: 'Users',
            status: 'success',
            action: () => navigate('/admin-control-center')
          },
          {
            title: 'Stations Covered',
            value: '18/20',
            subtitle: '90% coverage',
            icon: 'MapPin',
            status: 'success'
          },
          {
            title: 'Reports Pending',
            value: '3',
            subtitle: 'Require review',
            icon: 'FileText',
            status: 'warning'
          },
          {
            title: 'System Health',
            value: '98%',
            subtitle: 'All systems operational',
            icon: 'Activity',
            status: 'success'
          }
        ];
        baseData.quickActions.unshift({
          id: 'admin-center',
          title: 'Admin Center',
          description: 'Manage team and analytics',
          icon: 'Settings',
          route: '/admin-control-center',
          color: 'bg-purple-600'
        });
        break;
    }

    return baseData;
  };

  const dashboardData = getDashboardData();

  const handleQuickAction = (route) => {
    navigate(route);
  };

  const handleRoleChange = (newRole) => {
    setObserverRole(newRole);
  };

  useEffect(() => {
    // Simulate periodic sync updates
    const syncInterval = setInterval(() => {
      setLastSyncTime(new Date());
    }, 30000);

    return () => clearInterval(syncInterval);
  }, []);

  return (
    <div className="min-h-screen bg-background">
      <Header />
      <Sidebar />
      <QuickActionPanel />
      <StatusIndicator />

      {/* Main Content */}
      <main className="lg:ml-64 pt-16 pb-20 lg:pb-6">
        <div className="p-4 lg:p-6 max-w-7xl mx-auto">
          {/* Dashboard Header */}
          <div className="mb-6">
            <div className="flex flex-col lg:flex-row lg:items-center lg:justify-between mb-4">
              <div>
                <h1 className="text-2xl lg:text-3xl font-bold text-text-primary mb-2">
                  Welcome back, {observerData.name}
                </h1>
                <div className="flex items-center space-x-4 text-text-secondary">
                  <span className="flex items-center space-x-1">
                    <Icon name="User" size={16} />
                    <span className="text-sm font-medium capitalize">
                      {observerRole.replace('-', ' ')}
                    </span>
                  </span>
                  <span className="flex items-center space-x-1">
                    <Icon name="MapPin" size={16} />
                    <span className="text-sm">{observerData.parish} Parish</span>
                  </span>
                  <span className="flex items-center space-x-1">
                    <Icon name="Clock" size={16} />
                    <span className="text-sm">{new Date().toLocaleDateString()}</span>
                  </span>
                </div>
              </div>

              {/* Role Switcher (for demo purposes) */}
              <div className="mt-4 lg:mt-0">
                <div className="flex items-center space-x-2 p-1 bg-surface border border-border rounded-lg">
                  {['indoor-agent', 'roving-observer', 'parish-coordinator'].map((role) => (
                    <button
                      key={role}
                      onClick={() => handleRoleChange(role)}
                      className={`px-3 py-2 text-xs font-medium rounded-md transition-colors duration-150 ease-out ${
                        observerRole === role
                          ? 'bg-primary text-white' :'text-text-secondary hover:text-text-primary hover:bg-surface-secondary'
                      }`}
                    >
                      {role.replace('-', ' ').replace(/\b\w/g, l => l.toUpperCase())}
                    </button>
                  ))}
                </div>
              </div>
            </div>

            {/* Connection Status Bar */}
            <div className="flex items-center justify-between p-3 bg-surface border border-border rounded-lg">
              <div className="flex items-center space-x-4">
                <div className="flex items-center space-x-2">
                  <div className={`w-2 h-2 rounded-full ${isOnline ? 'bg-success animate-pulse' : 'bg-error'}`} />
                  <span className="text-sm font-medium text-text-primary">
                    {isOnline ? 'Online' : 'Offline Mode'}
                  </span>
                </div>
                <div className="flex items-center space-x-2 text-text-secondary">
                  <Icon name="RefreshCw" size={14} />
                  <span className="text-xs">
                    Last sync: {lastSyncTime.toLocaleTimeString()}
                  </span>
                </div>
              </div>
              <div className="flex items-center space-x-2">
                <Icon name="Shield" size={14} className="text-success" />
                <span className="text-xs text-success font-medium">Secure Connection</span>
              </div>
            </div>
          </div>

          {/* Dashboard Grid */}
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
            {/* Left Column - Status Cards & Quick Actions */}
            <div className="lg:col-span-8 space-y-6">
              {/* Status Cards */}
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
                {dashboardData.statusCards.map((card, index) => (
                  <StatusCard key={index} {...card} />
                ))}
              </div>

              {/* Quick Actions */}
              <div className="card p-6">
                <h2 className="text-lg font-semibold text-text-primary mb-4">Quick Actions</h2>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  {dashboardData.quickActions.map((action) => (
                    <QuickActionTile
                      key={action.id}
                      {...action}
                      onClick={() => handleQuickAction(action.route)}
                    />
                  ))}
                </div>
              </div>

              {/* Team Overview (Parish Coordinator only) */}
              {observerRole === 'parish-coordinator' && (
                <TeamOverview />
              )}

              {/* Recent Activity */}
              <RecentActivity observerRole={observerRole} />

              {/* News Feed */}
              <div className="card p-6">
                <div className="flex items-center justify-between mb-4">
                  <h2 className="text-lg font-semibold text-text-primary">Latest News & Updates</h2>
                  <button className="text-sm text-primary hover:text-primary-700 transition-colors duration-150 ease-out">
                    View All
                  </button>
                </div>
                <div className="space-y-4">
                  {dashboardData.newsItems.map((news) => (
                    <NewsCard key={news.id} {...news} />
                  ))}
                </div>
              </div>
            </div>

            {/* Right Column - Notifications & Chat */}
            <div className="lg:col-span-4 space-y-6">
              {/* Notification Center */}
              <NotificationCenter notifications={dashboardData.notifications} />

              {/* Emergency Contacts */}
              <div className="card p-6">
                <h3 className="text-lg font-semibold text-text-primary mb-4">Emergency Contacts</h3>
                <div className="space-y-3">
                  <div className="flex items-center justify-between p-3 bg-error-50 border border-error-200 rounded-lg">
                    <div className="flex items-center space-x-3">
                      <div className="w-8 h-8 bg-error text-white rounded-full flex items-center justify-center">
                        <Icon name="Phone" size={16} />
                      </div>
                      <div>
                        <p className="text-sm font-medium text-text-primary">Emergency Hotline</p>
                        <p className="text-xs text-text-secondary">24/7 Support</p>
                      </div>
                    </div>
                    <button className="text-error hover:text-error-700 transition-colors duration-150 ease-out">
                      <Icon name="Phone" size={16} />
                    </button>
                  </div>

                  <div className="flex items-center justify-between p-3 bg-warning-50 border border-warning-200 rounded-lg">
                    <div className="flex items-center space-x-3">
                      <div className="w-8 h-8 bg-warning text-white rounded-full flex items-center justify-center">
                        <Icon name="MessageSquare" size={16} />
                      </div>
                      <div>
                        <p className="text-sm font-medium text-text-primary">Parish Coordinator</p>
                        <p className="text-xs text-text-secondary">Sarah Johnson</p>
                      </div>
                    </div>
                    <button className="text-warning hover:text-warning-700 transition-colors duration-150 ease-out">
                      <Icon name="MessageSquare" size={16} />
                    </button>
                  </div>

                  <div className="flex items-center justify-between p-3 bg-primary-50 border border-primary-200 rounded-lg">
                    <div className="flex items-center space-x-3">
                      <div className="w-8 h-8 bg-primary text-white rounded-full flex items-center justify-center">
                        <Icon name="HelpCircle" size={16} />
                      </div>
                      <div>
                        <p className="text-sm font-medium text-text-primary">Technical Support</p>
                        <p className="text-xs text-text-secondary">IT Helpdesk</p>
                      </div>
                    </div>
                    <button className="text-primary hover:text-primary-700 transition-colors duration-150 ease-out">
                      <Icon name="ExternalLink" size={16} />
                    </button>
                  </div>
                </div>
              </div>

              {/* System Status */}
              <div className="card p-6">
                <h3 className="text-lg font-semibold text-text-primary mb-4">System Status</h3>
                <div className="space-y-3">
                  <div className="flex items-center justify-between">
                    <span className="text-sm text-text-primary">Data Sync</span>
                    <div className="flex items-center space-x-2">
                      <div className="w-2 h-2 bg-success rounded-full" />
                      <span className="text-xs text-success font-medium">Active</span>
                    </div>
                  </div>
                  <div className="flex items-center justify-between">
                    <span className="text-sm text-text-primary">GPS Location</span>
                    <div className="flex items-center space-x-2">
                      <div className="w-2 h-2 bg-success rounded-full" />
                      <span className="text-xs text-success font-medium">Enabled</span>
                    </div>
                  </div>
                  <div className="flex items-center justify-between">
                    <span className="text-sm text-text-primary">Camera Access</span>
                    <div className="flex items-center space-x-2">
                      <div className="w-2 h-2 bg-success rounded-full" />
                      <span className="text-xs text-success font-medium">Ready</span>
                    </div>
                  </div>
                  <div className="flex items-center justify-between">
                    <span className="text-sm text-text-primary">Backup SMS</span>
                    <div className="flex items-center space-x-2">
                      <div className="w-2 h-2 bg-warning rounded-full" />
                      <span className="text-xs text-warning font-medium">Standby</span>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </main>
    </div>
  );
};

export default ObserverDashboard;