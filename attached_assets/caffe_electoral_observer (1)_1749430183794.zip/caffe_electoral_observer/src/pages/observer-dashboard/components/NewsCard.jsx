import React, { useState } from 'react';
import Icon from 'components/AppIcon';
import Image from 'components/AppImage';

const NewsCard = ({ title, summary, image, timestamp, category }) => {
  const [isExpanded, setIsExpanded] = useState(false);

  const formatTimestamp = (date) => {
    const now = new Date();
    const diffMs = now - date;
    const diffHours = Math.floor(diffMs / (1000 * 60 * 60));
    
    if (diffHours < 1) return 'Just now';
    if (diffHours < 24) return `${diffHours}h ago`;
    const diffDays = Math.floor(diffHours / 24);
    return `${diffDays}d ago`;
  };

  const getCategoryColor = () => {
    switch (category.toLowerCase()) {
      case 'training':
        return 'bg-secondary-100 text-secondary-700';
      case 'guidelines':
        return 'bg-primary-100 text-primary-700';
      case 'technology':
        return 'bg-warning-100 text-warning-700';
      default:
        return 'bg-surface-secondary text-text-secondary';
    }
  };

  return (
    <div className="border border-border rounded-lg overflow-hidden hover:shadow-elevation-2 transition-shadow duration-200 ease-in-out">
      <div className="flex">
        <div className="w-24 h-24 flex-shrink-0 overflow-hidden">
          <Image
            src={image}
            alt={title}
            className="w-full h-full object-cover"
          />
        </div>
        
        <div className="flex-1 p-4">
          <div className="flex items-start justify-between mb-2">
            <div className="flex items-center space-x-2">
              <span className={`px-2 py-1 text-xs font-medium rounded-full ${getCategoryColor()}`}>
                {category}
              </span>
              <span className="text-xs text-text-secondary">
                {formatTimestamp(timestamp)}
              </span>
            </div>
            <button
              onClick={() => setIsExpanded(!isExpanded)}
              className="p-1 hover:bg-surface-secondary rounded transition-colors duration-150 ease-out"
            >
              <Icon name={isExpanded ? 'ChevronUp' : 'ChevronDown'} size={16} />
            </button>
          </div>
          
          <h4 className="text-sm font-semibold text-text-primary mb-1 line-clamp-2">
            {title}
          </h4>
          
          <p className={`text-xs text-text-secondary ${isExpanded ? '' : 'line-clamp-2'}`}>
            {summary}
          </p>
          
          {isExpanded && (
            <div className="mt-3 flex items-center space-x-4">
              <button className="flex items-center space-x-1 text-xs text-primary hover:text-primary-700 transition-colors duration-150 ease-out">
                <Icon name="ExternalLink" size={12} />
                <span>Read More</span>
              </button>
              <button className="flex items-center space-x-1 text-xs text-text-secondary hover:text-text-primary transition-colors duration-150 ease-out">
                <Icon name="Share" size={12} />
                <span>Share</span>
              </button>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};

export default NewsCard;