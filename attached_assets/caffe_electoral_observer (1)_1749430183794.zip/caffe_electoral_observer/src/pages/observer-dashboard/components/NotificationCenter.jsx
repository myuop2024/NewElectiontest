import React, { useState } from 'react';
import Icon from 'components/AppIcon';

const NotificationCenter = ({ notifications }) => {
  const [isExpanded, setIsExpanded] = useState(false);
  const [notificationList, setNotificationList] = useState(notifications);

  const unreadCount = notificationList.filter(n => !n.read).length;

  const formatTimestamp = (date) => {
    const now = new Date();
    const diffMs = now - date;
    const diffMins = Math.floor(diffMs / (1000 * 60));
    
    if (diffMins < 1) return 'Just now';
    if (diffMins < 60) return `${diffMins}m ago`;
    const diffHours = Math.floor(diffMins / 60);
    return `${diffHours}h ago`;
  };

  const getNotificationIcon = (type) => {
    switch (type) {
      case 'alert':
        return 'AlertTriangle';
      case 'message':
        return 'MessageSquare';
      case 'reminder':
        return 'Clock';
      default:
        return 'Bell';
    }
  };

  const getNotificationColor = (type) => {
    switch (type) {
      case 'alert':
        return 'text-error';
      case 'message':
        return 'text-primary';
      case 'reminder':
        return 'text-warning';
      default:
        return 'text-text-secondary';
    }
  };

  const markAsRead = (id) => {
    setNotificationList(prev =>
      prev.map(notification =>
        notification.id === id ? { ...notification, read: true } : notification
      )
    );
  };

  const markAllAsRead = () => {
    setNotificationList(prev =>
      prev.map(notification => ({ ...notification, read: true }))
    );
  };

  return (
    <div className="card p-6">
      <div className="flex items-center justify-between mb-4">
        <div className="flex items-center space-x-2">
          <h3 className="text-lg font-semibold text-text-primary">Notifications</h3>
          {unreadCount > 0 && (
            <div className="w-5 h-5 bg-accent text-white text-xs font-bold rounded-full flex items-center justify-center">
              {unreadCount}
            </div>
          )}
        </div>
        <div className="flex items-center space-x-2">
          {unreadCount > 0 && (
            <button
              onClick={markAllAsRead}
              className="text-xs text-primary hover:text-primary-700 transition-colors duration-150 ease-out"
            >
              Mark all read
            </button>
          )}
          <button
            onClick={() => setIsExpanded(!isExpanded)}
            className="p-1 hover:bg-surface-secondary rounded transition-colors duration-150 ease-out"
          >
            <Icon name={isExpanded ? 'ChevronUp' : 'ChevronDown'} size={16} />
          </button>
        </div>
      </div>

      <div className="space-y-3">
        {(isExpanded ? notificationList : notificationList.slice(0, 3)).map((notification) => (
          <div
            key={notification.id}
            className={`p-3 border rounded-lg transition-colors duration-150 ease-out cursor-pointer hover:bg-surface-secondary ${
              !notification.read ? 'border-primary-200 bg-primary-50' : 'border-border bg-surface'
            }`}
            onClick={() => markAsRead(notification.id)}
          >
            <div className="flex items-start space-x-3">
              <Icon
                name={getNotificationIcon(notification.type)}
                size={16}
                className={getNotificationColor(notification.type)}
              />
              <div className="flex-1 min-w-0">
                <div className="flex items-center justify-between mb-1">
                  <h4 className={`text-sm font-medium ${!notification.read ? 'text-text-primary' : 'text-text-secondary'}`}>
                    {notification.title}
                  </h4>
                  {!notification.read && (
                    <div className="w-2 h-2 bg-primary rounded-full flex-shrink-0" />
                  )}
                </div>
                <p className="text-xs text-text-secondary mb-1 line-clamp-2">
                  {notification.message}
                </p>
                <span className="text-xs text-text-secondary">
                  {formatTimestamp(notification.timestamp)}
                </span>
              </div>
            </div>
          </div>
        ))}
      </div>

      {!isExpanded && notificationList.length > 3 && (
        <button
          onClick={() => setIsExpanded(true)}
          className="w-full mt-3 py-2 text-sm text-primary hover:text-primary-700 transition-colors duration-150 ease-out"
        >
          View {notificationList.length - 3} more notifications
        </button>
      )}
    </div>
  );
};

export default NotificationCenter;