import React from 'react';
import Icon from 'components/AppIcon';

const StatusCard = ({ title, value, subtitle, icon, status, action }) => {
  const getStatusColor = () => {
    switch (status) {
      case 'success':
        return 'border-success-200 bg-success-50';
      case 'warning':
        return 'border-warning-200 bg-warning-50';
      case 'error':
        return 'border-error-200 bg-error-50';
      case 'info':
        return 'border-primary-200 bg-primary-50';
      case 'active':
        return 'border-secondary-200 bg-secondary-50';
      default:
        return 'border-border bg-surface';
    }
  };

  const getIconColor = () => {
    switch (status) {
      case 'success':
        return 'text-success';
      case 'warning':
        return 'text-warning';
      case 'error':
        return 'text-error';
      case 'info':
        return 'text-primary';
      case 'active':
        return 'text-secondary';
      default:
        return 'text-text-secondary';
    }
  };

  const getValueColor = () => {
    switch (status) {
      case 'success':
        return 'text-success-700';
      case 'warning':
        return 'text-warning-700';
      case 'error':
        return 'text-error-700';
      case 'info':
        return 'text-primary-700';
      case 'active':
        return 'text-secondary-700';
      default:
        return 'text-text-primary';
    }
  };

  return (
    <div
      className={`p-4 border rounded-lg transition-all duration-150 ease-out ${getStatusColor()} ${
        action ? 'cursor-pointer hover:shadow-elevation-2' : ''
      }`}
      onClick={action}
    >
      <div className="flex items-center justify-between mb-2">
        <Icon name={icon} size={20} className={getIconColor()} />
        {status === 'warning' && (
          <div className="w-2 h-2 bg-warning rounded-full animate-pulse" />
        )}
        {status === 'active' && (
          <div className="w-2 h-2 bg-secondary rounded-full animate-pulse" />
        )}
      </div>
      
      <div>
        <h3 className="text-sm font-medium text-text-secondary mb-1">{title}</h3>
        <p className={`text-xl font-bold ${getValueColor()} mb-1`}>{value}</p>
        <p className="text-xs text-text-secondary">{subtitle}</p>
      </div>
      
      {action && (
        <div className="mt-3 flex justify-end">
          <Icon name="ChevronRight" size={16} className="text-text-secondary" />
        </div>
      )}
    </div>
  );
};

export default StatusCard;