import React from 'react';
import Icon from 'components/AppIcon';

const QuickActionTile = ({ title, description, icon, color, urgent, badge, onClick }) => {
  return (
    <button
      onClick={onClick}
      className={`relative w-full p-4 rounded-lg text-white transition-all duration-200 ease-in-out hover:shadow-elevation-3 transform hover:-translate-y-1 min-h-touch ${color} ${
        urgent ? 'ring-2 ring-accent ring-opacity-50 animate-pulse' : ''
      }`}
    >
      <div className="flex items-start justify-between mb-3">
        <Icon name={icon} size={24} className="text-white" />
        {badge && (
          <div className="absolute -top-2 -right-2 w-6 h-6 bg-accent text-white text-xs font-bold rounded-full flex items-center justify-center">
            {badge}
          </div>
        )}
        {urgent && (
          <div className="absolute -top-1 -right-1 w-3 h-3 bg-accent rounded-full animate-ping" />
        )}
      </div>
      
      <div className="text-left">
        <h3 className="text-lg font-semibold mb-1">{title}</h3>
        <p className="text-sm opacity-90">{description}</p>
      </div>
      
      <div className="mt-3 flex justify-end">
        <Icon name="ArrowRight" size={16} className="text-white opacity-75" />
      </div>
    </button>
  );
};

export default QuickActionTile;