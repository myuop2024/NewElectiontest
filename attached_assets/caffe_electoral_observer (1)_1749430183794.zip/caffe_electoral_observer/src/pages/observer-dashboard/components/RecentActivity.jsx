import React from 'react';
import Icon from 'components/AppIcon';

const RecentActivity = ({ observerRole }) => {
  const getActivityData = () => {
    const baseActivities = [
      {
        id: 1,
        type: 'check-in',
        title: 'Station Check-in Completed',
        description: 'Successfully checked in at PS-001-A',
        timestamp: new Date(Date.now() - 300000),
        icon: 'MapPin',
        color: 'text-success'
      },
      {
        id: 2,
        type: 'document',
        title: 'Document Uploaded',
        description: 'Voter registration form processed via OCR',
        timestamp: new Date(Date.now() - 600000),
        icon: 'Upload',
        color: 'text-primary'
      },
      {
        id: 3,
        type: 'message',
        title: 'Message Received',
        description: 'New guidelines from Parish Coordinator',
        timestamp: new Date(Date.now() - 900000),
        icon: 'MessageSquare',
        color: 'text-warning'
      },
      {
        id: 4,
        type: 'training',
        title: 'Training Module Completed',
        description: 'Electoral Procedures Certification earned',
        timestamp: new Date(Date.now() - 1800000),
        icon: 'GraduationCap',
        color: 'text-secondary'
      }
    ];

    // Role-specific activities
    if (observerRole === 'roving-observer') {
      baseActivities.unshift({
        id: 0,
        type: 'route',
        title: 'Route Navigation Started',
        description: 'En route to PS-003-B (ETA: 15 minutes)',
        timestamp: new Date(Date.now() - 120000),
        icon: 'Navigation',
        color: 'text-accent'
      });
    } else if (observerRole === 'parish-coordinator') {
      baseActivities.unshift({
        id: 0,
        type: 'admin',
        title: 'Team Status Review',
        description: 'Reviewed 24 observer reports and assignments',
        timestamp: new Date(Date.now() - 180000),
        icon: 'Users',
        color: 'text-purple-600'
      });
    }

    return baseActivities.slice(0, 5);
  };

  const activities = getActivityData();

  const formatTimestamp = (date) => {
    const now = new Date();
    const diffMs = now - date;
    const diffMins = Math.floor(diffMs / (1000 * 60));
    
    if (diffMins < 1) return 'Just now';
    if (diffMins < 60) return `${diffMins}m ago`;
    const diffHours = Math.floor(diffMins / 60);
    if (diffHours < 24) return `${diffHours}h ago`;
    const diffDays = Math.floor(diffHours / 24);
    return `${diffDays}d ago`;
  };

  const getActivityBackground = (type) => {
    switch (type) {
      case 'check-in':
        return 'bg-success-50 border-success-200';
      case 'document':
        return 'bg-primary-50 border-primary-200';
      case 'message':
        return 'bg-warning-50 border-warning-200';
      case 'training':
        return 'bg-secondary-50 border-secondary-200';
      case 'route':
        return 'bg-accent-50 border-accent-200';
      case 'admin':
        return 'bg-purple-50 border-purple-200';
      default:
        return 'bg-surface border-border';
    }
  };

  return (
    <div className="card p-6">
      <div className="flex items-center justify-between mb-4">
        <h2 className="text-lg font-semibold text-text-primary">Recent Activity</h2>
        <button className="text-sm text-primary hover:text-primary-700 transition-colors duration-150 ease-out">
          View All
        </button>
      </div>

      <div className="space-y-4">
        {activities.map((activity, index) => (
          <div key={activity.id} className="relative">
            {/* Timeline Line */}
            {index < activities.length - 1 && (
              <div className="absolute left-6 top-12 w-0.5 h-8 bg-border" />
            )}
            
            <div className={`flex items-start space-x-4 p-3 border rounded-lg ${getActivityBackground(activity.type)}`}>
              <div className={`w-8 h-8 rounded-full flex items-center justify-center bg-surface border-2 ${activity.color.replace('text-', 'border-')}`}>
                <Icon name={activity.icon} size={16} className={activity.color} />
              </div>
              
              <div className="flex-1 min-w-0">
                <div className="flex items-center justify-between mb-1">
                  <h3 className="text-sm font-medium text-text-primary">
                    {activity.title}
                  </h3>
                  <span className="text-xs text-text-secondary">
                    {formatTimestamp(activity.timestamp)}
                  </span>
                </div>
                <p className="text-xs text-text-secondary">
                  {activity.description}
                </p>
              </div>
            </div>
          </div>
        ))}
      </div>

      {/* Quick Activity Actions */}
      <div className="mt-6 pt-4 border-t border-border">
        <div className="grid grid-cols-2 gap-3">
          <button className="flex items-center justify-center space-x-2 px-3 py-2 text-sm text-primary border border-primary-200 rounded-lg hover:bg-primary-50 transition-colors duration-150 ease-out">
            <Icon name="Plus" size={16} />
            <span>Quick Report</span>
          </button>
          <button className="flex items-center justify-center space-x-2 px-3 py-2 text-sm text-text-secondary border border-border rounded-lg hover:bg-surface-secondary transition-colors duration-150 ease-out">
            <Icon name="Download" size={16} />
            <span>Export Log</span>
          </button>
        </div>
      </div>
    </div>
  );
};

export default RecentActivity;