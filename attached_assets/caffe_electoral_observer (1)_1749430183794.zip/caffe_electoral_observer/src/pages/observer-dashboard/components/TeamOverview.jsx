import React from 'react';
import Icon from 'components/AppIcon';
import Image from 'components/AppImage';

const TeamOverview = () => {
  const teamData = {
    totalObservers: 24,
    checkedIn: 22,
    activeRoutes: 8,
    pendingReports: 3,
    observers: [
      {
        id: 'OBS-2024-001',
        name: 'Michael Rodriguez',
        role: 'Indoor Agent',
        station: 'PS-001-A',
        status: 'checked-in',
        lastUpdate: new Date(Date.now() - 300000),
        avatar: 'https://randomuser.me/api/portraits/men/32.jpg'
      },
      {
        id: 'OBS-2024-002',
        name: 'Sarah Johnson',
        role: 'Roving Observer',
        station: 'Route A-1',
        status: 'en-route',
        lastUpdate: new Date(Date.now() - 600000),
        avatar: 'https://randomuser.me/api/portraits/women/44.jpg'
      },
      {
        id: 'OBS-2024-003',
        name: 'David Chen',
        role: 'Indoor Agent',
        station: 'PS-003-B',
        status: 'checked-in',
        lastUpdate: new Date(Date.now() - 900000),
        avatar: 'https://randomuser.me/api/portraits/men/56.jpg'
      },
      {
        id: 'OBS-2024-004',
        name: 'Maria Garcia',
        role: 'Roving Observer',
        station: 'Route B-2',
        status: 'offline',
        lastUpdate: new Date(Date.now() - 1800000),
        avatar: 'https://randomuser.me/api/portraits/women/68.jpg'
      },
      {
        id: 'OBS-2024-005',
        name: 'James Wilson',
        role: 'Indoor Agent',
        station: 'PS-005-C',
        status: 'pending',
        lastUpdate: new Date(Date.now() - 2400000),
        avatar: 'https://randomuser.me/api/portraits/men/78.jpg'
      }
    ]
  };

  const getStatusColor = (status) => {
    switch (status) {
      case 'checked-in':
        return 'bg-success text-white';
      case 'en-route':
        return 'bg-warning text-white';
      case 'offline':
        return 'bg-error text-white';
      case 'pending':
        return 'bg-text-secondary text-white';
      default:
        return 'bg-surface-secondary text-text-secondary';
    }
  };

  const getStatusIcon = (status) => {
    switch (status) {
      case 'checked-in':
        return 'CheckCircle';
      case 'en-route':
        return 'Navigation';
      case 'offline':
        return 'WifiOff';
      case 'pending':
        return 'Clock';
      default:
        return 'User';
    }
  };

  const formatLastUpdate = (date) => {
    const now = new Date();
    const diffMs = now - date;
    const diffMins = Math.floor(diffMs / (1000 * 60));
    
    if (diffMins < 1) return 'Just now';
    if (diffMins < 60) return `${diffMins}m ago`;
    const diffHours = Math.floor(diffMins / 60);
    return `${diffHours}h ago`;
  };

  return (
    <div className="card p-6">
      <div className="flex items-center justify-between mb-6">
        <h2 className="text-lg font-semibold text-text-primary">Team Overview</h2>
        <button className="text-sm text-primary hover:text-primary-700 transition-colors duration-150 ease-out">
          View All
        </button>
      </div>

      {/* Summary Stats */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4 mb-6">
        <div className="text-center p-3 bg-success-50 border border-success-200 rounded-lg">
          <div className="text-2xl font-bold text-success-700">{teamData.checkedIn}</div>
          <div className="text-xs text-success-600">Checked In</div>
        </div>
        <div className="text-center p-3 bg-warning-50 border border-warning-200 rounded-lg">
          <div className="text-2xl font-bold text-warning-700">{teamData.activeRoutes}</div>
          <div className="text-xs text-warning-600">Active Routes</div>
        </div>
        <div className="text-center p-3 bg-error-50 border border-error-200 rounded-lg">
          <div className="text-2xl font-bold text-error-700">{teamData.totalObservers - teamData.checkedIn}</div>
          <div className="text-xs text-error-600">Not Checked In</div>
        </div>
        <div className="text-center p-3 bg-primary-50 border border-primary-200 rounded-lg">
          <div className="text-2xl font-bold text-primary-700">{teamData.pendingReports}</div>
          <div className="text-xs text-primary-600">Pending Reports</div>
        </div>
      </div>

      {/* Observer List */}
      <div className="space-y-3">
        <h3 className="text-sm font-medium text-text-primary mb-3">Recent Activity</h3>
        {teamData.observers.map((observer) => (
          <div key={observer.id} className="flex items-center space-x-3 p-3 border border-border rounded-lg hover:bg-surface-secondary transition-colors duration-150 ease-out">
            <div className="relative">
              <div className="w-10 h-10 rounded-full overflow-hidden">
                <Image
                  src={observer.avatar}
                  alt={observer.name}
                  className="w-full h-full object-cover"
                />
              </div>
              <div className={`absolute -bottom-1 -right-1 w-4 h-4 rounded-full flex items-center justify-center ${getStatusColor(observer.status)}`}>
                <Icon name={getStatusIcon(observer.status)} size={8} />
              </div>
            </div>
            
            <div className="flex-1 min-w-0">
              <div className="flex items-center justify-between">
                <h4 className="text-sm font-medium text-text-primary truncate">
                  {observer.name}
                </h4>
                <span className="text-xs text-text-secondary">
                  {formatLastUpdate(observer.lastUpdate)}
                </span>
              </div>
              <div className="flex items-center space-x-2 mt-1">
                <span className="text-xs text-text-secondary">{observer.role}</span>
                <span className="text-xs text-text-secondary">•</span>
                <span className="text-xs text-text-secondary">{observer.station}</span>
              </div>
            </div>
            
            <div className="flex items-center space-x-2">
              <span className={`px-2 py-1 text-xs font-medium rounded-full ${getStatusColor(observer.status)}`}>
                {observer.status.replace('-', ' ')}
              </span>
              <button className="p-1 hover:bg-surface-secondary rounded transition-colors duration-150 ease-out">
                <Icon name="MoreVertical" size={16} className="text-text-secondary" />
              </button>
            </div>
          </div>
        ))}
      </div>

      {/* Quick Actions */}
      <div className="mt-6 pt-4 border-t border-border">
        <div className="grid grid-cols-2 gap-3">
          <button className="flex items-center justify-center space-x-2 px-4 py-2 bg-primary text-white rounded-lg hover:bg-primary-700 transition-colors duration-150 ease-out">
            <Icon name="MessageSquare" size={16} />
            <span className="text-sm font-medium">Broadcast Message</span>
          </button>
          <button className="flex items-center justify-center space-x-2 px-4 py-2 border border-border text-text-primary rounded-lg hover:bg-surface-secondary transition-colors duration-150 ease-out">
            <Icon name="Download" size={16} />
            <span className="text-sm font-medium">Export Report</span>
          </button>
        </div>
      </div>
    </div>
  );
};

export default TeamOverview;