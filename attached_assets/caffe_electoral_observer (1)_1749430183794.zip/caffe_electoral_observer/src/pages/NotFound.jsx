import React from 'react';
import { useNavigate } from 'react-router-dom';
import Icon from 'components/AppIcon';

const NotFound = () => {
  const navigate = useNavigate();

  const handleGoHome = () => {
    navigate('/login-registration');
  };

  return (
    <div className="min-h-screen bg-background flex items-center justify-center px-4">
      <div className="max-w-md w-full text-center">
        {/* CAFFE Logo */}
        <div className="mb-8">
          <div className="w-16 h-16 bg-primary rounded-lg flex items-center justify-center mx-auto mb-4">
            <svg
              viewBox="0 0 24 24"
              className="w-8 h-8 text-white"
              fill="currentColor"
            >
              <path d="M12 2L2 7v10c0 5.55 3.84 9.74 9 11 5.16-1.26 9-5.45 9-11V7l-10-5z" />
              <path d="M9 12l2 2 4-4" stroke="white" strokeWidth="2" fill="none" />
            </svg>
          </div>
          <h1 className="text-2xl font-bold text-text-primary">CAFFE</h1>
          <p className="text-sm text-text-secondary font-mono">Electoral Observer Platform</p>
        </div>

        {/* 404 Error */}
        <div className="mb-8">
          <div className="text-6xl font-bold text-primary mb-4">404</div>
          <h2 className="text-2xl font-semibold text-text-primary mb-2">Page Not Found</h2>
          <p className="text-text-secondary mb-6">
            The page you're looking for doesn't exist or has been moved. Please check the URL or return to the login page.
          </p>
        </div>

        {/* Action Button */}
        <button
          onClick={handleGoHome}
          className="w-full flex items-center justify-center space-x-2 px-6 py-3 bg-primary text-white rounded-lg hover:bg-primary-700 transition-colors duration-200 ease-in-out min-h-touch"
        >
          <Icon name="Home" size={20} />
          <span className="font-medium">Return to Login</span>
        </button>

        {/* Additional Help */}
        <div className="mt-8 p-4 bg-surface border border-border rounded-lg">
          <div className="flex items-center space-x-2 mb-2">
            <Icon name="HelpCircle" size={16} className="text-primary" />
            <span className="text-sm font-medium text-text-primary">Need Help?</span>
          </div>
          <p className="text-xs text-text-secondary">
            If you believe this is an error, please contact CAFFE technical support for assistance.
          </p>
        </div>
      </div>
    </div>
  );
};

export default NotFound;