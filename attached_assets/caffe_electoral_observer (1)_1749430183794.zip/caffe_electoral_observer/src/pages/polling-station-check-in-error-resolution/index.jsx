// src/pages/polling-station-check-in-error-resolution/index.jsx
import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import Header from 'components/ui/Header';
import Sidebar from 'components/ui/Sidebar';
import Button from 'components/ui/Button';
import Icon from 'components/AppIcon';
import ErrorPanel from './components/ErrorPanel';
import DiagnosticSection from './components/DiagnosticSection';
import GpsTroubleshooting from './components/GpsTroubleshooting';
import NetworkRecovery from './components/NetworkRecovery';
import StationVerification from './components/StationVerification';
import EmergencyContactPanel from './components/EmergencyContactPanel';
import ProgressIndicator from './components/ProgressIndicator';

const PollingStationCheckInErrorResolution = () => {
  const navigate = useNavigate();
  const [errorType, setErrorType] = useState('gps-accuracy'); // gps-accuracy, network-connectivity, station-mismatch, server-timeout
  const [retryCount, setRetryCount] = useState(0);
  const [isManualOverrideEnabled, setIsManualOverrideEnabled] = useState(false);
  const [isOfflineModeActive, setIsOfflineModeActive] = useState(false);
  const [diagnosticData, setDiagnosticData] = useState({
    gpsSignalStrength: 45, // percentage
    internetConnectivity: 'intermittent', // 'strong', 'intermittent', 'none'
    serverResponseTime: 2800, // ms
    batteryLevel: 65, // percentage
    lastSyncTime: new Date(Date.now() - 900000), // 15 mins ago
  });

  // Simulated diagnostic refresh
  const refreshDiagnostics = () => {
    setDiagnosticData(prev => ({
      ...prev,
      gpsSignalStrength: Math.min(100, prev.gpsSignalStrength + Math.random() * 20 - 5),
      internetConnectivity: ['strong', 'intermittent', 'none'][Math.floor(Math.random() * 3)],
      serverResponseTime: Math.max(500, prev.serverResponseTime + Math.random() * 1000 - 500),
      lastSyncTime: new Date(),
    }));
  };

  // Handler for retry action
  const handleRetry = () => {
    setRetryCount(prev => prev + 1);
    refreshDiagnostics();
    
    // Simulated success chance increasing with each retry
    const successProbability = Math.min(0.8, 0.2 + (retryCount * 0.15));
    
    if (Math.random() < successProbability) {
      // Navigate back to dashboard with success message
      navigate('/observer-dashboard', { 
        state: { 
          notification: {
            type: 'success',
            message: 'Check-in successful after recovery'
          }
        }
      });
    } else {
      // Change error type randomly to simulate different error scenarios
      const errorTypes = ['gps-accuracy', 'network-connectivity', 'station-mismatch', 'server-timeout'];
      setErrorType(errorTypes[Math.floor(Math.random() * errorTypes.length)]);
    }
  };

  // Handler for manual override
  const handleManualOverride = () => {
    setIsManualOverrideEnabled(true);
  };

  // Handler for offline mode
  const handleOfflineMode = () => {
    setIsOfflineModeActive(true);
    // In a real app, this would configure the app for offline data storage
    setTimeout(() => {
      navigate('/observer-dashboard', {
        state: {
          notification: {
            type: 'info',
            message: 'Switched to offline mode. Data will sync when connection is restored.'
          }
        }
      });
    }, 1500);
  };

  // Handler for emergency contact
  const handleEmergencyContact = (contactType) => {
    // In a real app, this would initiate a call or message
    console.log(`Contacting ${contactType} support`);
  };

  // Get success probability based on current diagnostics
  const getSuccessProbability = () => {
    let probability = 0;
    
    // GPS signal contribution
    probability += (diagnosticData.gpsSignalStrength / 100) * 0.4;
    
    // Internet connectivity contribution
    if (diagnosticData.internetConnectivity === 'strong') probability += 0.3;
    else if (diagnosticData.internetConnectivity === 'intermittent') probability += 0.15;
    
    // Server response time contribution (inverse - faster is better)
    const responseTimeFactor = Math.max(0, 1 - (diagnosticData.serverResponseTime / 5000));
    probability += responseTimeFactor * 0.2;
    
    // Retry count contribution
    probability += Math.min(0.1, retryCount * 0.02);
    
    return Math.min(0.95, probability);
  };

  // Periodically refresh diagnostics
  useEffect(() => {
    const interval = setInterval(() => {
      refreshDiagnostics();
    }, 10000);
    
    return () => clearInterval(interval);
  }, []);

  return (
    <div className="min-h-screen bg-background">
      <Header />
      <Sidebar />
      
      {/* Main Content */}
      <main className="lg:ml-64 pt-16 pb-20 lg:pb-6">
        <div className="p-4 lg:p-6 max-w-7xl mx-auto">
          {/* Page Header */}
          <div className="mb-6">
            <div className="flex items-center mb-2">
              <button 
                onClick={() => navigate('/observer-dashboard')}
                className="mr-3 hover:bg-surface rounded-full p-1"
              >
                <Icon name="ArrowLeft" size={20} className="text-text-secondary" />
              </button>
              <h1 className="text-2xl font-bold text-text-primary">Polling Station Check-in</h1>
            </div>
            <div className="flex items-center text-text-secondary">
              <Icon name="AlertTriangle" size={16} className="mr-2 text-warning" />
              <span>Error recovery mode</span>
            </div>
          </div>
          
          {/* Content Grid */}
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
            {/* Main Error Resolution Panel */}
            <div className="lg:col-span-8 space-y-6">
              {/* Error Panel */}
              <ErrorPanel 
                errorType={errorType} 
                retryCount={retryCount}
              />
              
              {/* Diagnostic Section */}
              <DiagnosticSection 
                diagnosticData={diagnosticData}
                onRefresh={refreshDiagnostics}
              />
              
              {/* Resolution Actions */}
              <div className="card p-6">
                <h2 className="text-lg font-semibold text-text-primary mb-4">Resolution Actions</h2>
                <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                  <Button
                    variant="primary"
                    fullWidth
                    iconName="RefreshCw"
                    onClick={handleRetry}
                  >
                    Retry Check-in
                  </Button>
                  <Button
                    variant="secondary"
                    fullWidth
                    iconName="Shield"
                    onClick={handleManualOverride}
                    disabled={isManualOverrideEnabled}
                  >
                    Manual Override
                  </Button>
                  <Button
                    variant="outline"
                    fullWidth
                    iconName="Database"
                    onClick={handleOfflineMode}
                    disabled={isOfflineModeActive}
                  >
                    Offline Mode
                  </Button>
                </div>
                
                {isManualOverrideEnabled && (
                  <div className="mt-4 p-4 bg-warning-50 border border-warning-200 rounded-lg">
                    <div className="flex items-center mb-2">
                      <Icon name="Shield" size={18} className="text-warning mr-2" />
                      <span className="font-medium">Manual Override Requested</span>
                    </div>
                    <p className="text-sm text-text-secondary mb-3">
                      A supervisor approval request has been sent. Please wait for authorization.
                    </p>
                    <div className="flex items-center">
                      <div className="w-full h-2 bg-border rounded-full overflow-hidden">
                        <div className="h-full bg-warning animate-pulse w-1/3" />
                      </div>
                      <span className="ml-3 text-xs font-medium">Awaiting approval</span>
                    </div>
                  </div>
                )}
              </div>
              
              {/* Progress Indicator */}
              <ProgressIndicator 
                retryCount={retryCount} 
                successProbability={getSuccessProbability()} 
              />
              
              {/* Troubleshooting Guides */}
              <div className="space-y-6">
                {errorType === 'gps-accuracy' && (
                  <GpsTroubleshooting gpsStrength={diagnosticData.gpsSignalStrength} />
                )}
                
                {errorType === 'network-connectivity' && (
                  <NetworkRecovery connectionStatus={diagnosticData.internetConnectivity} />
                )}
                
                {errorType === 'station-mismatch' && (
                  <StationVerification />
                )}
              </div>
            </div>
            
            {/* Sidebar Content */}
            <div className="lg:col-span-4 space-y-6">
              {/* Emergency Contact Panel */}
              <EmergencyContactPanel 
                errorType={errorType} 
                errorCode={`ERR-${errorType.substring(0, 3).toUpperCase()}-${Math.floor(Math.random() * 1000)}`}
                retryCount={retryCount}
                onContactSupport={() => handleEmergencyContact('technical')}
                onContactCoordinator={() => handleEmergencyContact('coordinator')}
              />
              
              {/* Desktop-only: Detailed Error Logs */}
              <div className="hidden lg:block card p-6">
                <div className="flex items-center justify-between mb-4">
                  <h3 className="text-lg font-semibold text-text-primary">System Diagnostics</h3>
                  <button className="text-xs text-primary hover:text-primary-700">
                    Export Logs
                  </button>
                </div>
                <div className="bg-surface-secondary rounded-lg p-3 font-mono text-xs overflow-x-auto">
                  <div className="text-text-secondary">
                    <div className="grid grid-cols-[80px_1fr] gap-2">
                      <span className="text-error">[ERROR]</span>
                      <span>Check-in attempt failed: {errorType.replace('-', ' ')}</span>
                      
                      <span className="text-text-tertiary">[INFO]</span>
                      <span>GPS coordinates: {(35.12345 + Math.random() * 0.001).toFixed(5)}, {(-106.54321 + Math.random() * 0.001).toFixed(5)}</span>
                      
                      <span className="text-text-tertiary">[INFO]</span>
                      <span>Device ID: OBS-{Math.floor(Math.random() * 10000)}</span>
                      
                      <span className="text-warning">[WARN]</span>
                      <span>Signal strength: {diagnosticData.gpsSignalStrength.toFixed(1)}%</span>
                      
                      <span className="text-text-tertiary">[INFO]</span>
                      <span>Network type: {diagnosticData.internetConnectivity === 'strong' ? 'LTE' : diagnosticData.internetConnectivity === 'intermittent' ? '3G' : 'No signal'}</span>
                      
                      <span className="text-text-tertiary">[INFO]</span>
                      <span>Battery: {diagnosticData.batteryLevel}%</span>
                      
                      <span className="text-text-tertiary">[INFO]</span>
                      <span>Retry count: {retryCount}</span>
                      
                      <span className="text-success">[DEBUG]</span>
                      <span>Success probability: {(getSuccessProbability() * 100).toFixed(1)}%</span>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </main>
    </div>
  );
};

export default PollingStationCheckInErrorResolution;