// src/pages/polling-station-check-in-error-resolution/components/DiagnosticSection.jsx
import React from 'react';
import Icon from 'components/AppIcon';
import Button from 'components/ui/Button';

const DiagnosticSection = ({ diagnosticData, onRefresh }) => {
  const { gpsSignalStrength, internetConnectivity, serverResponseTime, lastSyncTime } = diagnosticData;

  // Helper to format the last sync time
  const formatLastSync = () => {
    const now = new Date();
    const diffMs = now - lastSyncTime;
    const diffMins = Math.floor(diffMs / 60000);
    
    if (diffMins < 1) return 'Just now';
    if (diffMins < 60) return `${diffMins}m ago`;
    const diffHours = Math.floor(diffMins / 60);
    return `${diffHours}h ago`;
  };

  // Helper to get connectivity status display
  const getConnectivityStatus = () => {
    switch (internetConnectivity) {
      case 'strong':
        return { text: 'Strong', icon: 'Wifi', color: 'success' };
      case 'intermittent':
        return { text: 'Intermittent', icon: 'WifiOff', color: 'warning' };
      case 'none':
        return { text: 'No Connection', icon: 'WifiOff', color: 'error' };
      default:
        return { text: 'Unknown', icon: 'HelpCircle', color: 'text-secondary' };
    }
  };

  // Helper to get server response status
  const getServerResponseStatus = () => {
    if (serverResponseTime < 1000) {
      return { text: 'Excellent', color: 'success' };
    } else if (serverResponseTime < 2000) {
      return { text: 'Good', color: 'success' };
    } else if (serverResponseTime < 3000) {
      return { text: 'Slow', color: 'warning' };
    } else {
      return { text: 'Very Slow', color: 'error' };
    }
  };

  // Helper to get GPS signal status
  const getGpsStatus = () => {
    if (gpsSignalStrength > 70) {
      return { text: 'Strong', color: 'success' };
    } else if (gpsSignalStrength > 40) {
      return { text: 'Moderate', color: 'warning' };
    } else {
      return { text: 'Weak', color: 'error' };
    }
  };

  const connectivityStatus = getConnectivityStatus();
  const serverStatus = getServerResponseStatus();
  const gpsStatus = getGpsStatus();

  return (
    <div className="card p-6">
      <div className="flex items-center justify-between mb-4">
        <h2 className="text-lg font-semibold text-text-primary">System Diagnostics</h2>
        <Button
          variant="ghost"
          size="sm"
          iconName="RefreshCw"
          onClick={onRefresh}
        >
          Refresh
        </Button>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        {/* GPS Signal Strength */}
        <div className="p-4 bg-surface-secondary rounded-lg">
          <div className="flex items-center justify-between mb-2">
            <div className="flex items-center">
              <Icon name="MapPin" size={16} className="mr-2 text-text-secondary" />
              <span className="text-sm font-medium text-text-primary">GPS Signal</span>
            </div>
            <span className={`text-xs font-medium text-${gpsStatus.color}`}>
              {gpsStatus.text}
            </span>
          </div>
          <div className="w-full h-2 bg-border rounded-full overflow-hidden mb-2">
            <div 
              className={`h-full ${gpsSignalStrength > 70 ? 'bg-success' : gpsSignalStrength > 40 ? 'bg-warning' : 'bg-error'}`}
              style={{ width: `${gpsSignalStrength}%` }}
            />
          </div>
          <span className="text-xs text-text-secondary">
            {gpsSignalStrength.toFixed(0)}% accuracy
          </span>
        </div>

        {/* Internet Connectivity */}
        <div className="p-4 bg-surface-secondary rounded-lg">
          <div className="flex items-center justify-between mb-2">
            <div className="flex items-center">
              <Icon name={connectivityStatus.icon} size={16} className="mr-2 text-text-secondary" />
              <span className="text-sm font-medium text-text-primary">Connectivity</span>
            </div>
            <span className={`text-xs font-medium text-${connectivityStatus.color}`}>
              {connectivityStatus.text}
            </span>
          </div>
          <div className="w-full h-2 bg-border rounded-full overflow-hidden mb-2">
            <div 
              className={`h-full ${internetConnectivity === 'strong' ? 'bg-success' : internetConnectivity === 'intermittent' ? 'bg-warning' : 'bg-error'}`}
              style={{ width: `${internetConnectivity === 'strong' ? 100 : internetConnectivity === 'intermittent' ? 50 : 10}%` }}
            />
          </div>
          <span className="text-xs text-text-secondary">
            Last sync: {formatLastSync()}
          </span>
        </div>

        {/* Server Response Time */}
        <div className="p-4 bg-surface-secondary rounded-lg">
          <div className="flex items-center justify-between mb-2">
            <div className="flex items-center">
              <Icon name="Server" size={16} className="mr-2 text-text-secondary" />
              <span className="text-sm font-medium text-text-primary">Server Response</span>
            </div>
            <span className={`text-xs font-medium text-${serverStatus.color}`}>
              {serverStatus.text}
            </span>
          </div>
          <div className="w-full h-2 bg-border rounded-full overflow-hidden mb-2">
            <div 
              className={`h-full ${serverResponseTime < 1000 ? 'bg-success' : serverResponseTime < 3000 ? 'bg-warning' : 'bg-error'}`}
              style={{ width: `${Math.max(10, 100 - (serverResponseTime / 50))}%` }}
            />
          </div>
          <span className="text-xs text-text-secondary">
            {(serverResponseTime / 1000).toFixed(1)}s response time
          </span>
        </div>
      </div>
    </div>
  );
};

export default DiagnosticSection;