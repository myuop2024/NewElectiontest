// src/pages/polling-station-check-in-error-resolution/components/EmergencyContactPanel.jsx
import React from 'react';
import Icon from 'components/AppIcon';


const EmergencyContactPanel = ({ errorType, errorCode, retryCount, onContactSupport, onContactCoordinator }) => {
  // Determine urgency level based on error type and retry count
  const getUrgencyLevel = () => {
    if (retryCount >= 3) return 'high';
    if (errorType === 'network-connectivity' || errorType === 'station-mismatch') return 'medium';
    return 'low';
  };

  const urgencyLevel = getUrgencyLevel();

  // Contact options
  const contactOptions = [
    {
      id: 'technical-support',
      title: 'Technical Support',
      description: 'For app or device issues',
      icon: 'Headphones',
      color: 'primary',
      action: onContactSupport,
    },
    {
      id: 'field-coordinator',
      title: 'Field Coordinator',
      description: 'For station assignment issues',
      icon: 'Users',
      color: 'secondary',
      action: onContactCoordinator,
    },
  ];

  return (
    <div className="card p-6">
      <h2 className="text-lg font-semibold text-text-primary mb-4">Emergency Contact</h2>
      
      {/* Urgency Indicator */}
      <div className={`mb-6 p-3 bg-${urgencyLevel === 'high' ? 'error' : urgencyLevel === 'medium' ? 'warning' : 'primary'}-50 rounded-lg border border-${urgencyLevel === 'high' ? 'error' : urgencyLevel === 'medium' ? 'warning' : 'primary'}-100`}>
        <div className="flex items-center">
          <Icon 
            name={urgencyLevel === 'high' ? 'AlertCircle' : urgencyLevel === 'medium' ? 'AlertTriangle' : 'Info'} 
            size={18} 
            className={`mr-3 text-${urgencyLevel === 'high' ? 'error' : urgencyLevel === 'medium' ? 'warning' : 'primary'}`} 
          />
          <div>
            <h3 className="text-sm font-medium text-text-primary">
              {urgencyLevel === 'high' ?'Immediate assistance recommended' 
                : urgencyLevel === 'medium' ?'Contact support if issues persist' :'Self-resolution likely possible'}
            </h3>
            <p className="text-xs text-text-secondary mt-0.5">
              {retryCount > 0 ? `${retryCount} failed attempts` : 'First attempt failed'}
            </p>
          </div>
        </div>
      </div>
      
      {/* Error Information */}
      <div className="mb-6 p-4 bg-surface-secondary rounded-lg">
        <h3 className="text-sm font-medium text-text-primary mb-2">Error Information</h3>
        <div className="space-y-2 text-sm">
          <div className="flex items-center">
            <span className="text-text-secondary w-24">Error Type:</span>
            <span className="text-text-primary font-mono">{errorType.replace('-', ' ')}</span>
          </div>
          <div className="flex items-center">
            <span className="text-text-secondary w-24">Error Code:</span>
            <span className="text-text-primary font-mono">{errorCode}</span>
          </div>
          <div className="flex items-center">
            <span className="text-text-secondary w-24">Timestamp:</span>
            <span className="text-text-primary font-mono">{new Date().toISOString()}</span>
          </div>
          <div className="flex items-center">
            <span className="text-text-secondary w-24">Retry Count:</span>
            <span className="text-text-primary font-mono">{retryCount}</span>
          </div>
        </div>
      </div>
      
      {/* Contact Options */}
      <div className="space-y-3">
        {contactOptions.map((option) => (
          <button
            key={option.id}
            onClick={option.action}
            className={`w-full flex items-center p-3 border border-${option.color}-100 rounded-lg transition-colors duration-150 hover:bg-${option.color}-50`}
          >
            <div className={`w-10 h-10 rounded-full bg-${option.color}-50 flex items-center justify-center mr-3`}>
              <Icon name={option.icon} size={18} className={`text-${option.color}`} />
            </div>
            <div className="text-left">
              <h3 className="text-sm font-medium text-text-primary">{option.title}</h3>
              <p className="text-xs text-text-secondary">{option.description}</p>
            </div>
            <Icon name="ArrowRight" size={16} className={`ml-auto text-${option.color}`} />
          </button>
        ))}
      </div>
      
      {/* Communication Tip */}
      <div className="mt-6 p-3 bg-surface-secondary rounded-lg">
        <div className="flex items-start">
          <Icon name="Lightbulb" size={16} className="text-text-secondary mr-2 mt-0.5" />
          <p className="text-xs text-text-secondary">
            When contacting support, your error code and device information will be automatically transmitted to expedite troubleshooting.
          </p>
        </div>
      </div>
    </div>
  );
};

export default EmergencyContactPanel;