// src/pages/polling-station-check-in-error-resolution/components/ProgressIndicator.jsx
import React from 'react';
import Icon from 'components/AppIcon';

const ProgressIndicator = ({ retryCount, successProbability }) => {
  // Format success probability as percentage
  const successPercentage = Math.round(successProbability * 100);
  
  // Determine status color based on success probability
  const getStatusColor = () => {
    if (successPercentage >= 70) return 'success';
    if (successPercentage >= 40) return 'warning';
    return 'error';
  };
  
  // Get status message based on probability
  const getStatusMessage = () => {
    if (successPercentage >= 70) return 'High chance of success';
    if (successPercentage >= 40) return 'Moderate chance of success';
    return 'Low chance of success';
  };
  
  const statusColor = getStatusColor();
  const statusMessage = getStatusMessage();
  
  return (
    <div className="card p-6">
      <div className="flex items-center justify-between mb-4">
        <h2 className="text-lg font-semibold text-text-primary">Recovery Progress</h2>
        <div className="flex items-center space-x-2">
          <span className="text-sm text-text-secondary">Retry attempts:</span>
          <span className="text-sm font-medium">{retryCount}</span>
        </div>
      </div>
      
      {/* Success Probability Meter */}
      <div className="mb-6">
        <div className="flex items-center justify-between mb-2">
          <span className="text-sm text-text-secondary">Success probability</span>
          <span className={`text-sm font-medium text-${statusColor}`}>{successPercentage}%</span>
        </div>
        <div className="w-full h-3 bg-surface-secondary rounded-full overflow-hidden">
          <div 
            className={`h-full bg-${statusColor}`}
            style={{ width: `${successPercentage}%` }}
          />
        </div>
        <div className="mt-1 flex justify-between items-center">
          <span className="text-xs text-text-tertiary">Low</span>
          <span className={`text-xs font-medium text-${statusColor}`}>{statusMessage}</span>
          <span className="text-xs text-text-tertiary">High</span>
        </div>
      </div>
      
      {/* Contributing Factors */}
      <div>
        <h3 className="text-sm font-medium text-text-primary mb-3">Contributing Factors</h3>
        <div className="space-y-2">
          {/* Retry Factor */}
          <div className="flex items-center justify-between">
            <div className="flex items-center">
              <Icon name="RefreshCw" size={14} className="text-text-secondary mr-2" />
              <span className="text-sm text-text-secondary">Retry attempts</span>
            </div>
            <div className="flex items-center">
              <div className="w-16 h-1.5 bg-surface-secondary rounded-full overflow-hidden mr-2">
                <div 
                  className={`h-full ${retryCount > 2 ? 'bg-success' : 'bg-warning'}`}
                  style={{ width: `${Math.min(100, retryCount * 33.3)}%` }}
                />
              </div>
              <span className="text-xs text-text-secondary">{retryCount > 2 ? 'Good' : 'Limited'}</span>
            </div>
          </div>
          
          {/* Time Factor */}
          <div className="flex items-center justify-between">
            <div className="flex items-center">
              <Icon name="Clock" size={14} className="text-text-secondary mr-2" />
              <span className="text-sm text-text-secondary">Time elapsed</span>
            </div>
            <div className="flex items-center">
              <div className="w-16 h-1.5 bg-surface-secondary rounded-full overflow-hidden mr-2">
                <div 
                  className="h-full bg-warning"
                  style={{ width: '60%' }}
                />
              </div>
              <span className="text-xs text-text-secondary">Moderate</span>
            </div>
          </div>
          
          {/* Connectivity Factor */}
          <div className="flex items-center justify-between">
            <div className="flex items-center">
              <Icon name="Wifi" size={14} className="text-text-secondary mr-2" />
              <span className="text-sm text-text-secondary">Network stability</span>
            </div>
            <div className="flex items-center">
              <div className="w-16 h-1.5 bg-surface-secondary rounded-full overflow-hidden mr-2">
                <div 
                  className={`h-full ${successProbability > 0.6 ? 'bg-success' : 'bg-warning'}`}
                  style={{ width: `${successProbability * 100}%` }}
                />
              </div>
              <span className="text-xs text-text-secondary">{successProbability > 0.6 ? 'Good' : 'Variable'}</span>
            </div>
          </div>
        </div>
      </div>
      
      {/* Auto-retry Notice - show if probability is high */}
      {successProbability > 0.7 && (
        <div className="mt-4 p-3 bg-success-50 border border-success-100 rounded-lg flex items-center">
          <Icon name="Clock" size={16} className="text-success mr-2" />
          <p className="text-xs text-text-secondary">
            <span className="font-medium">Auto-retry scheduled:</span> The system will automatically attempt another check-in in 30 seconds based on improved conditions.
          </p>
        </div>
      )}
    </div>
  );
};

export default ProgressIndicator;