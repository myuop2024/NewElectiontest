// src/pages/polling-station-check-in-error-resolution/components/NetworkRecovery.jsx
import React from 'react';
import Icon from 'components/AppIcon';
import Button from 'components/ui/Button';

const NetworkRecovery = ({ connectionStatus }) => {
  const recoverySteps = [
    {
      id: 1,
      title: 'Switch between WiFi and cellular data',
      description: 'If WiFi is unreliable, try switching to cellular data. If cellular data is slow, connect to a nearby WiFi network.',
      icon: 'ToggleLeft',
      actionText: 'Switch Network Type',
      priority: 'high',
    },
    {
      id: 2,
      title: 'Enable airplane mode reset',
      description: 'Turn on airplane mode for 30 seconds, then turn it off. This will reset all network connections.',
      icon: 'Plane',
      actionText: 'Toggle Airplane Mode',
      priority: 'medium',
    },
    {
      id: 3,
      title: 'Move to a better coverage area',
      description: 'Try moving to a window or outside where signal strength may be better.',
      icon: 'MoveHorizontal',
      priority: 'medium',
    },
    {
      id: 4,
      title: 'Activate SMS fallback',
      description: 'When internet is unavailable, enable SMS mode to send critical data via text message.',
      icon: 'MessageSquare',
      actionText: 'Enable SMS Mode',
      priority: connectionStatus === 'none' ? 'high' : 'low',
    },
  ];

  // Get connection status display
  const getConnectionDisplay = () => {
    switch (connectionStatus) {
      case 'strong':
        return { text: 'Strong', icon: 'Wifi', color: 'success', description: 'Your connection is stable but the server cannot be reached.' };
      case 'intermittent':
        return { text: 'Intermittent', icon: 'WifiOff', color: 'warning', description: 'Your connection is unstable and keeps dropping.' };
      case 'none':
        return { text: 'No Connection', icon: 'WifiOff', color: 'error', description: 'Your device cannot connect to any network.' };
      default:
        return { text: 'Unknown', icon: 'HelpCircle', color: 'text-secondary', description: 'Connection status cannot be determined.' };
    }
  };

  const connectionDisplay = getConnectionDisplay();

  // Simulate network recovery action
  const handleNetworkAction = (actionText) => {
    console.log(`Performing network action: ${actionText}`);
    // In a real app, this would trigger device-specific network actions
  };

  return (
    <div className="card p-6">
      <h2 className="text-lg font-semibold text-text-primary mb-4">Network Recovery Options</h2>
      
      {/* Current Network Status */}
      <div className={`flex items-center mb-6 p-4 bg-${connectionDisplay.color}-50 border border-${connectionDisplay.color}-100 rounded-lg`}>
        <div className={`w-10 h-10 rounded-full bg-${connectionDisplay.color}-100 flex items-center justify-center mr-4`}>
          <Icon name={connectionDisplay.icon} size={20} className={`text-${connectionDisplay.color}`} />
        </div>
        <div>
          <div className="flex items-center">
            <h3 className="text-sm font-medium text-text-primary">Network Status: {connectionDisplay.text}</h3>
          </div>
          <p className="mt-1 text-sm text-text-secondary">{connectionDisplay.description}</p>
        </div>
      </div>
      
      {/* Recovery Steps */}
      <div className="space-y-4">
        {recoverySteps.map((step) => (
          <div key={step.id} className="flex items-start p-4 border border-border rounded-lg">
            <div className={`flex-shrink-0 w-10 h-10 rounded-full flex items-center justify-center mr-4 ${step.priority === 'high' ? 'bg-warning-50' : 'bg-surface-secondary'}`}>
              <Icon 
                name={step.icon} 
                size={18} 
                className={step.priority === 'high' ? 'text-warning' : 'text-text-secondary'} 
              />
            </div>
            <div className="flex-grow">
              <div className="flex items-center">
                <h3 className="text-sm font-medium text-text-primary">{step.title}</h3>
                {step.priority === 'high' && (
                  <span className="ml-2 px-2 py-0.5 bg-warning-50 text-warning text-xs font-medium rounded">Recommended</span>
                )}
              </div>
              <p className="mt-1 text-sm text-text-secondary">{step.description}</p>
              
              {step.actionText && (
                <Button
                  variant="ghost"
                  size="sm"
                  className="mt-2"
                  iconName={step.icon}
                  onClick={() => handleNetworkAction(step.actionText)}
                >
                  {step.actionText}
                </Button>
              )}
            </div>
          </div>
        ))}
      </div>
      
      {/* SMS Fallback Info */}
      {connectionStatus === 'none' && (
        <div className="mt-6 p-4 bg-accent-50 border border-accent-100 rounded-lg">
          <div className="flex items-start">
            <Icon name="AlertCircle" size={18} className="text-accent mr-3 mt-0.5" />
            <div>
              <h3 className="text-sm font-medium text-text-primary">About SMS Fallback</h3>
              <p className="mt-1 text-sm text-text-secondary">
                SMS fallback uses text messaging to send critical check-in data when internet is unavailable. This mode uses minimal data but may incur standard messaging rates.
              </p>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default NetworkRecovery;