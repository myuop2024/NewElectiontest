// src/pages/polling-station-check-in-error-resolution/components/ErrorPanel.jsx
import React from 'react';
import Icon from 'components/AppIcon';

const ErrorPanel = ({ errorType, retryCount }) => {
  // Define error details based on error type
  const errorDetails = {
    'gps-accuracy': {
      title: 'GPS Accuracy Insufficient',
      description: 'Your device cannot determine your location with sufficient accuracy to verify you are at the correct polling station.',
      icon: 'MapPin',
      color: 'warning',
      severity: 'Medium',
    },
    'network-connectivity': {
      title: 'Network Connectivity Lost',
      description: 'The application cannot connect to the central server to verify your check-in credentials.',
      icon: 'WifiOff',
      color: 'error',
      severity: 'High',
    },
    'station-mismatch': {
      title: 'Station Verification Mismatch',
      description: 'Your current location does not match the assigned polling station coordinates in our system.',
      icon: 'AlertTriangle',
      color: 'error',
      severity: 'High',
    },
    'server-timeout': {
      title: 'Server Timeout',
      description: 'The server took too long to respond to your check-in request. This may be due to high traffic or network issues.',
      icon: 'Clock',
      color: 'warning',
      severity: 'Medium',
    },
  };

  const currentError = errorDetails[errorType] || errorDetails['gps-accuracy'];

  return (
    <div className={`card p-6 border-l-4 border-${currentError.color}`}>
      <div className="flex flex-col md:flex-row md:items-start">
        <div className={`flex-shrink-0 w-12 h-12 bg-${currentError.color}-50 rounded-full flex items-center justify-center mb-4 md:mb-0 md:mr-4`}>
          <Icon 
            name={currentError.icon} 
            size={24} 
            className={`text-${currentError.color}`} 
          />
        </div>
        
        <div className="flex-grow">
          <div className="flex flex-col md:flex-row md:items-center justify-between mb-2">
            <h2 className="text-xl font-semibold text-text-primary">{currentError.title}</h2>
            <div className={`inline-flex items-center mt-2 md:mt-0 px-3 py-1 rounded-full bg-${currentError.color}-50 text-${currentError.color} text-xs font-medium`}>
              {currentError.severity} Severity
            </div>
          </div>
          
          <p className="text-text-secondary mb-4">{currentError.description}</p>
          
          <div className="flex flex-wrap items-center text-sm text-text-secondary">
            <div className="flex items-center mr-6 mb-2">
              <Icon name="Clock" size={14} className="mr-1" />
              <span>Error occurred: {new Date().toLocaleTimeString()}</span>
            </div>
            {retryCount > 0 && (
              <div className="flex items-center mr-6 mb-2">
                <Icon name="RefreshCw" size={14} className="mr-1" />
                <span>Retry attempts: {retryCount}</span>
              </div>
            )}
            <div className="flex items-center mb-2">
              <Icon name="Hash" size={14} className="mr-1" />
              <span>Error code: ERR-{errorType.substring(0, 3).toUpperCase()}-{Math.floor(Math.random() * 1000)}</span>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default ErrorPanel;