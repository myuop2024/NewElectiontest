// src/pages/polling-station-check-in-error-resolution/components/GpsTroubleshooting.jsx
import React from 'react';
import Icon from 'components/AppIcon';

const GpsTroubleshooting = ({ gpsStrength }) => {
  const troubleshootingSteps = [
    {
      id: 1,
      title: 'Move to an open area',
      description: 'GPS signals work best outdoors with a clear view of the sky. Move away from buildings, trees, or other obstructions.',
      icon: 'MoveHorizontal',
      priority: 'high',
    },
    {
      id: 2,
      title: 'Hold your device properly',
      description: 'Don\'t cover the top of your device where the GPS antenna is located. Hold it flat with the screen facing up.',
      icon: 'Smartphone',
      priority: 'medium',
    },
    {
      id: 3,
      title: 'Wait for signal acquisition',
      description: 'GPS may take 1-2 minutes to get an accurate location fix. Remain stationary in an open area.',
      icon: 'Clock',
      priority: 'medium',
    },
    {
      id: 4,
      title: 'Enable high-accuracy mode',
      description: 'Check your device location settings and ensure high-accuracy mode is enabled.',
      icon: 'Settings',
      priority: 'medium',
    },
    {
      id: 5,
      title: 'Restart location services',
      description: 'Turn your device\'s location services off and on again to reset the GPS system.',
      icon: 'RefreshCw',
      priority: 'medium',
    },
  ];

  // Filter steps based on GPS strength
  const filteredSteps = gpsStrength < 30 
    ? troubleshootingSteps 
    : troubleshootingSteps.filter(step => step.id <= 3);

  return (
    <div className="card p-6">
      <h2 className="text-lg font-semibold text-text-primary mb-4">GPS Troubleshooting Guide</h2>
      
      {/* Current GPS Status */}
      <div className="flex items-center mb-6 p-3 bg-surface-secondary rounded-lg">
        <div className="w-10 h-10 rounded-full bg-warning-50 flex items-center justify-center mr-4">
          <Icon name="MapPin" size={20} className="text-warning" />
        </div>
        <div>
          <h3 className="text-sm font-medium text-text-primary">Current GPS Accuracy</h3>
          <div className="flex items-center mt-1">
            <div className="w-24 h-2 bg-border rounded-full overflow-hidden mr-2">
              <div 
                className={`h-full ${gpsStrength > 70 ? 'bg-success' : gpsStrength > 40 ? 'bg-warning' : 'bg-error'}`}
                style={{ width: `${gpsStrength}%` }}
              />
            </div>
            <span className="text-xs text-text-secondary">{gpsStrength.toFixed(0)}% ({gpsStrength > 70 ? 'Good' : gpsStrength > 40 ? 'Moderate' : 'Poor'})</span>
          </div>
        </div>
      </div>
      
      {/* Troubleshooting Steps */}
      <div className="space-y-4">
        {filteredSteps.map((step) => (
          <div key={step.id} className="flex p-4 border border-border rounded-lg">
            <div className={`flex-shrink-0 w-10 h-10 rounded-full flex items-center justify-center mr-4 ${step.priority === 'high' ? 'bg-warning-50' : 'bg-surface-secondary'}`}>
              <Icon 
                name={step.icon} 
                size={18} 
                className={step.priority === 'high' ? 'text-warning' : 'text-text-secondary'} 
              />
            </div>
            <div>
              <div className="flex items-center">
                <h3 className="text-sm font-medium text-text-primary">{step.title}</h3>
                {step.priority === 'high' && (
                  <span className="ml-2 px-2 py-0.5 bg-warning-50 text-warning text-xs font-medium rounded">Recommended</span>
                )}
              </div>
              <p className="mt-1 text-sm text-text-secondary">{step.description}</p>
            </div>
          </div>
        ))}
      </div>
      
      {/* Additional Tips */}
      <div className="mt-6 p-4 bg-primary-50 border border-primary-100 rounded-lg">
        <div className="flex items-start">
          <Icon name="Lightbulb" size={18} className="text-primary mr-3 mt-0.5" />
          <div>
            <h3 className="text-sm font-medium text-text-primary">Pro Tip</h3>
            <p className="mt-1 text-sm text-text-secondary">
              If you're in a rural location with limited cellular coverage, your GPS may still work. Even in offline mode, your coordinates can be captured for later verification.
            </p>
          </div>
        </div>
      </div>
    </div>
  );
};

export default GpsTroubleshooting;