// src/pages/polling-station-check-in-error-resolution/components/StationVerification.jsx
import React, { useState } from 'react';
import Icon from 'components/AppIcon';
import Input from 'components/ui/Input';
import Button from 'components/ui/Button';

const StationVerification = () => {
  const [latitude, setLatitude] = useState('');
  const [longitude, setLongitude] = useState('');
  const [stationCode, setStationCode] = useState('');
  const [hasImage, setHasImage] = useState(false);
  const [isVerifying, setIsVerifying] = useState(false);

  // Expected station details (would come from API in real app)
  const expectedStation = {
    name: 'Kingston Central Primary School',
    code: 'KGN-001-A',
    coordinates: {
      latitude: 18.0179,
      longitude: -76.8099
    }
  };

  // Handle manual verification
  const handleVerify = () => {
    setIsVerifying(true);
    
    // Simulate verification process
    setTimeout(() => {
      setIsVerifying(false);
      // In a real app, this would send the verification data to the server
    }, 1500);
  };

  // Simulate taking a photo
  const handleTakePhoto = () => {
    // In a real app, this would activate the camera
    setTimeout(() => {
      setHasImage(true);
    }, 1000);
  };

  return (
    <div className="card p-6">
      <h2 className="text-lg font-semibold text-text-primary mb-4">Station Verification Panel</h2>
      
      {/* Expected vs Current Location */}
      <div className="mb-6 p-4 bg-surface-secondary rounded-lg">
        <h3 className="text-sm font-medium text-text-primary mb-3">Expected Station Details</h3>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <div className="space-y-2">
            <div className="flex items-center text-sm">
              <Icon name="MapPin" size={16} className="text-text-secondary mr-2" />
              <span className="text-text-primary font-medium">Station Name:</span>
              <span className="ml-2 text-text-secondary">{expectedStation.name}</span>
            </div>
            <div className="flex items-center text-sm">
              <Icon name="Hash" size={16} className="text-text-secondary mr-2" />
              <span className="text-text-primary font-medium">Station Code:</span>
              <span className="ml-2 text-text-secondary">{expectedStation.code}</span>
            </div>
          </div>
          <div className="space-y-2">
            <div className="flex items-center text-sm">
              <Icon name="Navigation" size={16} className="text-text-secondary mr-2" />
              <span className="text-text-primary font-medium">Latitude:</span>
              <span className="ml-2 text-text-secondary">{expectedStation.coordinates.latitude}</span>
            </div>
            <div className="flex items-center text-sm">
              <Icon name="Navigation" size={16} className="text-text-secondary mr-2" />
              <span className="text-text-primary font-medium">Longitude:</span>
              <span className="ml-2 text-text-secondary">{expectedStation.coordinates.longitude}</span>
            </div>
          </div>
        </div>
      </div>
      
      {/* Manual Coordinate Entry */}
      <div className="mb-6">
        <h3 className="text-sm font-medium text-text-primary mb-3">Manual Coordinate Entry</h3>
        <p className="text-sm text-text-secondary mb-4">
          If your GPS is not working correctly, you can manually enter your coordinates and station code for verification.
        </p>
        
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-4">
          <div>
            <label className="block text-sm font-medium text-text-secondary mb-1">Latitude</label>
            <Input 
              type="text" 
              placeholder="e.g. 18.0179"
              value={latitude}
              onChange={(e) => setLatitude(e.target.value)}
            />
          </div>
          <div>
            <label className="block text-sm font-medium text-text-secondary mb-1">Longitude</label>
            <Input 
              type="text" 
              placeholder="e.g. -76.8099"
              value={longitude}
              onChange={(e) => setLongitude(e.target.value)}
            />
          </div>
        </div>
        
        <div className="mb-4">
          <label className="block text-sm font-medium text-text-secondary mb-1">Station Code</label>
          <Input 
            type="text" 
            placeholder="Enter the station code displayed at your location"
            value={stationCode}
            onChange={(e) => setStationCode(e.target.value)}
          />
        </div>
      </div>
      
      {/* Photo Verification */}
      <div className="mb-6">
        <h3 className="text-sm font-medium text-text-primary mb-3">Photo Verification</h3>
        <p className="text-sm text-text-secondary mb-4">
          Take a photo of the polling station entrance sign to help verify your location.
        </p>
        
        {hasImage ? (
          <div className="relative h-40 bg-surface-secondary rounded-lg overflow-hidden">
            {/* Simulated image placeholder */}
            <div className="absolute inset-0 bg-gradient-to-br from-primary-100 to-primary-200 flex items-center justify-center">
              <Icon name="Check" size={40} className="text-primary" />
            </div>
            <div className="absolute bottom-0 left-0 right-0 bg-black/50 text-white p-2 text-xs text-center">
              Station entrance photo captured
            </div>
            <button 
              className="absolute top-2 right-2 w-8 h-8 bg-surface rounded-full flex items-center justify-center hover:bg-border"
              onClick={() => setHasImage(false)}
            >
              <Icon name="X" size={16} className="text-text-secondary" />
            </button>
          </div>
        ) : (
          <Button
            variant="outline"
            fullWidth
            className="h-40"
            iconName="Camera"
            onClick={handleTakePhoto}
          >
            Tap to Take Photo
          </Button>
        )}
      </div>
      
      {/* Verification Action */}
      <Button
        variant="primary"
        fullWidth
        iconName="CheckCircle"
        onClick={handleVerify}
        disabled={isVerifying || (!latitude && !longitude && !stationCode && !hasImage)}
      >
        {isVerifying ? 'Verifying...' : 'Verify My Location'}
      </Button>
      
      {/* Help Text */}
      <div className="mt-4 text-xs text-text-secondary flex items-start">
        <Icon name="Info" size={14} className="mr-2 mt-0.5" />
        <p>
          Manual verification requires supervisor approval and may take longer to process. 
          Providing multiple verification methods (coordinates, code, and photo) increases success rate.
        </p>
      </div>
    </div>
  );
};

export default StationVerification;