// src/pages/document-upload-ocr-processing/index.jsx
import React, { useState, useEffect, useCallback } from 'react';
import { useNavigate } from 'react-router-dom';
import Header from 'components/ui/Header';
import Sidebar from 'components/ui/Sidebar';
import QuickActionPanel from 'components/ui/QuickActionPanel';
import StatusIndicator from 'components/ui/StatusIndicator';
import Icon from 'components/AppIcon';
import Button from 'components/ui/Button';

import CameraCapture from './components/CameraCapture';
import DocumentTypeSelector from './components/DocumentTypeSelector';
import OcrProcessingPanel from './components/OcrProcessingPanel';
import TranscriptionEditor from './components/TranscriptionEditor';
import DocumentGallery from './components/DocumentGallery';
import BatchUploadQueue from './components/BatchUploadQueue';
import SecurityIndicator from './components/SecurityIndicator';
import FormBuilder from './components/FormBuilder';

const DocumentUploadOcrProcessing = () => {
  const navigate = useNavigate();
  const [currentView, setCurrentView] = useState('capture'); // capture, gallery, batch
  const [selectedDocumentType, setSelectedDocumentType] = useState(null);
  const [capturedDocuments, setCapturedDocuments] = useState([]);
  const [processingQueue, setProcessingQueue] = useState([]);
  const [currentDocument, setCurrentDocument] = useState(null);
  const [isMobileView, setIsMobileView] = useState(false);
  const [uploadProgress, setUploadProgress] = useState({});
  const [processingErrors, setProcessingErrors] = useState({});
  const [retryAttempts, setRetryAttempts] = useState({});
  const [processingStats, setProcessingStats] = useState({
    totalProcessed: 0,
    successfulUploads: 0,
    failedProcessing: 0,
    averageConfidence: 0
  });
  const [securityStatus, setSecurityStatus] = useState({
    encryption: 'active',
    backup: 'synced',
    connection: 'secure'
  });

  // Check if mobile view
  useEffect(() => {
    const checkMobileView = () => {
      setIsMobileView(window.innerWidth < 1024);
    };
    
    checkMobileView();
    const handleResize = () => checkMobileView();
    window.addEventListener('resize', handleResize);
    
    return () => window.removeEventListener('resize', handleResize);
  }, []);

  // Update processing stats whenever documents change
  useEffect(() => {
    const stats = capturedDocuments.reduce(
      (acc, doc) => {
        if (doc.status === 'processed' || doc.status === 'uploaded') {
          acc.totalProcessed++;
          acc.averageConfidence += doc.confidence || 0;
        }
        if (doc.status === 'uploaded') {
          acc.successfulUploads++;
        }
        if (doc.status === 'error') {
          acc.failedProcessing++;
        }
        return acc;
      },
      { totalProcessed: 0, successfulUploads: 0, failedProcessing: 0, averageConfidence: 0 }
    );

    if (stats.totalProcessed > 0) {
      stats.averageConfidence = stats.averageConfidence / stats.totalProcessed;
    }

    setProcessingStats(stats);
  }, [capturedDocuments]);

  // Enhanced document type configurations with better OCR templates
  const documentTypes = [
    {
      id: 'incident-report',
      name: 'Incident Report',
      description: 'Electoral irregularities and violations',
      icon: 'AlertTriangle',
      color: 'error',
      ocrTemplate: 'incident_form',
      requiredFields: ['incident_type', 'location', 'time', 'description', 'reporter_name'],
      confidenceThreshold: 0.7
    },
    {
      id: 'voter-tally',
      name: 'Voter Tally Sheet',
      description: 'Official vote counting results',
      icon: 'Calculator',
      color: 'primary',
      ocrTemplate: 'tally_sheet',
      requiredFields: ['station_id', 'total_votes', 'candidates', 'timestamp'],
      confidenceThreshold: 0.85
    },
    {
      id: 'official-form',
      name: 'Official Form',
      description: 'Government electoral documents',
      icon: 'FileText',
      color: 'secondary',
      ocrTemplate: 'official_document',
      requiredFields: ['form_type', 'reference_number', 'date', 'issuing_authority'],
      confidenceThreshold: 0.8
    },
    {
      id: 'station-materials',
      name: 'Station Materials',
      description: 'Ballot boxes, equipment, signage',
      icon: 'Package',
      color: 'warning',
      ocrTemplate: 'materials_checklist',
      requiredFields: ['item_type', 'condition', 'serial_number', 'location'],
      confidenceThreshold: 0.75
    }
  ];

  const handleDocumentCapture = useCallback((photoData) => {
    const documentId = `doc_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`;
    
    const newDocument = {
      id: documentId,
      type: selectedDocumentType,
      captureData: photoData,
      timestamp: new Date().toISOString(),
      status: 'captured',
      ocrStatus: 'pending',
      confidence: null,
      extractedText: null,
      formFields: {},
      processingProgress: 0,
      processingStartTime: new Date().toISOString(),
      metadata: {
        ...photoData.metadata,
        captureType: photoData.type,
        documentTypeId: selectedDocumentType?.id
      }
    };
    
    setCapturedDocuments(prev => [newDocument, ...prev]);
    setCurrentDocument(newDocument);
    
    // Start OCR processing
    startOcrProcessing(newDocument);
  }, [selectedDocumentType]);

  const startOcrProcessing = async (document) => {
    const documentId = document.id;
    setProcessingQueue(prev => [...prev, documentId]);
    setProcessingErrors(prev => ({ ...prev, [documentId]: null }));
    
    try {
      // Update document status to processing
      setCapturedDocuments(prev => 
        prev.map(doc => 
          doc.id === documentId 
            ? { ...doc, status: 'processing', ocrStatus: 'Initializing OCR engine...' }
            : doc
        )
      );

      // Enhanced OCR processing simulation with realistic steps
      const steps = [
        { progress: 10, status: 'Loading OCR engine', delay: 500 },
        { progress: 25, status: 'Analyzing image quality and orientation', delay: 800 },
        { progress: 40, status: 'Detecting text regions and layout', delay: 1000 },
        { progress: 60, status: 'Extracting text content', delay: 1200 },
        { progress: 75, status: 'Applying document template matching', delay: 800 },
        { progress: 90, status: 'Validating extracted data', delay: 600 },
        { progress: 100, status: 'Processing complete', delay: 300 }
      ];
      
      for (const step of steps) {
        await new Promise(resolve => setTimeout(resolve, step.delay));
        
        setCapturedDocuments(prev => 
          prev.map(doc => 
            doc.id === documentId 
              ? { 
                  ...doc, 
                  processingProgress: step.progress, 
                  ocrStatus: step.status 
                }
              : doc
          )
        );
        
        // Check if processing was cancelled or document was removed
        const currentDoc = capturedDocuments.find(d => d.id === documentId);
        if (!currentDoc || !processingQueue.includes(documentId)) {
          throw new Error('Processing cancelled');
        }
      }
      
      // Simulate more realistic OCR results based on document type
      const baseConfidence = 0.75 + Math.random() * 0.2;
      const documentType = document.type;
      const adjustedConfidence = Math.min(0.98, baseConfidence + (documentType?.confidenceThreshold || 0.7) * 0.1);
      
      // Generate realistic extracted text based on document type
      const mockExtractedText = generateMockExtractedText(documentType);
      const mockFields = generateMockFormFields(documentType, document.metadata);
      
      setCapturedDocuments(prev => 
        prev.map(doc => 
          doc.id === documentId 
            ? {
                ...doc,
                ocrStatus: 'completed',
                extractedText: mockExtractedText,
                confidence: adjustedConfidence,
                formFields: mockFields,
                status: 'processed',
                processingEndTime: new Date().toISOString()
              }
            : doc
        )
      );
      
    } catch (error) {
      console.error('OCR processing error:', error);
      
      const errorMessage = error.message === 'Processing cancelled' ?'Processing was cancelled' :'OCR processing failed. This may be due to poor image quality or unsupported document format.';
      
      setProcessingErrors(prev => ({ ...prev, [documentId]: errorMessage }));
      
      setCapturedDocuments(prev => 
        prev.map(doc => 
          doc.id === documentId 
            ? { 
                ...doc, 
                ocrStatus: 'error', 
                status: 'error',
                processingEndTime: new Date().toISOString(),
                errorDetails: {
                  message: errorMessage,
                  timestamp: new Date().toISOString(),
                  retryable: error.message !== 'Processing cancelled'
                }
              }
            : doc
        )
      );
    } finally {
      setProcessingQueue(prev => prev.filter(id => id !== documentId));
    }
  };

  const generateMockExtractedText = (documentType) => {
    const templates = {
      'incident-report': `ELECTORAL INCIDENT REPORT\n\nReport ID: IR-${Date.now().toString().slice(-6)}\nDate: ${new Date().toLocaleDateString()}\nTime: ${new Date().toLocaleTimeString()}\nLocation: Polling Station 001-A\n\nIncident Type: Voter Intimidation\nDescription: Unauthorized personnel observed near voting area attempting to influence voter decisions.\n\nReporter: John Smith\nPosition: Election Observer\nContact: +1-555-0123\n\nWitnesses: Jane Doe, Bob Wilson\n\nAction Taken: Incident reported to election officials and security personnel notified.`,
      
      'voter-tally': `OFFICIAL VOTE TALLY SHEET\n\nPolling Station: PS-001-A\nConstituency: Central District\nDate: ${new Date().toLocaleDateString()}\n\nCandidate A: 1,247 votes\nCandidate B: 892 votes\nCandidate C: 456 votes\n\nTotal Valid Votes: 2,595\nInvalid Votes: 23\nTotal Ballots Cast: 2,618\n\nRegistered Voters: 3,200\nTurnout: 81.8%\n\nPresiding Officer: Mary Johnson\nSignature: [Signed]\nTimestamp: ${new Date().toLocaleString()}`,
      
      'official-form': `ELECTORAL COMMISSION FORM EC-104\n\nReference Number: EC-104-${Date.now().toString().slice(-6)}\nIssue Date: ${new Date().toLocaleDateString()}\nValid Until: ${new Date(Date.now() + 90*24*60*60*1000).toLocaleDateString()}\n\nDocument Type: Observer Accreditation\nIssuing Authority: National Electoral Commission\n\nObserver Details:\nName: Sarah Williams\nOrganization: Citizens Electoral Watch\nID Number: CEW-2024-157\n\nAuthorized Areas: All polling stations in District 5\nSpecial Permissions: Photography, Data Collection\n\nOfficial Seal: [SEALED]\nIssued By: Commissioner Janet Brown`,
      
      'station-materials': `POLLING STATION EQUIPMENT CHECKLIST\n\nStation ID: PS-001-A\nLocation: Central Community Hall\nDate: ${new Date().toLocaleDateString()}\n\nBallot Boxes:\n- Box #1: Serial BB-2024-001 - Good Condition\n- Box #2: Serial BB-2024-002 - Good Condition\n\nVoting Booths:\n- Booth A: VB-001 - Operational\n- Booth B: VB-002 - Operational\n- Booth C: VB-003 - Minor wear, functional\n\nSignage:\n- Directional signs: Complete\n- Candidate posters: Properly displayed\n- Information boards: Updated\n\nSecurity Seals:\n- Unused seals: 50 units\n- Applied seals: 2 units\n\nChecked by: Equipment Officer Mike Davis\nTime: ${new Date().toLocaleTimeString()}`
    };
    
    return templates[documentType?.id] || `Document content extracted but template not recognized.\n\nDocument appears to contain official electoral information.\nManual review recommended for proper categorization.\n\nExtracted on: ${new Date().toLocaleString()}`;
  };

  const generateMockFormFields = (documentType, metadata) => {
    const baseFields = {
      document_type: documentType?.name || 'Unknown',
      date: new Date().toLocaleDateString(),
      timestamp: new Date().toISOString(),
      extracted_by: 'OCR Engine v2.1',
      confidence_score: Math.random() * 0.3 + 0.7
    };
    
    const typeSpecificFields = {
      'incident-report': {
        incident_type: 'Voter Intimidation',
        location: 'Polling Station 001-A',
        reporter_name: 'John Smith',
        reference: `IR-${Date.now().toString().slice(-6)}`,
        severity: 'Medium'
      },
      'voter-tally': {
        station_id: 'PS-001-A',
        total_votes: '2,595',
        valid_votes: '2,595',
        invalid_votes: '23',
        turnout_percentage: '81.8%',
        reference: `TS-${Date.now().toString().slice(-6)}`
      },
      'official-form': {
        form_type: 'Observer Accreditation',
        reference_number: `EC-104-${Date.now().toString().slice(-6)}`,
        issuing_authority: 'National Electoral Commission',
        validity_period: '90 days',
        reference: `OF-${Date.now().toString().slice(-6)}`
      },
      'station-materials': {
        item_type: 'Equipment Checklist',
        condition: 'Good',
        station_id: 'PS-001-A',
        inspector: 'Mike Davis',
        reference: `SM-${Date.now().toString().slice(-6)}`
      }
    };
    
    return {
      ...baseFields,
      ...(typeSpecificFields[documentType?.id] || {})
    };
  };

  const handleDocumentTypeSelect = useCallback((type) => {
    setSelectedDocumentType(type);
  }, []);

  const handleTranscriptionUpdate = useCallback((documentId, updatedText, updatedFields) => {
    setCapturedDocuments(prev => 
      prev.map(doc => 
        doc.id === documentId 
          ? {
              ...doc,
              extractedText: updatedText,
              formFields: updatedFields,
              status: 'edited',
              lastModified: new Date().toISOString()
            }
          : doc
      )
    );
  }, []);

  const handleBatchUpload = useCallback((documents) => {
    documents.forEach(doc => {
      handleDocumentCapture(doc);
    });
  }, [handleDocumentCapture]);

  const handleSecureUpload = async (documentId) => {
    const document = capturedDocuments.find(doc => doc.id === documentId);
    if (!document) {
      console.error('Document not found for upload:', documentId);
      return;
    }
    
    try {
      setUploadProgress(prev => ({ ...prev, [documentId]: 0 }));
      
      // Update document status
      setCapturedDocuments(prev => 
        prev.map(doc => 
          doc.id === documentId 
            ? { ...doc, status: 'uploading' }
            : doc
        )
      );
      
      // Simulate secure upload with realistic progress and validation
      const uploadSteps = [
        { progress: 10, status: 'Validating document data', delay: 300 },
        { progress: 25, status: 'Encrypting file content', delay: 500 },
        { progress: 40, status: 'Establishing secure connection', delay: 400 },
        { progress: 60, status: 'Uploading to secure server', delay: 800 },
        { progress: 80, status: 'Verifying upload integrity', delay: 600 },
        { progress: 95, status: 'Generating backup copy', delay: 400 },
        { progress: 100, status: 'Upload complete', delay: 200 }
      ];
      
      for (const step of uploadSteps) {
        await new Promise(resolve => setTimeout(resolve, step.delay));
        setUploadProgress(prev => ({ ...prev, [documentId]: step.progress }));
      }
      
      setCapturedDocuments(prev => 
        prev.map(doc => 
          doc.id === documentId 
            ? { 
                ...doc, 
                status: 'uploaded', 
                uploadTimestamp: new Date().toISOString(),
                uploadDetails: {
                  server: 'secure-electoral-db-01',
                  backupCreated: true,
                  encryptionLevel: 'AES-256'
                }
              }
            : doc
        )
      );
      
      // Clean up upload progress
      setTimeout(() => {
        setUploadProgress(prev => {
          const { [documentId]: removed, ...rest } = prev;
          return rest;
        });
      }, 2000);
      
    } catch (error) {
      console.error('Upload error:', error);
      setCapturedDocuments(prev => 
        prev.map(doc => 
          doc.id === documentId 
            ? { 
                ...doc, 
                status: 'upload_error',
                errorDetails: {
                  message: 'Upload failed. Please check your connection and try again.',
                  timestamp: new Date().toISOString(),
                  retryable: true
                }
              }
            : doc
        )
      );
      
      setUploadProgress(prev => {
        const { [documentId]: removed, ...rest } = prev;
        return rest;
      });
    }
  };

  const handleRetryProcessing = useCallback(async (documentId, options = {}) => {
    const document = capturedDocuments.find(doc => doc.id === documentId);
    if (!document) return;
    
    const currentAttempts = retryAttempts[documentId] || 0;
    if (currentAttempts >= 3) {
      alert('Maximum retry attempts reached. Please try manual entry or recapture the document.');
      return;
    }
    
    setRetryAttempts(prev => ({ ...prev, [documentId]: currentAttempts + 1 }));
    
    // Reset document status for retry
    setCapturedDocuments(prev => 
      prev.map(doc => 
        doc.id === documentId 
          ? {
              ...doc,
              status: 'captured',
              ocrStatus: 'pending',
              confidence: null,
              extractedText: null,
              processingProgress: 0,
              errorDetails: null
            }
          : doc
      )
    );
    
    // Start processing again
    await startOcrProcessing(document);
  }, [capturedDocuments, retryAttempts]);

  const handleManualEntry = useCallback((documentId) => {
    const document = capturedDocuments.find(doc => doc.id === documentId);
    if (!document) return;
    
    // Set document to manual entry mode
    setCapturedDocuments(prev => 
      prev.map(doc => 
        doc.id === documentId 
          ? {
              ...doc,
              status: 'manual_entry',
              extractedText: '',
              formFields: generateMockFormFields(doc.type, doc.metadata),
              confidence: 1.0, // Manual entry has 100% confidence
              manualEntry: true
            }
          : doc
      )
    );
    
    setCurrentDocument(document);
  }, [capturedDocuments]);

  const handleBulkAction = useCallback((action, documentIds) => {
    switch (action) {
      case 'delete':
        setCapturedDocuments(prev => 
          prev.filter(doc => !documentIds.includes(doc.id))
        );
        // Clean up related states
        setUploadProgress(prev => {
          const newProgress = { ...prev };
          documentIds.forEach(id => delete newProgress[id]);
          return newProgress;
        });
        setProcessingErrors(prev => {
          const newErrors = { ...prev };
          documentIds.forEach(id => delete newErrors[id]);
          return newErrors;
        });
        setRetryAttempts(prev => {
          const newAttempts = { ...prev };
          documentIds.forEach(id => delete newAttempts[id]);
          return newAttempts;
        });
        break;
      
      case 'retry':
        documentIds.forEach(id => handleRetryProcessing(id));
        break;
        
      case 'upload':
        documentIds.forEach(id => handleSecureUpload(id));
        break;
        
      default:
        console.warn('Unknown bulk action:', action);
    }
  }, [handleRetryProcessing, handleSecureUpload]);

  const renderMobileView = () => {
    return (
      <div className="space-y-6">
        {/* Mobile Navigation Tabs */}
        <div className="flex bg-surface border border-border rounded-lg p-1">
          {[
            { id: 'capture', name: 'Capture', icon: 'Camera' },
            { id: 'gallery', name: 'Gallery', icon: 'Grid' },
            { id: 'batch', name: 'Batch', icon: 'Layers' }
          ].map((tab) => (
            <button
              key={tab.id}
              onClick={() => setCurrentView(tab.id)}
              className={`flex-1 flex items-center justify-center space-x-2 py-2 px-3 text-sm font-medium rounded-md transition-colors duration-150 ease-out ${
                currentView === tab.id
                  ? 'bg-primary text-white' :'text-text-secondary hover:text-text-primary hover:bg-surface-secondary'
              }`}
            >
              <Icon name={tab.icon} size={16} />
              <span>{tab.name}</span>
            </button>
          ))}
        </div>

        {/* Mobile Content */}
        {currentView === 'capture' && (
          <div className="space-y-6">
            <DocumentTypeSelector
              documentTypes={documentTypes}
              selectedType={selectedDocumentType}
              onTypeSelect={handleDocumentTypeSelect}
            />
            
            {selectedDocumentType && (
              <CameraCapture
                onPhotoCaptured={handleDocumentCapture}
                documentType={selectedDocumentType}
              />
            )}
            
            {currentDocument && (
              <OcrProcessingPanel
                document={currentDocument}
                isProcessing={processingQueue.includes(currentDocument.id)}
                onRetryProcessing={handleRetryProcessing}
                onManualEntry={handleManualEntry}
              />
            )}
            
            {currentDocument?.extractedText && (
              <TranscriptionEditor
                document={currentDocument}
                onUpdate={handleTranscriptionUpdate}
              />
            )}
          </div>
        )}

        {currentView === 'gallery' && (
          <DocumentGallery
            documents={capturedDocuments}
            onDocumentSelect={setCurrentDocument}
            onUpload={handleSecureUpload}
            uploadProgress={uploadProgress}
            onBulkAction={handleBulkAction}
          />
        )}

        {currentView === 'batch' && (
          <BatchUploadQueue
            onBatchUpload={handleBatchUpload}
            processingQueue={processingQueue}
          />
        )}
      </div>
    );
  };

  const renderDesktopView = () => {
    return (
      <div className="grid grid-cols-12 gap-6 h-full">
        {/* Left Panel - Camera and Controls */}
        <div className="col-span-5 space-y-6">
          <DocumentTypeSelector
            documentTypes={documentTypes}
            selectedType={selectedDocumentType}
            onTypeSelect={handleDocumentTypeSelect}
          />
          
          {selectedDocumentType && (
            <CameraCapture
              onPhotoCaptured={handleDocumentCapture}
              documentType={selectedDocumentType}
            />
          )}
          
          <DocumentGallery
            documents={capturedDocuments.slice(0, 6)} // Show recent 6
            onDocumentSelect={setCurrentDocument}
            onUpload={handleSecureUpload}
            uploadProgress={uploadProgress}
            onBulkAction={handleBulkAction}
            compact={true}
          />
        </div>

        {/* Right Panel - Processing and Results */}
        <div className="col-span-7 space-y-6">
          {currentDocument ? (
            <>
              <OcrProcessingPanel
                document={currentDocument}
                isProcessing={processingQueue.includes(currentDocument.id)}
                onRetryProcessing={handleRetryProcessing}
                onManualEntry={handleManualEntry}
              />
              
              {(currentDocument.extractedText || currentDocument.manualEntry) && (
                <TranscriptionEditor
                  document={currentDocument}
                  onUpdate={handleTranscriptionUpdate}
                />
              )}
              
              <FormBuilder
                document={currentDocument}
                documentType={selectedDocumentType}
              />
            </>
          ) : (
            <div className="card p-8 text-center">
              <Icon name="FileText" size={48} className="text-text-tertiary mx-auto mb-4" />
              <h3 className="text-lg font-semibold text-text-primary mb-2">
                Select Document Type to Begin
              </h3>
              <p className="text-text-secondary mb-4">
                Choose a document type and capture or upload a document to start OCR processing.
              </p>
              
              {capturedDocuments.length > 0 && (
                <div className="mt-6">
                  <h4 className="text-sm font-medium text-text-primary mb-2">
                    Recent Documents
                  </h4>
                  <div className="flex flex-wrap gap-2 justify-center">
                    {capturedDocuments.slice(0, 3).map(doc => (
                      <button
                        key={doc.id}
                        onClick={() => setCurrentDocument(doc)}
                        className="text-xs px-3 py-2 bg-primary-50 text-primary rounded-lg hover:bg-primary-100 transition-colors"
                      >
                        {doc.type?.name || 'Unknown'} - {new Date(doc.timestamp).toLocaleTimeString()}
                      </button>
                    ))}
                  </div>
                </div>
              )}
            </div>
          )}
        </div>
      </div>
    );
  };

  return (
    <div className="min-h-screen bg-background">
      <Header />
      <Sidebar />
      <QuickActionPanel />
      <StatusIndicator />

      {/* Main Content */}
      <main className="lg:ml-64 pt-16 pb-20 lg:pb-6">
        <div className="p-4 lg:p-6 max-w-7xl mx-auto">
          {/* Page Header */}
          <div className="mb-6">
            <div className="flex flex-col lg:flex-row lg:items-center lg:justify-between mb-4">
              <div>
                <h1 className="text-2xl lg:text-3xl font-bold text-text-primary mb-2">
                  Document Upload & OCR Processing
                </h1>
                <p className="text-text-secondary">
                  Securely capture, process, and manage electoral documents with AI-powered transcription
                </p>
              </div>
              
              <div className="mt-4 lg:mt-0 flex items-center space-x-4">
                <SecurityIndicator status={securityStatus} />
                
                <Button
                  variant="outline"
                  iconName="Settings"
                  onClick={() => console.log('Open settings')}
                  className="hidden lg:flex"
                >
                  Settings
                </Button>
              </div>
            </div>

            {/* Enhanced Stats Bar */}
            <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
              <div className="bg-surface border border-border rounded-lg p-4">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-xs text-text-secondary font-medium uppercase tracking-wide">
                      Captured Today
                    </p>
                    <p className="text-2xl font-bold text-text-primary">
                      {capturedDocuments.length}
                    </p>
                    <p className="text-xs text-text-secondary mt-1">
                      {capturedDocuments.filter(d => new Date(d.timestamp).toDateString() === new Date().toDateString()).length} today
                    </p>
                  </div>
                  <Icon name="Camera" size={20} className="text-primary" />
                </div>
              </div>
              
              <div className="bg-surface border border-border rounded-lg p-4">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-xs text-text-secondary font-medium uppercase tracking-wide">
                      Processing
                    </p>
                    <p className="text-2xl font-bold text-text-primary">
                      {processingQueue.length}
                    </p>
                    <p className="text-xs text-text-secondary mt-1">
                      {Object.keys(processingErrors).filter(id => processingErrors[id]).length} errors
                    </p>
                  </div>
                  <Icon name="Loader" size={20} className={`${processingQueue.length > 0 ? 'text-warning animate-spin' : 'text-text-tertiary'}`} />
                </div>
              </div>
              
              <div className="bg-surface border border-border rounded-lg p-4">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-xs text-text-secondary font-medium uppercase tracking-wide">
                      Uploaded
                    </p>
                    <p className="text-2xl font-bold text-text-primary">
                      {processingStats.successfulUploads}
                    </p>
                    <p className="text-xs text-text-secondary mt-1">
                      {capturedDocuments.filter(doc => doc.status === 'processed').length} ready
                    </p>
                  </div>
                  <Icon name="Upload" size={20} className="text-success" />
                </div>
              </div>
              
              <div className="bg-surface border border-border rounded-lg p-4">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-xs text-text-secondary font-medium uppercase tracking-wide">
                      Avg Confidence
                    </p>
                    <p className="text-2xl font-bold text-text-primary">
                      {processingStats.totalProcessed > 0 
                        ? Math.round(processingStats.averageConfidence * 100) + '%' :'0%'
                      }
                    </p>
                    <p className="text-xs text-text-secondary mt-1">
                      {processingStats.totalProcessed} processed
                    </p>
                  </div>
                  <Icon 
                    name="TrendingUp" 
                    size={20} 
                    className={processingStats.averageConfidence >= 0.8 ? 'text-success' : 
                              processingStats.averageConfidence >= 0.6 ? 'text-warning' : 'text-error'} 
                  />
                </div>
              </div>
            </div>
          </div>

          {/* Main Content Area */}
          <div className="min-h-[600px]">
            {isMobileView ? renderMobileView() : renderDesktopView()}
          </div>
        </div>
      </main>
    </div>
  );
};

export default DocumentUploadOcrProcessing;