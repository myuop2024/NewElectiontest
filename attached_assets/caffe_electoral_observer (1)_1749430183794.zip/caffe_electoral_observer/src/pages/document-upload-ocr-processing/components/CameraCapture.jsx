// src/pages/document-upload-ocr-processing/components/CameraCapture.jsx
import React, { useState, useRef, useEffect } from 'react';
import Icon from 'components/AppIcon';
import Button from 'components/ui/Button';

const CameraCapture = ({ onPhotoCaptured, documentType }) => {
  const [isCapturing, setIsCapturing] = useState(false);
  const [showCamera, setShowCamera] = useState(false);
  const [cameraError, setCameraError] = useState(null);
  const [lightingIndicator, setLightingIndicator] = useState('good');
  const [isOptimizing, setIsOptimizing] = useState(false);
  const [dragOver, setDragOver] = useState(false);
  const [supportedFormats, setSupportedFormats] = useState([]);
  const [imageQuality, setImageQuality] = useState(null);
  
  const fileInputRef = useRef(null);
  const videoRef = useRef(null);
  const canvasRef = useRef(null);
  const streamRef = useRef(null);

  // Check supported image formats and camera capabilities
  useEffect(() => {
    const checkSupport = async () => {
      const formats = ['image/jpeg', 'image/png', 'image/webp', 'image/heic', 'image/tiff'];
      const supported = [];
      
      for (const format of formats) {
        const canvas = document.createElement('canvas');
        canvas.width = 1;
        canvas.height = 1;
        try {
          canvas.toDataURL(format);
          supported.push(format);
        } catch (e) {
          // Format not supported
        }
      }
      
      setSupportedFormats(supported);
    };
    
    checkSupport();
  }, []);

  // Enhanced lighting and quality monitoring
  useEffect(() => {
    if (!showCamera || !videoRef.current) return;
    
    const checkImageQuality = () => {
      if (!videoRef.current || !canvasRef.current) return;
      
      const video = videoRef.current;
      const canvas = canvasRef.current;
      const context = canvas.getContext('2d');
      
      canvas.width = 320;
      canvas.height = 240;
      
      try {
        context.drawImage(video, 0, 0, 320, 240);
        const imageData = context.getImageData(0, 0, 320, 240);
        const data = imageData.data;
        
        let totalBrightness = 0;
        let totalContrast = 0;
        let sharpnessIndicator = 0;
        
        // Calculate brightness
        for (let i = 0; i < data.length; i += 4) {
          const brightness = (data[i] + data[i + 1] + data[i + 2]) / 3;
          totalBrightness += brightness;
        }
        
        const avgBrightness = totalBrightness / (data.length / 4);
        
        // Calculate basic contrast (simplified)
        for (let i = 0; i < data.length; i += 4) {
          const brightness = (data[i] + data[i + 1] + data[i + 2]) / 3;
          totalContrast += Math.abs(brightness - avgBrightness);
        }
        
        const avgContrast = totalContrast / (data.length / 4);
        
        // Simple sharpness detection using edge detection
        for (let y = 1; y < 239; y++) {
          for (let x = 1; x < 319; x++) {
            const idx = (y * 320 + x) * 4;
            const rightIdx = (y * 320 + x + 1) * 4;
            const bottomIdx = ((y + 1) * 320 + x) * 4;
            
            const current = (data[idx] + data[idx + 1] + data[idx + 2]) / 3;
            const right = (data[rightIdx] + data[rightIdx + 1] + data[rightIdx + 2]) / 3;
            const bottom = (data[bottomIdx] + data[bottomIdx + 1] + data[bottomIdx + 2]) / 3;
            
            sharpnessIndicator += Math.abs(current - right) + Math.abs(current - bottom);
          }
        }
        
        // Set lighting indicator
        if (avgBrightness < 60) {
          setLightingIndicator('poor');
        } else if (avgBrightness > 220) {
          setLightingIndicator('bright');
        } else {
          setLightingIndicator('good');
        }
        
        // Set quality indicator
        const qualityScore = {
          brightness: avgBrightness,
          contrast: avgContrast,
          sharpness: sharpnessIndicator / (318 * 238),
          overall: avgBrightness >= 60 && avgBrightness <= 220 && avgContrast > 20 ? 'good' : 'poor'
        };
        
        setImageQuality(qualityScore);
        
      } catch (error) {
        console.warn('Quality check failed:', error);
      }
    };
    
    const interval = setInterval(checkImageQuality, 1000);
    return () => clearInterval(interval);
  }, [showCamera]);

  const startCamera = async () => {
    try {
      setCameraError(null);
      setShowCamera(true);
      
      // Check if camera is available
      if (!navigator.mediaDevices || !navigator.mediaDevices.getUserMedia) {
        throw new Error('Camera not supported on this device');
      }
      
      // Try different camera configurations for better compatibility
      const constraints = [
        {
          video: {
            facingMode: 'environment',
            width: { ideal: 1920, min: 1280 },
            height: { ideal: 1080, min: 720 }
          }
        },
        {
          video: {
            facingMode: 'environment',
            width: { ideal: 1280 },
            height: { ideal: 720 }
          }
        },
        {
          video: {
            width: { ideal: 1280 },
            height: { ideal: 720 }
          }
        },
        { video: true } // Fallback
      ];
      
      let stream = null;
      
      for (const constraint of constraints) {
        try {
          stream = await navigator.mediaDevices.getUserMedia(constraint);
          break;
        } catch (e) {
          console.warn('Camera constraint failed:', e);
          continue;
        }
      }
      
      if (!stream) {
        throw new Error('Unable to access camera with any configuration');
      }
      
      streamRef.current = stream;
      if (videoRef.current) {
        videoRef.current.srcObject = stream;
      }
      
    } catch (error) {
      console.error('Camera access error:', error);
      let errorMessage = 'Camera access failed. Please try again or use file upload.';
      
      if (error.name === 'NotAllowedError' || error.name === 'PermissionDeniedError') {
        errorMessage = 'Camera permission denied. Please allow camera access and try again.';
      } else if (error.name === 'NotFoundError' || error.name === 'DevicesNotFoundError') {
        errorMessage = 'No camera found. Please ensure your device has a camera.';
      } else if (error.name === 'NotReadableError' || error.name === 'TrackStartError') {
        errorMessage = 'Camera is being used by another application. Please close other camera apps and try again.';
      } else if (error.name === 'OverconstrainedError' || error.name === 'ConstraintNotSatisfiedError') {
        errorMessage = 'Camera does not meet requirements. Trying with basic settings...';
      }
      
      setCameraError(errorMessage);
      setShowCamera(false);
    }
  };

  const stopCamera = () => {
    if (streamRef.current) {
      streamRef.current.getTracks().forEach(track => {
        track.stop();
      });
      streamRef.current = null;
    }
    setShowCamera(false);
    setLightingIndicator('good');
    setImageQuality(null);
  };

  const capturePhoto = async () => {
    if (!videoRef.current || !canvasRef.current) return;
    
    setIsCapturing(true);
    setIsOptimizing(true);
    
    try {
      const video = videoRef.current;
      const canvas = canvasRef.current;
      const context = canvas.getContext('2d');
      
      // Use actual video dimensions for better quality
      canvas.width = video.videoWidth || video.offsetWidth;
      canvas.height = video.videoHeight || video.offsetHeight;
      
      // Enhanced image capture with quality checks
      context.fillStyle = '#ffffff';
      context.fillRect(0, 0, canvas.width, canvas.height);
      context.drawImage(video, 0, 0, canvas.width, canvas.height);
      
      // Simulate AI optimization process
      await new Promise(resolve => setTimeout(resolve, 1500));
      
      // Try different quality settings for optimal file size
      const qualities = [0.95, 0.9, 0.85, 0.8];
      let bestBlob = null;
      let bestQuality = 0.9;
      
      for (const quality of qualities) {
        try {
          const blob = await new Promise(resolve => {
            canvas.toBlob(resolve, 'image/jpeg', quality);
          });
          
          if (blob && blob.size < 5 * 1024 * 1024) { // Less than 5MB
            bestBlob = blob;
            bestQuality = quality;
            break;
          }
        } catch (e) {
          console.warn('Failed to create blob with quality:', quality);
        }
      }
      
      if (!bestBlob) {
        // Fallback to basic blob creation
        bestBlob = await new Promise(resolve => {
          canvas.toBlob(resolve, 'image/jpeg', 0.8);
        });
      }
      
      const photoData = {
        blob: bestBlob,
        dataUrl: canvas.toDataURL('image/jpeg', bestQuality),
        timestamp: new Date().toISOString(),
        type: 'camera_capture',
        documentType: documentType?.id,
        metadata: {
          lighting: lightingIndicator,
          resolution: `${canvas.width}x${canvas.height}`,
          quality: imageQuality,
          optimized: true,
          fileSize: bestBlob?.size || 0,
          compressionQuality: bestQuality
        }
      };
      
      onPhotoCaptured?.(photoData);
      setIsCapturing(false);
      setIsOptimizing(false);
      stopCamera();
      
    } catch (error) {
      console.error('Photo capture error:', error);
      setCameraError('Failed to capture photo. Please try again.');
      setIsCapturing(false);
      setIsOptimizing(false);
    }
  };

  const validateFile = (file) => {
    const errors = [];
    
    // Check file type
    if (!file.type.startsWith('image/')) {
      errors.push('File must be an image');
    }
    
    // Check file size (max 10MB)
    if (file.size > 10 * 1024 * 1024) {
      errors.push('File size must be less than 10MB');
    }
    
    // Check if format is supported
    if (!supportedFormats.includes(file.type)) {
      errors.push(`Format ${file.type} may not be fully supported`);
    }
    
    return errors;
  };

  const handleFileUpload = async (file) => {
    const validationErrors = validateFile(file);
    
    if (validationErrors.length > 0) {
      setCameraError(validationErrors.join('. '));
      return;
    }
    
    setIsOptimizing(true);
    setCameraError(null);
    
    try {
      const reader = new FileReader();
      
      const photoData = await new Promise((resolve, reject) => {
        reader.onload = async (e) => {
          try {
            // Create image for processing
            const img = new Image();
            img.onload = async () => {
              try {
                const canvas = document.createElement('canvas');
                const context = canvas.getContext('2d');
                
                // Optimize image size while maintaining quality
                const maxWidth = 2048;
                const maxHeight = 2048;
                let { width, height } = img;
                
                if (width > maxWidth || height > maxHeight) {
                  const ratio = Math.min(maxWidth / width, maxHeight / height);
                  width *= ratio;
                  height *= ratio;
                }
                
                canvas.width = width;
                canvas.height = height;
                
                // Apply image enhancement
                context.fillStyle = '#ffffff';
                context.fillRect(0, 0, width, height);
                context.drawImage(img, 0, 0, width, height);
                
                // Create optimized blob
                canvas.toBlob((blob) => {
                  resolve({
                    blob: blob || file,
                    dataUrl: canvas.toDataURL('image/jpeg', 0.9),
                    timestamp: new Date().toISOString(),
                    type: 'file_upload',
                    documentType: documentType?.id,
                    metadata: {
                      fileName: file.name,
                      fileSize: blob?.size || file.size,
                      originalSize: file.size,
                      resolution: `${width}x${height}`,
                      originalResolution: `${img.naturalWidth}x${img.naturalHeight}`,
                      optimized: true,
                      mimeType: file.type
                    }
                  });
                }, 'image/jpeg', 0.9);
                
              } catch (error) {
                reject(error);
              }
            };
            
            img.onerror = () => reject(new Error('Invalid image file'));
            img.src = e.target?.result;
            
          } catch (error) {
            reject(error);
          }
        };
        
        reader.onerror = () => reject(new Error('Failed to read file'));
        reader.readAsDataURL(file);
      });
      
      // Simulate processing time
      await new Promise(resolve => setTimeout(resolve, 1000));
      
      onPhotoCaptured?.(photoData);
      
    } catch (error) {
      console.error('File upload error:', error);
      setCameraError(error.message || 'Failed to process file. Please try again.');
    } finally {
      setIsOptimizing(false);
    }
  };

  const handleDragOver = (e) => {
    e.preventDefault();
    e.stopPropagation();
    setDragOver(true);
  };

  const handleDragLeave = (e) => {
    e.preventDefault();
    e.stopPropagation();
    setDragOver(false);
  };

  const handleDrop = (e) => {
    e.preventDefault();
    e.stopPropagation();
    setDragOver(false);
    
    const files = Array.from(e.dataTransfer.files);
    const imageFile = files.find(file => file.type.startsWith('image/'));
    
    if (imageFile) {
      handleFileUpload(imageFile);
    } else {
      setCameraError('Please drop a valid image file.');
    }
  };

  const getLightingStatusColor = () => {
    switch (lightingIndicator) {
      case 'poor': return 'text-error';
      case 'bright': return 'text-warning';
      default: return 'text-success';
    }
  };

  const getLightingStatusText = () => {
    switch (lightingIndicator) {
      case 'poor': return 'Poor lighting - use flash or find better light';
      case 'bright': return 'Too bright - avoid direct light or glare';
      default: return 'Good lighting conditions';
    }
  };

  const getQualityIndicator = () => {
    if (!imageQuality) return null;
    
    return (
      <div className="absolute top-4 left-4 bg-black bg-opacity-50 text-white p-2 rounded-lg text-xs">
        <div className="flex items-center space-x-2 mb-1">
          <span>Quality:</span>
          <span className={imageQuality.overall === 'good' ? 'text-success' : 'text-warning'}>
            {imageQuality.overall === 'good' ? 'Good' : 'Poor'}
          </span>
        </div>
        <div className="text-xs opacity-75">
          Brightness: {Math.round(imageQuality.brightness)}
        </div>
      </div>
    );
  };

  if (isOptimizing) {
    return (
      <div className="card p-8">
        <div className="text-center">
          <div className="inline-flex items-center justify-center w-16 h-16 bg-primary-50 rounded-full mb-4">
            <Icon name="Loader" size={32} className="text-primary animate-spin" />
          </div>
          <h3 className="text-lg font-semibold text-text-primary mb-2">
            AI Optimization in Progress
          </h3>
          <p className="text-text-secondary mb-4">
            Enhancing image quality, adjusting exposure, and preparing for OCR...
          </p>
          <div className="w-full bg-surface-secondary rounded-full h-2">
            <div className="bg-primary h-2 rounded-full animate-pulse" style={{ width: '70%' }} />
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="space-y-4">
      {/* Document Type Info */}
      {documentType && (
        <div className="card p-4 bg-primary-50 border-primary-200">
          <div className="flex items-center space-x-3">
            <div className={`w-10 h-10 bg-${documentType.color} text-white rounded-lg flex items-center justify-center`}>
              <Icon name={documentType.icon} size={20} />
            </div>
            <div>
              <h3 className="font-semibold text-text-primary">{documentType.name}</h3>
              <p className="text-sm text-text-secondary">{documentType.description}</p>
            </div>
          </div>
        </div>
      )}

      {/* Camera Error */}
      {cameraError && (
        <div className="card p-4 bg-error-50 border-error-200">
          <div className="flex items-start space-x-3">
            <Icon name="AlertTriangle" size={20} className="text-error mt-0.5" />
            <div className="flex-1">
              <h4 className="font-medium text-error mb-1">Upload/Camera Error</h4>
              <p className="text-sm text-error-600">{cameraError}</p>
              <Button
                variant="outline"
                size="sm"
                className="mt-2 text-error border-error hover:bg-error-50"
                onClick={() => setCameraError(null)}
              >
                Dismiss
              </Button>
            </div>
          </div>
        </div>
      )}

      {/* Camera View */}
      {showCamera ? (
        <div className="card p-4">
          <div className="relative bg-black rounded-lg overflow-hidden mb-4">
            <video
              ref={videoRef}
              autoPlay
              playsInline
              muted
              className="w-full h-64 lg:h-80 object-cover"
              onLoadedMetadata={() => {
                // Video loaded successfully
              }}
            />
            
            {/* Camera overlay guides */}
            <div className="absolute inset-4 border-2 border-white border-dashed rounded-lg opacity-50 pointer-events-none" />
            <div className="absolute top-1/2 left-1/2 transform -translate-x-1/2 -translate-y-1/2 w-24 h-16 border-2 border-white rounded pointer-events-none" />
            
            {/* Quality indicator */}
            {getQualityIndicator()}
            
            {/* Lighting indicator */}
            <div className="absolute top-4 right-4 bg-black bg-opacity-50 text-white px-3 py-2 rounded-lg">
              <div className="flex items-center space-x-2">
                <div className={`w-2 h-2 rounded-full ${
                  lightingIndicator === 'good' ? 'bg-success' : 
                  lightingIndicator === 'poor' ? 'bg-error' : 'bg-warning'
                }`} />
                <span className="text-xs font-medium">
                  {lightingIndicator === 'good' ? 'Good Light' : 
                   lightingIndicator === 'poor' ? 'Poor Light' : 'Too Bright'}
                </span>
              </div>
            </div>
            
            {/* Instructions overlay */}
            <div className="absolute bottom-4 left-4 right-4">
              <div className="bg-black bg-opacity-50 text-white p-3 rounded-lg">
                <p className="text-sm font-medium mb-1">
                  Position document within the guides
                </p>
                <p className={`text-xs ${getLightingStatusColor()}`}>
                  {getLightingStatusText()}
                </p>
              </div>
            </div>
          </div>
          
          {/* Camera controls */}
          <div className="flex space-x-3">
            <Button
              variant="success"
              iconName="Camera"
              onClick={capturePhoto}
              disabled={isCapturing || (imageQuality?.overall === 'poor' && lightingIndicator === 'poor')}
              loading={isCapturing}
              className="flex-1"
            >
              {isCapturing ? 'Capturing...' : 'Capture Document'}
            </Button>
            
            <Button
              variant="outline"
              iconName="X"
              onClick={stopCamera}
              disabled={isCapturing}
            >
              Cancel
            </Button>
          </div>
        </div>
      ) : (
        /* Capture options */
        <div className="space-y-4">
          {/* Camera capture button */}
          <Button
            variant="primary"
            iconName="Camera"
            onClick={startCamera}
            className="w-full py-4 text-lg"
            disabled={!documentType}
          >
            <div className="text-center">
              <div className="font-semibold">Take Photo</div>
              <div className="text-sm opacity-75">Best for field photography</div>
            </div>
          </Button>
          
          {/* Drag and drop area */}
          <div
            className={`card p-8 border-2 border-dashed transition-colors duration-200 cursor-pointer ${
              dragOver
                ? 'border-primary bg-primary-50' :'border-border hover:border-primary-300 hover:bg-primary-50'
            }`}
            onDragOver={handleDragOver}
            onDragLeave={handleDragLeave}
            onDrop={handleDrop}
            onClick={() => fileInputRef.current?.click()}
          >
            <div className="text-center">
              <Icon name="Upload" size={32} className="text-text-tertiary mx-auto mb-4" />
              <h3 className="text-lg font-semibold text-text-primary mb-2">
                Upload Document
              </h3>
              <p className="text-text-secondary mb-4">
                Drag and drop an image file here, or click to browse
              </p>
              <p className="text-xs text-text-tertiary mb-4">
                Supported formats: JPEG, PNG, WebP{supportedFormats.includes('image/heic') ? ', HEIC' : ''}
                {supportedFormats.includes('image/tiff') ? ', TIFF' : ''} (Max 10MB)
              </p>
              <Button variant="outline" iconName="Folder" disabled={!documentType}>
                Browse Files
              </Button>
            </div>
          </div>
          
          {/* Hidden file input */}
          <input
            ref={fileInputRef}
            type="file"
            accept="image/*"
            onChange={(e) => {
              const file = e.target.files?.[0];
              if (file) {
                handleFileUpload(file);
                e.target.value = ''; // Reset input
              }
            }}
            className="hidden"
          />
        </div>
      )}

      {/* Hidden canvas for image processing */}
      <canvas ref={canvasRef} className="hidden" />

      {/* Guidelines */}
      {!showCamera && documentType && (
        <div className="card p-4">
          <h4 className="font-medium text-text-primary mb-3 flex items-center space-x-2">
            <Icon name="Info" size={16} className="text-primary" />
            <span>Photography Guidelines</span>
          </h4>
          <ul className="space-y-2 text-sm text-text-secondary">
            <li className="flex items-start space-x-2">
              <Icon name="Check" size={14} className="text-success mt-0.5" />
              <span>Ensure document is flat and fully visible in frame</span>
            </li>
            <li className="flex items-start space-x-2">
              <Icon name="Check" size={14} className="text-success mt-0.5" />
              <span>Use good lighting - avoid shadows and glare</span>
            </li>
            <li className="flex items-start space-x-2">
              <Icon name="Check" size={14} className="text-success mt-0.5" />
              <span>Hold camera steady and parallel to document</span>
            </li>
            <li className="flex items-start space-x-2">
              <Icon name="Check" size={14} className="text-success mt-0.5" />
              <span>Capture text clearly - zoom if necessary</span>
            </li>
            <li className="flex items-start space-x-2">
              <Icon name="Check" size={14} className="text-success mt-0.5" />
              <span>Supported formats: JPEG, PNG, WebP (up to 10MB)</span>
            </li>
          </ul>
        </div>
      )}
    </div>
  );
};

export default CameraCapture;