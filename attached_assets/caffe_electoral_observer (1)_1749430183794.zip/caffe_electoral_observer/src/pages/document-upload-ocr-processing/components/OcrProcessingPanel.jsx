// src/pages/document-upload-ocr-processing/components/OcrProcessingPanel.jsx
import React, { useState } from 'react';
import Icon from 'components/AppIcon';
import Button from 'components/ui/Button';

const OcrProcessingPanel = ({ document, isProcessing, onRetryProcessing, onManualEntry }) => {
  const [showAdvancedMetrics, setShowAdvancedMetrics] = useState(false);
  const [processingAttempts, setProcessingAttempts] = useState(1);

  if (!document) return null;

  const getConfidenceColor = (confidence) => {
    if (confidence >= 0.9) return 'text-success';
    if (confidence >= 0.7) return 'text-warning';
    return 'text-error';
  };

  const getConfidenceLabel = (confidence) => {
    if (confidence >= 0.9) return 'Excellent';
    if (confidence >= 0.7) return 'Good';
    if (confidence >= 0.5) return 'Fair';
    return 'Poor';
  };

  const getProcessingRecommendation = () => {
    if (!document.confidence) return null;
    
    if (document.confidence < 0.5) {
      return {
        level: 'error',
        title: 'Manual Review Required',
        message: 'Low confidence score suggests the document may need manual transcription.',
        actions: ['manual_entry', 'retry_with_enhancement']
      };
    } else if (document.confidence < 0.7) {
      return {
        level: 'warning',
        title: 'Review Recommended',
        message: 'Moderate confidence score. Please verify the extracted text for accuracy.',
        actions: ['review_text', 'retry_processing']
      };
    } else if (document.confidence < 0.9) {
      return {
        level: 'info',
        title: 'Good Results',
        message: 'Good confidence score. Minor verification may be needed.',
        actions: ['quick_review']
      };
    }
    
    return {
      level: 'success',
      title: 'Excellent Results',
      message: 'High confidence score indicates accurate text extraction.',
      actions: []
    };
  };

  const handleRetry = async () => {
    setProcessingAttempts(prev => prev + 1);
    onRetryProcessing?.(document.id, {
      attempt: processingAttempts + 1,
      enhancement: true,
      previousConfidence: document.confidence
    });
  };

  const handleManualEntry = () => {
    onManualEntry?.(document.id);
  };

  const formatProcessingTime = (startTime, endTime) => {
    if (!startTime || !endTime) return 'Unknown';
    const diff = new Date(endTime) - new Date(startTime);
    return `${(diff / 1000).toFixed(1)}s`;
  };

  const getTextRegionCount = (text) => {
    if (!text) return 0;
    // Simulate text region detection
    const lines = text.split('\n').filter(line => line.trim().length > 0);
    return Math.max(1, Math.floor(lines.length / 2) + Math.floor(Math.random() * 3));
  };

  const recommendation = getProcessingRecommendation();

  return (
    <div className="card p-6">
      <div className="flex items-center justify-between mb-4">
        <h3 className="text-lg font-semibold text-text-primary">
          OCR Processing
          {processingAttempts > 1 && (
            <span className="ml-2 text-sm font-normal text-text-secondary">
              (Attempt {processingAttempts})
            </span>
          )}
        </h3>
        
        {document.status && (
          <div className={`inline-flex items-center space-x-2 px-3 py-1 rounded-full text-sm font-medium ${
            document.status === 'processed' ? 'bg-success-50 text-success' :
            document.status === 'error'? 'bg-error-50 text-error' : 'bg-warning-50 text-warning'
          }`}>
            <div className={`w-2 h-2 rounded-full ${
              document.status === 'processed' ? 'bg-success' :
              document.status === 'error' ? 'bg-error' : 'bg-warning animate-pulse'
            }`} />
            <span className="capitalize">
              {document.status === 'processed' ? 'Complete' : 
               document.status === 'error' ? 'Failed' : 'Processing'}
            </span>
          </div>
        )}
      </div>

      {/* Processing Progress */}
      {isProcessing && (
        <div className="space-y-4 mb-6">
          <div className="flex items-center space-x-3">
            <Icon name="Loader" size={20} className="text-primary animate-spin" />
            <div className="flex-1">
              <p className="font-medium text-text-primary">
                {document.ocrStatus || 'Starting OCR processing...'}
              </p>
              <p className="text-sm text-text-secondary">
                {document.processingProgress < 50 
                  ? 'Analyzing image and detecting text regions...' :'Extracting and validating text content...'}
              </p>
            </div>
          </div>
          
          <div className="w-full bg-surface-secondary rounded-full h-3">
            <div 
              className="bg-primary h-3 rounded-full transition-all duration-500 ease-out relative overflow-hidden"
              style={{ width: `${document.processingProgress || 0}%` }}
            >
              <div className="absolute inset-0 bg-gradient-to-r from-transparent via-white to-transparent opacity-25 animate-pulse" />
            </div>
          </div>
          
          <div className="text-xs text-text-secondary text-center">
            {document.processingProgress || 0}% complete
          </div>
        </div>
      )}

      {/* Document Preview */}
      {document.captureData?.dataUrl && (
        <div className="mb-6">
          <div className="flex items-center justify-between mb-3">
            <h4 className="font-medium text-text-primary">Document Preview</h4>
            {document.metadata?.fileSize && (
              <span className="text-xs text-text-secondary">
                {(document.metadata.fileSize / 1024).toFixed(1)} KB
              </span>
            )}
          </div>
          <div className="relative bg-surface-secondary rounded-lg overflow-hidden">
            <img
              src={document.captureData.dataUrl}
              alt="Document preview"
              className="w-full h-48 object-cover"
              loading="lazy"
            />
            
            {/* Processing overlay */}
            {isProcessing && (
              <div className="absolute inset-0 bg-black bg-opacity-20 flex items-center justify-center">
                <div className="bg-white rounded-lg p-3 shadow-lg">
                  <Icon name="Eye" size={20} className="text-primary animate-pulse" />
                </div>
              </div>
            )}
            
            {/* Quality indicator */}
            {document.metadata?.quality && (
              <div className="absolute top-2 right-2 bg-black bg-opacity-60 text-white px-2 py-1 rounded text-xs">
                Quality: {document.metadata.quality.overall === 'good' ? 'Good' : 'Fair'}
              </div>
            )}
          </div>
        </div>
      )}

      {/* OCR Results */}
      {document.confidence !== null && !isProcessing && (
        <div className="space-y-4">
          <div className="flex items-center justify-between">
            <h4 className="font-medium text-text-primary">Extraction Results</h4>
            <div className="flex items-center space-x-3">
              <button
                onClick={() => setShowAdvancedMetrics(!showAdvancedMetrics)}
                className="text-xs text-text-secondary hover:text-text-primary transition-colors"
              >
                {showAdvancedMetrics ? 'Hide' : 'Show'} Details
              </button>
              <div className="flex items-center space-x-2">
                <span className="text-sm text-text-secondary">Confidence:</span>
                <span className={`text-sm font-medium ${getConfidenceColor(document.confidence)}`}>
                  {Math.round(document.confidence * 100)}% ({getConfidenceLabel(document.confidence)})
                </span>
              </div>
            </div>
          </div>
          
          {/* Confidence visualization */}
          <div className="relative w-full bg-surface-secondary rounded-full h-3">
            <div 
              className={`h-3 rounded-full transition-all duration-1000 ${
                document.confidence >= 0.9 ? 'bg-success' :
                document.confidence >= 0.7 ? 'bg-warning' : 'bg-error'
              }`}
              style={{ width: `${document.confidence * 100}%` }}
            />
            <div className="absolute inset-0 flex items-center justify-center">
              <span className="text-xs font-medium text-white drop-shadow">
                {Math.round(document.confidence * 100)}%
              </span>
            </div>
          </div>
          
          {/* Recommendation card */}
          {recommendation && (
            <div className={`p-4 rounded-lg border ${
              recommendation.level === 'error' ? 'bg-error-50 border-error-200' :
              recommendation.level === 'warning' ? 'bg-warning-50 border-warning-200' :
              recommendation.level === 'info'? 'bg-blue-50 border-blue-200' : 'bg-success-50 border-success-200'
            }`}>
              <div className="flex items-start space-x-3">
                <Icon 
                  name={
                    recommendation.level === 'error' ? 'AlertTriangle' :
                    recommendation.level === 'warning' ? 'AlertCircle' :
                    recommendation.level === 'info' ? 'Info' : 'CheckCircle'
                  } 
                  size={20} 
                  className={`mt-0.5 ${
                    recommendation.level === 'error' ? 'text-error' :
                    recommendation.level === 'warning' ? 'text-warning' :
                    recommendation.level === 'info'? 'text-blue-600' : 'text-success'
                  }`} 
                />
                <div className="flex-1">
                  <h5 className={`font-medium mb-1 ${
                    recommendation.level === 'error' ? 'text-error-700' :
                    recommendation.level === 'warning' ? 'text-warning-700' :
                    recommendation.level === 'info'? 'text-blue-700' : 'text-success-700'
                  }`}>
                    {recommendation.title}
                  </h5>
                  <p className={`text-sm mb-3 ${
                    recommendation.level === 'error' ? 'text-error-600' :
                    recommendation.level === 'warning' ? 'text-warning-600' :
                    recommendation.level === 'info'? 'text-blue-600' : 'text-success-600'
                  }`}>
                    {recommendation.message}
                  </p>
                  
                  {recommendation.actions.length > 0 && (
                    <div className="flex flex-wrap gap-2">
                      {recommendation.actions.includes('manual_entry') && (
                        <Button
                          variant="outline"
                          size="sm"
                          iconName="Edit"
                          onClick={handleManualEntry}
                        >
                          Manual Entry
                        </Button>
                      )}
                      {recommendation.actions.includes('retry_processing') && (
                        <Button
                          variant="outline"
                          size="sm"
                          iconName="RefreshCw"
                          onClick={handleRetry}
                        >
                          Retry OCR
                        </Button>
                      )}
                      {recommendation.actions.includes('retry_with_enhancement') && (
                        <Button
                          variant="outline"
                          size="sm"
                          iconName="Zap"
                          onClick={handleRetry}
                        >
                          Enhanced Retry
                        </Button>
                      )}
                    </div>
                  )}
                </div>
              </div>
            </div>
          )}
          
          {/* Processing metrics */}
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4 p-4 bg-surface-secondary rounded-lg">
            <div>
              <p className="text-xs text-text-secondary font-medium uppercase tracking-wide mb-1">
                Processing Time
              </p>
              <p className="text-sm text-text-primary font-medium">
                {isProcessing ? 'Processing...' : 
                 formatProcessingTime(document.processingStartTime, document.processingEndTime)}
              </p>
            </div>
            
            <div>
              <p className="text-xs text-text-secondary font-medium uppercase tracking-wide mb-1">
                Text Regions
              </p>
              <p className="text-sm text-text-primary font-medium">
                {isProcessing ? '...' : getTextRegionCount(document.extractedText)}
              </p>
            </div>
            
            <div>
              <p className="text-xs text-text-secondary font-medium uppercase tracking-wide mb-1">
                Template Match
              </p>
              <p className="text-sm text-text-primary font-medium">
                {isProcessing ? '...' : document.formFields?.document_type || 'Auto-detected'}
              </p>
            </div>
            
            <div>
              <p className="text-xs text-text-secondary font-medium uppercase tracking-wide mb-1">
                Enhancement
              </p>
              <p className="text-sm text-text-primary font-medium">
                {document.captureData?.metadata?.optimized ? 'Applied' : 'None'}
              </p>
            </div>
          </div>
          
          {/* Advanced metrics */}
          {showAdvancedMetrics && (
            <div className="space-y-3 p-4 bg-surface border border-border rounded-lg">
              <h5 className="font-medium text-text-primary text-sm">Advanced Metrics</h5>
              
              <div className="grid grid-cols-2 md:grid-cols-3 gap-4 text-sm">
                <div>
                  <span className="text-text-secondary">Resolution:</span>
                  <span className="ml-2 font-medium text-text-primary">
                    {document.metadata?.resolution || 'Unknown'}
                  </span>
                </div>
                
                <div>
                  <span className="text-text-secondary">File Size:</span>
                  <span className="ml-2 font-medium text-text-primary">
                    {document.metadata?.fileSize ? 
                     `${(document.metadata.fileSize / 1024).toFixed(1)} KB` : 'Unknown'}
                  </span>
                </div>
                
                <div>
                  <span className="text-text-secondary">Format:</span>
                  <span className="ml-2 font-medium text-text-primary">
                    {document.metadata?.mimeType?.split('/')[1]?.toUpperCase() || 'JPEG'}
                  </span>
                </div>
                
                <div>
                  <span className="text-text-secondary">Lighting:</span>
                  <span className={`ml-2 font-medium ${
                    document.metadata?.lighting === 'good' ? 'text-success' :
                    document.metadata?.lighting === 'poor' ? 'text-error' : 'text-warning'
                  }`}>
                    {document.metadata?.lighting || 'Unknown'}
                  </span>
                </div>
                
                <div>
                  <span className="text-text-secondary">Attempts:</span>
                  <span className="ml-2 font-medium text-text-primary">
                    {processingAttempts}
                  </span>
                </div>
                
                {document.metadata?.quality && (
                  <div>
                    <span className="text-text-secondary">Quality:</span>
                    <span className={`ml-2 font-medium ${
                      document.metadata.quality.overall === 'good' ? 'text-success' : 'text-warning'
                    }`}>
                      {document.metadata.quality.overall}
                    </span>
                  </div>
                )}
              </div>
            </div>
          )}
        </div>
      )}

      {/* Error state */}
      {document.status === 'error' && (
        <div className="p-4 bg-error-50 border border-error-200 rounded-lg">
          <div className="flex items-start space-x-3">
            <Icon name="AlertTriangle" size={20} className="text-error" />
            <div className="flex-1">
              <h4 className="font-medium text-error mb-1">Processing Failed</h4>
              <p className="text-sm text-error-600 mb-3">
                OCR processing encountered an error. This may be due to poor image quality, 
                unsupported document format, or insufficient lighting conditions.
              </p>
              
              <div className="space-y-2">
                <div className="text-xs text-error-600">
                  <strong>Common solutions:</strong>
                  <ul className="list-disc list-inside mt-1 space-y-1">
                    <li>Ensure document is well-lit and clearly visible</li>
                    <li>Check that text is not blurry or distorted</li>
                    <li>Verify the document is fully within the frame</li>
                    <li>Try capturing from a different angle</li>
                  </ul>
                </div>
                
                <div className="flex flex-wrap gap-2 mt-3">
                  <Button
                    variant="outline"
                    size="sm"
                    iconName="RefreshCw"
                    onClick={handleRetry}
                    className="text-error border-error hover:bg-error-50"
                  >
                    Retry Processing
                  </Button>
                  
                  <Button
                    variant="outline"
                    size="sm"
                    iconName="Edit"
                    onClick={handleManualEntry}
                    className="text-error border-error hover:bg-error-50"
                  >
                    Manual Entry
                  </Button>
                </div>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* No data state */}
      {!document.extractedText && !isProcessing && document.status !== 'error' && (
        <div className="text-center py-8">
          <Icon name="FileText" size={48} className="text-text-tertiary mx-auto mb-4" />
          <h4 className="font-medium text-text-primary mb-2">
            Waiting for Processing
          </h4>
          <p className="text-text-secondary">
            Document will be processed automatically after capture.
          </p>
        </div>
      )}
    </div>
  );
};

export default OcrProcessingPanel;