// src/pages/document-upload-ocr-processing/components/DocumentGallery.jsx
import React, { useState, useMemo } from 'react';
import Icon from 'components/AppIcon';
import Button from 'components/ui/Button';

const DocumentGallery = ({ documents, onDocumentSelect, onUpload, uploadProgress, compact = false, onBulkAction }) => {
  const [selectedDocuments, setSelectedDocuments] = useState([]);
  const [sortBy, setSortBy] = useState('timestamp'); // timestamp, type, status, confidence
  const [filterBy, setFilterBy] = useState('all'); // all, processed, uploaded, error, pending
  const [searchTerm, setSearchTerm] = useState('');
  const [viewMode, setViewMode] = useState('grid'); // grid, list
  const [showPreview, setShowPreview] = useState(null);

  const getStatusColor = (status) => {
    switch (status) {
      case 'uploaded': return 'text-success';
      case 'processed': return 'text-primary';
      case 'error': return 'text-error';
      case 'captured': return 'text-warning';
      case 'processing': return 'text-blue-600';
      default: return 'text-text-secondary';
    }
  };

  const getStatusIcon = (status) => {
    switch (status) {
      case 'uploaded': return 'CheckCircle';
      case 'processed': return 'Eye';
      case 'error': return 'AlertTriangle';
      case 'captured': return 'Camera';
      case 'processing': return 'Loader';
      default: return 'FileText';
    }
  };

  const getStatusBadge = (status) => {
    const statusConfig = {
      uploaded: { bg: 'bg-success-50', text: 'text-success', label: 'Uploaded' },
      processed: { bg: 'bg-primary-50', text: 'text-primary', label: 'Processed' },
      error: { bg: 'bg-error-50', text: 'text-error', label: 'Error' },
      captured: { bg: 'bg-warning-50', text: 'text-warning', label: 'Captured' },
      processing: { bg: 'bg-blue-50', text: 'text-blue-600', label: 'Processing' },
      pending: { bg: 'bg-gray-50', text: 'text-gray-600', label: 'Pending' }
    };
    
    const config = statusConfig[status] || statusConfig.pending;
    
    return (
      <span className={`inline-flex items-center px-2 py-1 rounded-full text-xs font-medium ${config.bg} ${config.text}`}>
        <Icon 
          name={getStatusIcon(status)} 
          size={12} 
          className={`mr-1 ${status === 'processing' ? 'animate-spin' : ''}`} 
        />
        {config.label}
      </span>
    );
  };

  const filteredAndSortedDocuments = useMemo(() => {
    let filtered = documents || [];
    
    // Apply search filter
    if (searchTerm) {
      const searchLower = searchTerm.toLowerCase();
      filtered = filtered.filter(doc => 
        doc.extractedText?.toLowerCase().includes(searchLower) ||
        doc.formFields?.reference?.toLowerCase().includes(searchLower) ||
        doc.formFields?.station_id?.toLowerCase().includes(searchLower) ||
        doc.type?.name?.toLowerCase().includes(searchLower) ||
        doc.metadata?.fileName?.toLowerCase().includes(searchLower)
      );
    }
    
    // Apply status filter
    if (filterBy !== 'all') {
      filtered = filtered.filter(doc => doc.status === filterBy);
    }
    
    // Apply sorting
    filtered.sort((a, b) => {
      switch (sortBy) {
        case 'timestamp':
          return new Date(b.timestamp) - new Date(a.timestamp);
        case 'type':
          return (a.type?.name || '').localeCompare(b.type?.name || '');
        case 'status':
          return (a.status || '').localeCompare(b.status || '');
        case 'confidence':
          return (b.confidence || 0) - (a.confidence || 0);
        default:
          return 0;
      }
    });
    
    return filtered;
  }, [documents, searchTerm, filterBy, sortBy]);

  const handleSelectDocument = (documentId) => {
    setSelectedDocuments(prev => {
      const newSelection = prev.includes(documentId)
        ? prev.filter(id => id !== documentId)
        : [...prev, documentId];
      return newSelection;
    });
  };

  const handleSelectAll = () => {
    const allIds = filteredAndSortedDocuments.map(doc => doc.id);
    setSelectedDocuments(prev => 
      prev.length === allIds.length ? [] : allIds
    );
  };

  const handleBulkUpload = async () => {
    if (selectedDocuments.length === 0) return;
    
    try {
      for (const docId of selectedDocuments) {
        await onUpload?.(docId);
      }
      setSelectedDocuments([]);
    } catch (error) {
      console.error('Bulk upload failed:', error);
    }
  };

  const handleBulkDelete = () => {
    if (selectedDocuments.length === 0) return;
    
    if (window.confirm(`Delete ${selectedDocuments.length} selected documents?`)) {
      onBulkAction?.('delete', selectedDocuments);
      setSelectedDocuments([]);
    }
  };

  const handlePreviewDocument = (document) => {
    setShowPreview(document);
  };

  const formatFileSize = (bytes) => {
    if (!bytes) return 'Unknown';
    if (bytes === 0) return '0 Bytes';
    const k = 1024;
    const sizes = ['Bytes', 'KB', 'MB', 'GB'];
    const i = Math.floor(Math.log(bytes) / Math.log(k));
    return parseFloat((bytes / Math.pow(k, i)).toFixed(2)) + ' ' + sizes[i];
  };

  const formatDate = (dateString) => {
    try {
      const date = new Date(dateString);
      return date.toLocaleDateString() + ' ' + date.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
    } catch {
      return 'Invalid date';
    }
  };

  const getDocumentStats = () => {
    const docs = filteredAndSortedDocuments;
    return {
      total: docs.length,
      uploaded: docs.filter(d => d.status === 'uploaded').length,
      processed: docs.filter(d => d.status === 'processed').length,
      errors: docs.filter(d => d.status === 'error').length,
      avgConfidence: docs.length > 0 
        ? docs.reduce((acc, doc) => acc + (doc.confidence || 0), 0) / docs.length 
        : 0
    };
  };

  const renderGridView = () => {
    const filteredDocs = filteredAndSortedDocuments;
    
    return (
      <div className={`grid gap-4 ${
        compact 
          ? 'grid-cols-2 md:grid-cols-3' :'grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4'
      }`}>
        {filteredDocs.map((document) => (
          <div
            key={document.id}
            className={`card p-4 cursor-pointer transition-all duration-200 hover:shadow-md group ${
              selectedDocuments.includes(document.id) 
                ? 'ring-2 ring-primary border-primary bg-primary-50' :'border-border hover:border-primary-300'
            }`}
            onClick={() => onDocumentSelect?.(document)}
          >
            {/* Document preview */}
            <div className="relative mb-3">
              <div className={`aspect-video bg-surface-secondary rounded-lg overflow-hidden ${
                compact ? 'h-20' : 'h-32'
              }`}>
                {document.captureData?.dataUrl ? (
                  <img
                    src={document.captureData.dataUrl}
                    alt="Document"
                    className="w-full h-full object-cover transition-transform duration-200 group-hover:scale-105"
                    loading="lazy"
                  />
                ) : (
                  <div className="w-full h-full flex items-center justify-center">
                    <Icon name="FileText" size={24} className="text-text-tertiary" />
                  </div>
                )}
              </div>
              
              {/* Status indicator */}
              <div className="absolute top-2 right-2">
                {getStatusBadge(document.status)}
              </div>
              
              {/* Confidence score */}
              {document.confidence !== null && (
                <div className={`absolute bottom-2 right-2 px-2 py-1 rounded text-xs font-medium bg-black bg-opacity-60 text-white`}>
                  {Math.round(document.confidence * 100)}%
                </div>
              )}
              
              {/* Selection checkbox */}
              {!compact && (
                <div className="absolute top-2 left-2 opacity-0 group-hover:opacity-100 transition-opacity">
                  <input
                    type="checkbox"
                    checked={selectedDocuments.includes(document.id)}
                    onChange={(e) => {
                      e.stopPropagation();
                      handleSelectDocument(document.id);
                    }}
                    className="w-4 h-4 text-primary bg-white border-border rounded focus:ring-primary shadow-sm"
                  />
                </div>
              )}
              
              {/* Preview button */}
              <button
                onClick={(e) => {
                  e.stopPropagation();
                  handlePreviewDocument(document);
                }}
                className="absolute inset-0 bg-black bg-opacity-0 hover:bg-opacity-20 transition-all duration-200 flex items-center justify-center opacity-0 group-hover:opacity-100"
              >
                <Icon name="Eye" size={20} className="text-white" />
              </button>
              
              {/* Upload progress */}
              {uploadProgress[document.id] !== undefined && (
                <div className="absolute bottom-0 left-0 right-0 h-1 bg-black bg-opacity-20">
                  <div 
                    className="h-full bg-primary transition-all duration-300"
                    style={{ width: `${uploadProgress[document.id]}%` }}
                  />
                </div>
              )}
            </div>
            
            {/* Document info */}
            <div className="space-y-2">
              <div className="flex items-start justify-between">
                <h4 className={`font-medium text-text-primary truncate pr-2 ${
                  compact ? 'text-sm' : 'text-base'
                }`}>
                  {document.type?.name || 'Unknown Type'}
                </h4>
              </div>
              
              <p className={`text-text-secondary truncate ${
                compact ? 'text-xs' : 'text-sm'
              }`}>
                {document.formFields?.reference || 
                 document.formFields?.station_id || 
                 document.metadata?.fileName || 
                 'No reference'}
              </p>
              
              <div className="flex items-center justify-between">
                <span className={`text-text-tertiary ${
                  compact ? 'text-xs' : 'text-xs'
                }`}>
                  {formatDate(document.timestamp)}
                </span>
                
                {document.status === 'processed' && !uploadProgress[document.id] && (
                  <Button
                    variant="outline"
                    size="sm"
                    iconName="Upload"
                    onClick={(e) => {
                      e.stopPropagation();
                      onUpload?.(document.id);
                    }}
                    className="text-xs py-1 px-2 opacity-0 group-hover:opacity-100 transition-opacity"
                  >
                    Upload
                  </Button>
                )}
              </div>
              
              {/* File size */}
              {document.metadata?.fileSize && (
                <div className="text-xs text-text-tertiary">
                  {formatFileSize(document.metadata.fileSize)}
                </div>
              )}
            </div>
          </div>
        ))}
      </div>
    );
  };

  const renderListView = () => {
    const filteredDocs = filteredAndSortedDocuments;
    
    return (
      <div className="space-y-2">
        {filteredDocs.map((document) => (
          <div
            key={document.id}
            className={`card p-4 cursor-pointer transition-all duration-200 hover:shadow-sm group ${
              selectedDocuments.includes(document.id) 
                ? 'ring-2 ring-primary border-primary bg-primary-50' :'border-border hover:border-primary-300'
            }`}
            onClick={() => onDocumentSelect?.(document)}
          >
            <div className="flex items-center space-x-4">
              {/* Selection checkbox */}
              <input
                type="checkbox"
                checked={selectedDocuments.includes(document.id)}
                onChange={(e) => {
                  e.stopPropagation();
                  handleSelectDocument(document.id);
                }}
                className="w-4 h-4 text-primary bg-white border-border rounded focus:ring-primary"
              />
              
              {/* Document thumbnail */}
              <div className="w-16 h-12 bg-surface-secondary rounded overflow-hidden flex-shrink-0 relative group">
                {document.captureData?.dataUrl ? (
                  <img
                    src={document.captureData.dataUrl}
                    alt="Document"
                    className="w-full h-full object-cover"
                    loading="lazy"
                  />
                ) : (
                  <div className="w-full h-full flex items-center justify-center">
                    <Icon name="FileText" size={16} className="text-text-tertiary" />
                  </div>
                )}
                
                <button
                  onClick={(e) => {
                    e.stopPropagation();
                    handlePreviewDocument(document);
                  }}
                  className="absolute inset-0 bg-black bg-opacity-0 hover:bg-opacity-30 transition-all duration-200 flex items-center justify-center opacity-0 group-hover:opacity-100"
                >
                  <Icon name="Eye" size={14} className="text-white" />
                </button>
              </div>
              
              {/* Document details */}
              <div className="flex-1 min-w-0">
                <div className="flex items-center justify-between mb-1">
                  <h4 className="font-medium text-text-primary truncate">
                    {document.type?.name || 'Unknown Type'}
                  </h4>
                  <div className="flex items-center space-x-2">
                    {document.confidence !== null && (
                      <span className={`text-xs px-2 py-1 rounded-full ${
                        document.confidence >= 0.9 ? 'bg-success-50 text-success' :
                        document.confidence >= 0.7 ? 'bg-warning-50 text-warning' : 'bg-error-50 text-error'
                      }`}>
                        {Math.round(document.confidence * 100)}%
                      </span>
                    )}
                    {getStatusBadge(document.status)}
                  </div>
                </div>
                
                <div className="flex items-center justify-between">
                  <div className="flex items-center space-x-4 text-sm text-text-secondary">
                    <span className="truncate">
                      {document.formFields?.reference || 
                       document.formFields?.station_id || 
                       document.metadata?.fileName || 
                       'No reference'}
                    </span>
                    <span>{formatDate(document.timestamp)}</span>
                    {document.metadata?.fileSize && (
                      <span>{formatFileSize(document.metadata.fileSize)}</span>
                    )}
                  </div>
                  
                  {document.status === 'processed' && !uploadProgress[document.id] && (
                    <Button
                      variant="outline"
                      size="sm"
                      iconName="Upload"
                      onClick={(e) => {
                        e.stopPropagation();
                        onUpload?.(document.id);
                      }}
                    >
                      Upload
                    </Button>
                  )}
                </div>
              </div>
            </div>
            
            {/* Upload progress */}
            {uploadProgress[document.id] !== undefined && (
              <div className="mt-3 w-full h-1 bg-surface-secondary rounded">
                <div 
                  className="h-full bg-primary rounded transition-all duration-300"
                  style={{ width: `${uploadProgress[document.id]}%` }}
                />
              </div>
            )}
          </div>
        ))}
      </div>
    );
  };

  // Preview Modal
  const PreviewModal = ({ document, onClose }) => {
    if (!document) return null;
    
    return (
      <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-4">
        <div className="bg-white rounded-lg max-w-4xl max-h-full overflow-auto">
          <div className="p-4 border-b flex items-center justify-between">
            <h3 className="text-lg font-semibold">{document.type?.name || 'Document Preview'}</h3>
            <button onClick={onClose} className="text-text-secondary hover:text-text-primary">
              <Icon name="X" size={20} />
            </button>
          </div>
          
          <div className="p-4">
            {document.captureData?.dataUrl && (
              <img
                src={document.captureData.dataUrl}
                alt="Document preview"
                className="w-full h-auto max-h-96 object-contain"
              />
            )}
            
            <div className="mt-4 grid grid-cols-2 gap-4 text-sm">
              <div>
                <span className="font-medium">Status:</span>
                <span className="ml-2">{getStatusBadge(document.status)}</span>
              </div>
              
              {document.confidence !== null && (
                <div>
                  <span className="font-medium">Confidence:</span>
                  <span className="ml-2">{Math.round(document.confidence * 100)}%</span>
                </div>
              )}
              
              <div>
                <span className="font-medium">Captured:</span>
                <span className="ml-2">{formatDate(document.timestamp)}</span>
              </div>
              
              {document.metadata?.fileSize && (
                <div>
                  <span className="font-medium">Size:</span>
                  <span className="ml-2">{formatFileSize(document.metadata.fileSize)}</span>
                </div>
              )}
            </div>
          </div>
        </div>
      </div>
    );
  };

  if (!documents?.length) {
    return (
      <div className="card p-8 text-center">
        <Icon name="Folder" size={48} className="text-text-tertiary mx-auto mb-4" />
        <h3 className={`font-semibold text-text-primary mb-2 ${
          compact ? 'text-base' : 'text-lg'
        }`}>
          No Documents
        </h3>
        <p className={`text-text-secondary ${
          compact ? 'text-sm' : 'text-base'
        }`}>
          {compact ? 'Capture documents to see them here' : 'Captured documents will appear here for review and upload'}
        </p>
      </div>
    );
  }

  const stats = getDocumentStats();

  return (
    <>
      <div className="card p-6">
        <div className="flex items-center justify-between mb-4">
          <h3 className={`font-semibold text-text-primary ${
            compact ? 'text-base' : 'text-lg'
          }`}>
            Document Gallery {!compact && `(${stats.total})`}
          </h3>
          
          {!compact && (
            <div className="flex items-center space-x-2">
              <button
                onClick={() => setViewMode('grid')}
                className={`p-2 rounded-md transition-colors ${
                  viewMode === 'grid' ?'bg-primary text-white' :'text-text-secondary hover:text-text-primary hover:bg-surface-secondary'
                }`}
              >
                <Icon name="Grid" size={16} />
              </button>
              <button
                onClick={() => setViewMode('list')}
                className={`p-2 rounded-md transition-colors ${
                  viewMode === 'list' ?'bg-primary text-white' :'text-text-secondary hover:text-text-primary hover:bg-surface-secondary'
                }`}
              >
                <Icon name="List" size={16} />
              </button>
            </div>
          )}
        </div>

        {/* Stats summary */}
        {!compact && stats.total > 0 && (
          <div className="grid grid-cols-4 gap-4 mb-4 p-3 bg-surface-secondary rounded-lg">
            <div className="text-center">
              <div className="text-lg font-semibold text-text-primary">{stats.uploaded}</div>
              <div className="text-xs text-success">Uploaded</div>
            </div>
            <div className="text-center">
              <div className="text-lg font-semibold text-text-primary">{stats.processed}</div>
              <div className="text-xs text-primary">Processed</div>
            </div>
            <div className="text-center">
              <div className="text-lg font-semibold text-text-primary">{stats.errors}</div>
              <div className="text-xs text-error">Errors</div>
            </div>
            <div className="text-center">
              <div className="text-lg font-semibold text-text-primary">{Math.round(stats.avgConfidence * 100)}%</div>
              <div className="text-xs text-text-secondary">Avg Confidence</div>
            </div>
          </div>
        )}

        {/* Controls */}
        {!compact && (
          <div className="space-y-4 mb-6">
            {/* Search and filters */}
            <div className="flex flex-col md:flex-row gap-4">
              <div className="flex-1">
                <div className="relative">
                  <Icon name="Search" size={16} className="absolute left-3 top-1/2 transform -translate-y-1/2 text-text-tertiary" />
                  <input
                    type="text"
                    placeholder="Search documents..."
                    value={searchTerm}
                    onChange={(e) => setSearchTerm(e.target.value)}
                    className="w-full pl-10 pr-4 py-2 border border-border rounded-lg focus:ring-2 focus:ring-primary focus:border-transparent"
                  />
                  {searchTerm && (
                    <button
                      onClick={() => setSearchTerm('')}
                      className="absolute right-3 top-1/2 transform -translate-y-1/2 text-text-tertiary hover:text-text-primary"
                    >
                      <Icon name="X" size={16} />
                    </button>
                  )}
                </div>
              </div>
              
              <div className="flex space-x-2">
                <select
                  value={filterBy}
                  onChange={(e) => setFilterBy(e.target.value)}
                  className="px-3 py-2 border border-border rounded-lg focus:ring-2 focus:ring-primary focus:border-transparent"
                >
                  <option value="all">All Status</option>
                  <option value="captured">Captured</option>
                  <option value="processing">Processing</option>
                  <option value="processed">Processed</option>
                  <option value="uploaded">Uploaded</option>
                  <option value="error">Error</option>
                </select>
                
                <select
                  value={sortBy}
                  onChange={(e) => setSortBy(e.target.value)}
                  className="px-3 py-2 border border-border rounded-lg focus:ring-2 focus:ring-primary focus:border-transparent"
                >
                  <option value="timestamp">Sort by Date</option>
                  <option value="type">Sort by Type</option>
                  <option value="status">Sort by Status</option>
                  <option value="confidence">Sort by Confidence</option>
                </select>
              </div>
            </div>
            
            {/* Bulk actions */}
            {selectedDocuments.length > 0 && (
              <div className="flex items-center justify-between p-3 bg-primary-50 border border-primary-200 rounded-lg">
                <span className="text-sm text-primary font-medium">
                  {selectedDocuments.length} document{selectedDocuments.length > 1 ? 's' : ''} selected
                </span>
                
                <div className="flex space-x-2">
                  <Button
                    variant="outline"
                    size="sm"
                    onClick={handleSelectAll}
                  >
                    {selectedDocuments.length === filteredAndSortedDocuments.length ? 'Deselect All' : 'Select All'}
                  </Button>
                  
                  <Button
                    variant="primary"
                    size="sm"
                    iconName="Upload"
                    onClick={handleBulkUpload}
                    disabled={selectedDocuments.every(id => {
                      const doc = documents.find(d => d.id === id);
                      return doc?.status !== 'processed';
                    })}
                  >
                    Bulk Upload
                  </Button>
                  
                  <Button
                    variant="outline"
                    size="sm"
                    iconName="Trash2"
                    onClick={handleBulkDelete}
                    className="text-error border-error hover:bg-error-50"
                  >
                    Delete
                  </Button>
                </div>
              </div>
            )}
          </div>
        )}

        {/* Document grid/list */}
        {filteredAndSortedDocuments.length === 0 ? (
          <div className="text-center py-8">
            <Icon name="Search" size={48} className="text-text-tertiary mx-auto mb-4" />
            <h4 className="font-medium text-text-primary mb-2">
              No documents found
            </h4>
            <p className="text-text-secondary">
              Try adjusting your search or filter criteria.
            </p>
            {(searchTerm || filterBy !== 'all') && (
              <Button
                variant="outline"
                size="sm"
                onClick={() => {
                  setSearchTerm('');
                  setFilterBy('all');
                }}
                className="mt-3"
              >
                Clear filters
              </Button>
            )}
          </div>
        ) : (
          viewMode === 'grid' ? renderGridView() : renderListView()
        )}
      </div>
      
      {/* Preview Modal */}
      {showPreview && (
        <PreviewModal 
          document={showPreview} 
          onClose={() => setShowPreview(null)} 
        />
      )}
    </>
  );
};

export default DocumentGallery;