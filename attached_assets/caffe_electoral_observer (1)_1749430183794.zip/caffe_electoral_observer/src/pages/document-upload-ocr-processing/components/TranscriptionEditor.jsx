// src/pages/document-upload-ocr-processing/components/TranscriptionEditor.jsx
import React, { useState, useEffect } from 'react';
import Icon from 'components/AppIcon';
import Button from 'components/ui/Button';
import Input from 'components/ui/Input';

const TranscriptionEditor = ({ document, onUpdate }) => {
  const [editedText, setEditedText] = useState('');
  const [editedFields, setEditedFields] = useState({});
  const [hasChanges, setHasChanges] = useState(false);
  const [uncertainAreas, setUncertainAreas] = useState([]);
  const [activeTab, setActiveTab] = useState('text'); // text, fields

  useEffect(() => {
    if (document?.extractedText) {
      setEditedText(document.extractedText);
    }
    if (document?.formFields) {
      setEditedFields({ ...document.formFields });
    }
    
    // Simulate uncertain areas (would come from OCR service)
    setUncertainAreas([
      { start: 45, end: 62, confidence: 0.6, suggestion: 'uncertain text' },
      { start: 120, end: 135, confidence: 0.4, suggestion: 'unclear word' }
    ]);
  }, [document]);

  const handleTextChange = (newText) => {
    setEditedText(newText);
    setHasChanges(true);
  };

  const handleFieldChange = (fieldName, value) => {
    setEditedFields(prev => ({
      ...prev,
      [fieldName]: value
    }));
    setHasChanges(true);
  };

  const handleSaveChanges = () => {
    onUpdate?.(document.id, editedText, editedFields);
    setHasChanges(false);
  };

  const handleResetChanges = () => {
    setEditedText(document?.extractedText || '');
    setEditedFields({ ...document?.formFields || {} });
    setHasChanges(false);
  };

  const highlightUncertainText = (text) => {
    if (!uncertainAreas.length) return text;
    
    let result = [];
    let lastIndex = 0;
    
    uncertainAreas.forEach((area, index) => {
      // Add text before uncertain area
      if (area.start > lastIndex) {
        result.push(
          <span key={`normal-${index}`}>
            {text.slice(lastIndex, area.start)}
          </span>
        );
      }
      
      // Add uncertain area with highlighting
      result.push(
        <span
          key={`uncertain-${index}`}
          className="bg-warning-100 text-warning-800 px-1 rounded relative cursor-help"
          title={`Confidence: ${Math.round(area.confidence * 100)}% - ${area.suggestion}`}
        >
          {text.slice(area.start, area.end)}
          <Icon 
            name="AlertTriangle" 
            size={12} 
            className="absolute -top-1 -right-1 text-warning-600" 
          />
        </span>
      );
      
      lastIndex = area.end;
    });
    
    // Add remaining text
    if (lastIndex < text.length) {
      result.push(
        <span key="final">
          {text.slice(lastIndex)}
        </span>
      );
    }
    
    return result;
  };

  const renderFieldEditor = () => {
    const fieldLabels = {
      document_type: 'Document Type',
      date: 'Date',
      station_id: 'Station ID',
      reference: 'Reference Number',
      incident_type: 'Incident Type',
      location: 'Location',
      time: 'Time',
      description: 'Description',
      total_votes: 'Total Votes',
      candidates: 'Candidates',
      form_type: 'Form Type',
      reference_number: 'Reference Number',
      item_type: 'Item Type',
      condition: 'Condition',
      serial_number: 'Serial Number'
    };

    return (
      <div className="space-y-4">
        {Object.entries(editedFields).map(([fieldName, value]) => (
          <div key={fieldName}>
            <label className="block text-sm font-medium text-text-primary mb-2">
              {fieldLabels[fieldName] || fieldName.replace('_', ' ').replace(/\b\w/g, l => l.toUpperCase())}
            </label>
            <Input
              value={value || ''}
              onChange={(e) => handleFieldChange(fieldName, e.target.value)}
              placeholder={`Enter ${fieldLabels[fieldName] || fieldName}`}
              className="w-full"
            />
          </div>
        ))}
        
        {/* Add new field */}
        <Button
          variant="outline"
          iconName="Plus"
          onClick={() => {
            const fieldName = prompt('Enter field name:');
            if (fieldName) {
              handleFieldChange(fieldName.toLowerCase().replace(/\s+/g, '_'), '');
            }
          }}
          className="w-full"
        >
          Add Custom Field
        </Button>
      </div>
    );
  };

  if (!document?.extractedText && !document?.formFields) {
    return (
      <div className="card p-8 text-center">
        <Icon name="FileText" size={48} className="text-text-tertiary mx-auto mb-4" />
        <h3 className="text-lg font-semibold text-text-primary mb-2">
          No Text Extracted
        </h3>
        <p className="text-text-secondary">
          Complete OCR processing to begin transcription editing.
        </p>
      </div>
    );
  }

  return (
    <div className="card p-6">
      <div className="flex items-center justify-between mb-4">
        <h3 className="text-lg font-semibold text-text-primary">
          Transcription Editor
        </h3>
        
        {hasChanges && (
          <div className="flex items-center space-x-2">
            <span className="text-sm text-warning-600 flex items-center space-x-1">
              <Icon name="Edit" size={14} />
              <span>Unsaved changes</span>
            </span>
          </div>
        )}
      </div>

      {/* Tab Navigation */}
      <div className="flex space-x-1 mb-6 bg-surface-secondary p-1 rounded-lg">
        <button
          onClick={() => setActiveTab('text')}
          className={`flex-1 py-2 px-4 text-sm font-medium rounded-md transition-colors duration-150 ease-out ${
            activeTab === 'text' ?'bg-white text-text-primary shadow-sm' :'text-text-secondary hover:text-text-primary'
          }`}
        >
          Raw Text
        </button>
        <button
          onClick={() => setActiveTab('fields')}
          className={`flex-1 py-2 px-4 text-sm font-medium rounded-md transition-colors duration-150 ease-out ${
            activeTab === 'fields' ?'bg-white text-text-primary shadow-sm' :'text-text-secondary hover:text-text-primary'
          }`}
        >
          Structured Fields
        </button>
      </div>

      {/* Content */}
      {activeTab === 'text' ? (
        <div className="space-y-4">
          {/* Uncertain areas info */}
          {uncertainAreas.length > 0 && (
            <div className="p-3 bg-warning-50 border border-warning-200 rounded-lg">
              <div className="flex items-start space-x-2">
                <Icon name="AlertTriangle" size={16} className="text-warning mt-0.5" />
                <div>
                  <p className="text-sm font-medium text-warning-700">
                    {uncertainAreas.length} uncertain text region{uncertainAreas.length > 1 ? 's' : ''} detected
                  </p>
                  <p className="text-xs text-warning-600 mt-1">
                    Highlighted areas require manual verification. Hover for suggestions.
                  </p>
                </div>
              </div>
            </div>
          )}
          
          {/* Text editor */}
          <div>
            <label className="block text-sm font-medium text-text-primary mb-2">
              Extracted Text
            </label>
            <div className="relative">
              <textarea
                value={editedText}
                onChange={(e) => handleTextChange(e.target.value)}
                className="w-full h-64 p-4 border border-border rounded-lg font-mono text-sm resize-none focus:ring-2 focus:ring-primary focus:border-transparent"
                placeholder="Extracted text will appear here..."
              />
              
              {/* Text overlay for highlighting uncertain areas */}
              <div className="absolute inset-0 p-4 pointer-events-none whitespace-pre-wrap font-mono text-sm text-transparent bg-transparent overflow-hidden">
                {highlightUncertainText(editedText)}
              </div>
            </div>
          </div>
        </div>
      ) : (
        renderFieldEditor()
      )}

      {/* Action buttons */}
      <div className="flex justify-between mt-6">
        <div className="flex space-x-2">
          <Button
            variant="outline"
            iconName="RotateCcw"
            onClick={handleResetChanges}
            disabled={!hasChanges}
          >
            Reset
          </Button>
        </div>
        
        <div className="flex space-x-2">
          <Button
            variant="outline"
            iconName="Copy"
            onClick={() => {
              navigator.clipboard.writeText(editedText);
              // Could show a toast notification here
            }}
          >
            Copy Text
          </Button>
          
          <Button
            variant="primary"
            iconName="Save"
            onClick={handleSaveChanges}
            disabled={!hasChanges}
          >
            Save Changes
          </Button>
        </div>
      </div>

      {/* Stats */}
      <div className="mt-4 pt-4 border-t border-border">
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4 text-center">
          <div>
            <p className="text-xs text-text-secondary font-medium uppercase tracking-wide">
              Characters
            </p>
            <p className="text-sm font-semibold text-text-primary">
              {editedText.length}
            </p>
          </div>
          
          <div>
            <p className="text-xs text-text-secondary font-medium uppercase tracking-wide">
              Words
            </p>
            <p className="text-sm font-semibold text-text-primary">
              {editedText.split(/\s+/).filter(word => word.length > 0).length}
            </p>
          </div>
          
          <div>
            <p className="text-xs text-text-secondary font-medium uppercase tracking-wide">
              Fields
            </p>
            <p className="text-sm font-semibold text-text-primary">
              {Object.keys(editedFields).length}
            </p>
          </div>
          
          <div>
            <p className="text-xs text-text-secondary font-medium uppercase tracking-wide">
              Uncertain
            </p>
            <p className="text-sm font-semibold text-text-primary">
              {uncertainAreas.length}
            </p>
          </div>
        </div>
      </div>
    </div>
  );
};

export default TranscriptionEditor;