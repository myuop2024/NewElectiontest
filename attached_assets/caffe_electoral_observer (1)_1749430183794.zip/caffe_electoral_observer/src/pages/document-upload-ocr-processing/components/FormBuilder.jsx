// src/pages/document-upload-ocr-processing/components/FormBuilder.jsx
import React, { useState, useEffect } from 'react';
import Icon from 'components/AppIcon';
import Button from 'components/ui/Button';
import Input from 'components/ui/Input';

const FormBuilder = ({ document, documentType }) => {
  const [formData, setFormData] = useState({});
  const [dynamicFields, setDynamicFields] = useState([]);
  const [validationErrors, setValidationErrors] = useState({});
  const [isFormValid, setIsFormValid] = useState(false);

  // Field type configurations
  const fieldTypes = {
    text: { icon: 'Type', label: 'Text Input' },
    number: { icon: 'Hash', label: 'Number' },
    date: { icon: 'Calendar', label: 'Date' },
    time: { icon: 'Clock', label: 'Time' },
    textarea: { icon: 'AlignLeft', label: 'Long Text' },
    select: { icon: 'List', label: 'Dropdown' },
    checkbox: { icon: 'CheckSquare', label: 'Checkbox' },
    radio: { icon: 'Circle', label: 'Radio Button' }
  };

  // Initialize form from document type and extracted data
  useEffect(() => {
    if (!documentType || !document) return;
    
    const fields = generateFieldsFromTemplate();
    setDynamicFields(fields);
    
    // Populate form with extracted data
    const initialFormData = {};
    fields.forEach(field => {
      if (document.formFields?.[field.name]) {
        initialFormData[field.name] = document.formFields[field.name];
      }
    });
    
    setFormData(initialFormData);
  }, [documentType, document]);

  // Validate form whenever data changes
  useEffect(() => {
    validateForm();
  }, [formData]);

  const generateFieldsFromTemplate = () => {
    if (!documentType) return [];
    
    const templateFields = {
      'incident-report': [
        { name: 'incident_type', label: 'Incident Type', type: 'select', required: true, options: ['Voter Intimidation', 'Equipment Failure', 'Procedural Violation', 'Violence', 'Other'] },
        { name: 'location', label: 'Location', type: 'text', required: true },
        { name: 'time', label: 'Time Occurred', type: 'time', required: true },
        { name: 'description', label: 'Description', type: 'textarea', required: true },
        { name: 'witnesses', label: 'Number of Witnesses', type: 'number', required: false },
        { name: 'severity', label: 'Severity Level', type: 'select', required: true, options: ['Low', 'Medium', 'High', 'Critical'] }
      ],
      'voter-tally': [
        { name: 'station_id', label: 'Station ID', type: 'text', required: true },
        { name: 'total_votes', label: 'Total Votes Cast', type: 'number', required: true },
        { name: 'registered_voters', label: 'Registered Voters', type: 'number', required: true },
        { name: 'invalid_votes', label: 'Invalid Votes', type: 'number', required: false },
        { name: 'candidate_a_votes', label: 'Candidate A Votes', type: 'number', required: true },
        { name: 'candidate_b_votes', label: 'Candidate B Votes', type: 'number', required: true },
        { name: 'verified_by', label: 'Verified By', type: 'text', required: true }
      ],
      'official-form': [
        { name: 'form_type', label: 'Form Type', type: 'select', required: true, options: ['Registration Form', 'Ballot Count', 'Incident Report', 'Equipment Log', 'Other'] },
        { name: 'reference_number', label: 'Reference Number', type: 'text', required: true },
        { name: 'date_issued', label: 'Date Issued', type: 'date', required: true },
        { name: 'issuing_authority', label: 'Issuing Authority', type: 'text', required: true },
        { name: 'status', label: 'Status', type: 'select', required: true, options: ['Draft', 'Pending', 'Approved', 'Rejected'] }
      ],
      'station-materials': [
        { name: 'item_type', label: 'Item Type', type: 'select', required: true, options: ['Ballot Box', 'Voting Machine', 'Signage', 'Security Seal', 'Other'] },
        { name: 'condition', label: 'Condition', type: 'select', required: true, options: ['Excellent', 'Good', 'Fair', 'Poor', 'Damaged'] },
        { name: 'serial_number', label: 'Serial Number', type: 'text', required: false },
        { name: 'quantity', label: 'Quantity', type: 'number', required: true },
        { name: 'notes', label: 'Additional Notes', type: 'textarea', required: false }
      ]
    };
    
    return templateFields[documentType.id] || [];
  };

  const validateForm = () => {
    const errors = {};
    let isValid = true;
    
    dynamicFields.forEach(field => {
      if (field.required && (!formData[field.name] || formData[field.name].toString().trim() === '')) {
        errors[field.name] = `${field.label} is required`;
        isValid = false;
      }
      
      if (field.type === 'number' && formData[field.name] && isNaN(Number(formData[field.name]))) {
        errors[field.name] = `${field.label} must be a valid number`;
        isValid = false;
      }
      
      if (field.type === 'date' && formData[field.name] && !isValidDate(formData[field.name])) {
        errors[field.name] = `${field.label} must be a valid date`;
        isValid = false;
      }
    });
    
    setValidationErrors(errors);
    setIsFormValid(isValid);
  };

  const isValidDate = (dateString) => {
    return !isNaN(Date.parse(dateString));
  };

  const handleFieldChange = (fieldName, value) => {
    setFormData(prev => ({
      ...prev,
      [fieldName]: value
    }));
  };

  const addCustomField = () => {
    const fieldName = prompt('Enter field name:');
    const fieldType = prompt('Enter field type (text, number, date, textarea, select):') || 'text';
    
    if (fieldName && fieldTypes[fieldType]) {
      const newField = {
        name: fieldName.toLowerCase().replace(/\s+/g, '_'),
        label: fieldName,
        type: fieldType,
        required: false,
        custom: true
      };
      
      setDynamicFields(prev => [...prev, newField]);
    }
  };

  const removeCustomField = (fieldName) => {
    setDynamicFields(prev => prev.filter(field => field.name !== fieldName));
    setFormData(prev => {
      const { [fieldName]: removed, ...rest } = prev;
      return rest;
    });
  };

  const renderFormField = (field) => {
    const hasError = validationErrors[field.name];
    
    switch (field.type) {
      case 'textarea':
        return (
          <textarea
            value={formData[field.name] || ''}
            onChange={(e) => handleFieldChange(field.name, e.target.value)}
            className={`w-full p-3 border rounded-lg resize-none focus:ring-2 focus:ring-primary focus:border-transparent ${
              hasError ? 'border-error' : 'border-border'
            }`}
            rows={3}
            placeholder={`Enter ${field.label.toLowerCase()}`}
          />
        );
        
      case 'select':
        return (
          <select
            value={formData[field.name] || ''}
            onChange={(e) => handleFieldChange(field.name, e.target.value)}
            className={`w-full p-3 border rounded-lg focus:ring-2 focus:ring-primary focus:border-transparent ${
              hasError ? 'border-error' : 'border-border'
            }`}
          >
            <option value="">Select {field.label.toLowerCase()}</option>
            {field.options?.map(option => (
              <option key={option} value={option}>{option}</option>
            ))}
          </select>
        );
        
      case 'checkbox':
        return (
          <label className="flex items-center space-x-2 cursor-pointer">
            <input
              type="checkbox"
              checked={formData[field.name] || false}
              onChange={(e) => handleFieldChange(field.name, e.target.checked)}
              className="w-4 h-4 text-primary bg-white border-border rounded focus:ring-primary"
            />
            <span className="text-sm text-text-primary">{field.label}</span>
          </label>
        );
        
      default:
        return (
          <Input
            type={field.type}
            value={formData[field.name] || ''}
            onChange={(e) => handleFieldChange(field.name, e.target.value)}
            placeholder={`Enter ${field.label.toLowerCase()}`}
            className={hasError ? 'border-error' : ''}
          />
        );
    }
  };

  const exportFormData = () => {
    const exportData = {
      documentId: document.id,
      documentType: documentType.name,
      timestamp: new Date().toISOString(),
      formData,
      metadata: {
        confidence: document.confidence,
        extractedFields: document.formFields,
        customFields: dynamicFields.filter(field => field.custom)
      }
    };
    
    const dataStr = JSON.stringify(exportData, null, 2);
    const dataUri = 'data:application/json;charset=utf-8,'+ encodeURIComponent(dataStr);
    
    const exportFileDefaultName = `form_data_${document.id}.json`;
    
    const linkElement = document.createElement('a');
    linkElement.setAttribute('href', dataUri);
    linkElement.setAttribute('download', exportFileDefaultName);
    linkElement.click();
  };

  if (!documentType || !document) {
    return (
      <div className="card p-8 text-center">
        <Icon name="FormInput" size={48} className="text-text-tertiary mx-auto mb-4" />
        <h3 className="text-lg font-semibold text-text-primary mb-2">
          Dynamic Form Builder
        </h3>
        <p className="text-text-secondary">
          Select a document type and complete OCR processing to generate the structured form.
        </p>
      </div>
    );
  }

  return (
    <div className="card p-6">
      <div className="flex items-center justify-between mb-6">
        <div>
          <h3 className="text-lg font-semibold text-text-primary">
            Dynamic Form Fields
          </h3>
          <p className="text-sm text-text-secondary">
            Template: {documentType.ocrTemplate} • {dynamicFields.length} fields
          </p>
        </div>
        
        <div className="flex space-x-2">
          <Button
            variant="outline"
            size="sm"
            iconName="Plus"
            onClick={addCustomField}
          >
            Add Field
          </Button>
          
          <Button
            variant="outline"
            size="sm"
            iconName="Download"
            onClick={exportFormData}
            disabled={!isFormValid}
          >
            Export
          </Button>
        </div>
      </div>

      {/* Form validation status */}
      <div className={`p-3 rounded-lg mb-6 ${
        isFormValid 
          ? 'bg-success-50 border border-success-200' :'bg-warning-50 border border-warning-200'
      }`}>
        <div className="flex items-center space-x-2">
          <Icon 
            name={isFormValid ? 'CheckCircle' : 'AlertTriangle'} 
            size={16} 
            className={isFormValid ? 'text-success' : 'text-warning'} 
          />
          <span className={`text-sm font-medium ${
            isFormValid ? 'text-success' : 'text-warning'
          }`}>
            {isFormValid 
              ? 'Form is complete and valid'
              : `${Object.keys(validationErrors).length} field${Object.keys(validationErrors).length > 1 ? 's' : ''} require attention`
            }
          </span>
        </div>
      </div>

      {/* Dynamic form fields */}
      <div className="space-y-6">
        {dynamicFields.map((field) => (
          <div key={field.name} className="space-y-2">
            <div className="flex items-center justify-between">
              <label className="block text-sm font-medium text-text-primary">
                <div className="flex items-center space-x-2">
                  <Icon name={fieldTypes[field.type]?.icon || 'Type'} size={14} />
                  <span>{field.label}</span>
                  {field.required && <span className="text-error">*</span>}
                  {field.custom && (
                    <span className="px-2 py-1 bg-primary-50 text-primary text-xs rounded">
                      Custom
                    </span>
                  )}
                </div>
              </label>
              
              {field.custom && (
                <button
                  onClick={() => removeCustomField(field.name)}
                  className="text-text-secondary hover:text-error transition-colors"
                >
                  <Icon name="Trash2" size={14} />
                </button>
              )}
            </div>
            
            {renderFormField(field)}
            
            {validationErrors[field.name] && (
              <p className="text-sm text-error flex items-center space-x-1">
                <Icon name="AlertTriangle" size={12} />
                <span>{validationErrors[field.name]}</span>
              </p>
            )}
            
            {/* Show extracted value if different from current */}
            {document.formFields?.[field.name] && 
             document.formFields[field.name] !== formData[field.name] && (
              <p className="text-xs text-text-secondary flex items-center space-x-1">
                <Icon name="Eye" size={12} />
                <span>OCR extracted: "{document.formFields[field.name]}"</span>
              </p>
            )}
          </div>
        ))}
      </div>

      {/* Form actions */}
      <div className="flex justify-between items-center mt-8 pt-6 border-t border-border">
        <div className="text-sm text-text-secondary">
          {Object.keys(formData).length} of {dynamicFields.length} fields completed
        </div>
        
        <div className="flex space-x-2">
          <Button
            variant="outline"
            iconName="RotateCcw"
            onClick={() => {
              setFormData({});
              setValidationErrors({});
            }}
          >
            Reset Form
          </Button>
          
          <Button
            variant="primary"
            iconName="Save"
            disabled={!isFormValid}
          >
            Save Form Data
          </Button>
        </div>
      </div>
      
      {/* Field statistics */}
      <div className="mt-4 grid grid-cols-2 md:grid-cols-4 gap-4 text-center">
        <div>
          <p className="text-xs text-text-secondary font-medium uppercase tracking-wide">
            Required Fields
          </p>
          <p className="text-sm font-semibold text-text-primary">
            {dynamicFields.filter(f => f.required).length}
          </p>
        </div>
        
        <div>
          <p className="text-xs text-text-secondary font-medium uppercase tracking-wide">
            Custom Fields
          </p>
          <p className="text-sm font-semibold text-text-primary">
            {dynamicFields.filter(f => f.custom).length}
          </p>
        </div>
        
        <div>
          <p className="text-xs text-text-secondary font-medium uppercase tracking-wide">
            Completion
          </p>
          <p className="text-sm font-semibold text-text-primary">
            {Math.round((Object.keys(formData).length / dynamicFields.length) * 100)}%
          </p>
        </div>
        
        <div>
          <p className="text-xs text-text-secondary font-medium uppercase tracking-wide">
            Auto-filled
          </p>
          <p className="text-sm font-semibold text-text-primary">
            {Object.keys(document.formFields || {}).length}
          </p>
        </div>
      </div>
    </div>
  );
};

export default FormBuilder;