// src/pages/document-upload-ocr-processing/components/SecurityIndicator.jsx
import React, { useState } from 'react';
import Icon from 'components/AppIcon';

const SecurityIndicator = ({ status }) => {
  const [showDetails, setShowDetails] = useState(false);

  const getStatusColor = (statusType, value) => {
    switch (value) {
      case 'active': case'synced': case'secure':
        return 'text-success';
      case 'warning': case'pending':
        return 'text-warning';
      case 'error': case'failed':
        return 'text-error';
      default:
        return 'text-text-secondary';
    }
  };

  const getStatusIcon = (statusType, value) => {
    if (statusType === 'encryption') {
      return value === 'active' ? 'Shield' : 'ShieldOff';
    }
    if (statusType === 'backup') {
      return value === 'synced' ? 'Cloud' : 'CloudOff';
    }
    if (statusType === 'connection') {
      return value === 'secure' ? 'Lock' : 'Unlock';
    }
    return 'AlertTriangle';
  };

  const getOverallStatus = () => {
    const values = Object.values(status || {});
    if (values.includes('error') || values.includes('failed')) {
      return { status: 'error', color: 'text-error', bgColor: 'bg-error-50', borderColor: 'border-error-200' };
    }
    if (values.includes('warning') || values.includes('pending')) {
      return { status: 'warning', color: 'text-warning', bgColor: 'bg-warning-50', borderColor: 'border-warning-200' };
    }
    return { status: 'secure', color: 'text-success', bgColor: 'bg-success-50', borderColor: 'border-success-200' };
  };

  const overall = getOverallStatus();

  return (
    <div className="relative">
      <button
        onClick={() => setShowDetails(!showDetails)}
        className={`flex items-center space-x-2 px-3 py-2 rounded-lg border transition-colors duration-150 ease-out ${
          overall.bgColor
        } ${overall.borderColor} hover:shadow-sm`}
      >
        <Icon 
          name={overall.status === 'secure' ? 'Shield' : overall.status === 'warning' ? 'AlertTriangle' : 'ShieldOff'} 
          size={16} 
          className={overall.color} 
        />
        <span className={`text-sm font-medium ${overall.color}`}>
          {overall.status === 'secure' ? 'Secure' : overall.status === 'warning' ? 'Warning' : 'Error'}
        </span>
        <Icon 
          name={showDetails ? 'ChevronUp' : 'ChevronDown'} 
          size={14} 
          className={overall.color} 
        />
      </button>

      {/* Security Details Dropdown */}
      {showDetails && (
        <div className="absolute top-full right-0 mt-2 w-80 bg-white border border-border rounded-lg shadow-lg z-10">
          <div className="p-4">
            <div className="flex items-center justify-between mb-4">
              <h4 className="font-semibold text-text-primary">
                Security Status
              </h4>
              <button
                onClick={() => setShowDetails(false)}
                className="text-text-secondary hover:text-text-primary"
              >
                <Icon name="X" size={16} />
              </button>
            </div>
            
            <div className="space-y-4">
              {/* Encryption Status */}
              <div className="flex items-center justify-between p-3 bg-surface-secondary rounded-lg">
                <div className="flex items-center space-x-3">
                  <Icon 
                    name={getStatusIcon('encryption', status?.encryption)} 
                    size={20} 
                    className={getStatusColor('encryption', status?.encryption)} 
                  />
                  <div>
                    <p className="font-medium text-text-primary">Encryption</p>
                    <p className="text-xs text-text-secondary">
                      AES-256 military-grade encryption
                    </p>
                  </div>
                </div>
                <div className={`px-2 py-1 rounded-full text-xs font-medium ${
                  status?.encryption === 'active' ? 'bg-success-50 text-success' : 'bg-error-50 text-error'
                }`}>
                  {status?.encryption === 'active' ? 'Active' : 'Inactive'}
                </div>
              </div>
              
              {/* Backup Status */}
              <div className="flex items-center justify-between p-3 bg-surface-secondary rounded-lg">
                <div className="flex items-center space-x-3">
                  <Icon 
                    name={getStatusIcon('backup', status?.backup)} 
                    size={20} 
                    className={getStatusColor('backup', status?.backup)} 
                  />
                  <div>
                    <p className="font-medium text-text-primary">Backup Storage</p>
                    <p className="text-xs text-text-secondary">
                      Secure cloud redundancy
                    </p>
                  </div>
                </div>
                <div className={`px-2 py-1 rounded-full text-xs font-medium ${
                  status?.backup === 'synced' ? 'bg-success-50 text-success' : 
                  status?.backup === 'pending' ? 'bg-warning-50 text-warning' : 'bg-error-50 text-error'
                }`}>
                  {status?.backup === 'synced' ? 'Synced' : 
                   status?.backup === 'pending' ? 'Pending' : 'Failed'}
                </div>
              </div>
              
              {/* Connection Status */}
              <div className="flex items-center justify-between p-3 bg-surface-secondary rounded-lg">
                <div className="flex items-center space-x-3">
                  <Icon 
                    name={getStatusIcon('connection', status?.connection)} 
                    size={20} 
                    className={getStatusColor('connection', status?.connection)} 
                  />
                  <div>
                    <p className="font-medium text-text-primary">Connection</p>
                    <p className="text-xs text-text-secondary">
                      TLS 1.3 secure transmission
                    </p>
                  </div>
                </div>
                <div className={`px-2 py-1 rounded-full text-xs font-medium ${
                  status?.connection === 'secure' ? 'bg-success-50 text-success' : 'bg-error-50 text-error'
                }`}>
                  {status?.connection === 'secure' ? 'Secure' : 'Insecure'}
                </div>
              </div>
            </div>
            
            {/* Security Information */}
            <div className="mt-4 p-3 bg-primary-50 border border-primary-200 rounded-lg">
              <div className="flex items-start space-x-2">
                <Icon name="Info" size={16} className="text-primary mt-0.5" />
                <div>
                  <p className="text-sm font-medium text-primary mb-1">
                    Enhanced Security Measures
                  </p>
                  <ul className="text-xs text-primary-700 space-y-1">
                    <li>• End-to-end encryption for all documents</li>
                    <li>• Automatic secure backup creation</li>
                    <li>• Zero-knowledge architecture</li>
                    <li>• Regular security audits and monitoring</li>
                  </ul>
                </div>
              </div>
            </div>
            
            {/* Last Security Check */}
            <div className="mt-3 text-center text-xs text-text-secondary">
              Last security check: {new Date().toLocaleTimeString()}
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default SecurityIndicator;