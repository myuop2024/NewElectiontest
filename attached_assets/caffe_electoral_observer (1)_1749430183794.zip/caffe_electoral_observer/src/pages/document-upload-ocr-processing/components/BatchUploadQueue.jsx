// src/pages/document-upload-ocr-processing/components/BatchUploadQueue.jsx
import React, { useState, useRef } from 'react';
import Icon from 'components/AppIcon';
import Button from 'components/ui/Button';

const BatchUploadQueue = ({ onBatchUpload, processingQueue }) => {
  const [dragOver, setDragOver] = useState(false);
  const [queuedFiles, setQueuedFiles] = useState([]);
  const [isProcessing, setIsProcessing] = useState(false);
  const [processingProgress, setProcessingProgress] = useState(0);
  const fileInputRef = useRef(null);

  const handleDragOver = (e) => {
    e.preventDefault();
    setDragOver(true);
  };

  const handleDragLeave = (e) => {
    e.preventDefault();
    setDragOver(false);
  };

  const handleDrop = (e) => {
    e.preventDefault();
    setDragOver(false);
    
    const files = Array.from(e.dataTransfer.files).filter(file => 
      file.type.startsWith('image/')
    );
    
    addFilesToQueue(files);
  };

  const handleFileSelect = (e) => {
    const files = Array.from(e.target.files).filter(file => 
      file.type.startsWith('image/')
    );
    
    addFilesToQueue(files);
  };

  const addFilesToQueue = (files) => {
    const newQueueItems = files.map(file => ({
      id: `queue_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`,
      file,
      name: file.name,
      size: file.size,
      type: file.type,
      status: 'queued',
      preview: null,
      documentType: null
    }));
    
    // Generate previews
    newQueueItems.forEach(item => {
      const reader = new FileReader();
      reader.onload = (e) => {
        setQueuedFiles(prev => 
          prev.map(queueItem => 
            queueItem.id === item.id 
              ? { ...queueItem, preview: e.target.result }
              : queueItem
          )
        );
      };
      reader.readAsDataURL(item.file);
    });
    
    setQueuedFiles(prev => [...prev, ...newQueueItems]);
  };

  const removeFromQueue = (itemId) => {
    setQueuedFiles(prev => prev.filter(item => item.id !== itemId));
  };

  const clearQueue = () => {
    setQueuedFiles([]);
  };

  const updateDocumentType = (itemId, documentType) => {
    setQueuedFiles(prev => 
      prev.map(item => 
        item.id === itemId 
          ? { ...item, documentType }
          : item
      )
    );
  };

  const processBatchUpload = async () => {
    if (queuedFiles.length === 0) return;
    
    setIsProcessing(true);
    setProcessingProgress(0);
    
    try {
      const totalFiles = queuedFiles.length;
      
      for (let i = 0; i < queuedFiles.length; i++) {
        const item = queuedFiles[i];
        
        // Update status to processing
        setQueuedFiles(prev => 
          prev.map(queueItem => 
            queueItem.id === item.id 
              ? { ...queueItem, status: 'processing' }
              : queueItem
          )
        );
        
        // Simulate processing time
        await new Promise(resolve => setTimeout(resolve, 800));
        
        // Create photo data object
        const photoData = {
          blob: item.file,
          dataUrl: item.preview,
          timestamp: new Date().toISOString(),
          type: 'batch_upload',
          documentType: item.documentType,
          metadata: {
            fileName: item.name,
            fileSize: item.size,
            batchProcessed: true
          }
        };
        
        // Send to parent for processing
        onBatchUpload?.([photoData]);
        
        // Update status to completed
        setQueuedFiles(prev => 
          prev.map(queueItem => 
            queueItem.id === item.id 
              ? { ...queueItem, status: 'completed' }
              : queueItem
          )
        );
        
        // Update progress
        setProcessingProgress(Math.round(((i + 1) / totalFiles) * 100));
      }
      
      // Clear queue after successful processing
      setTimeout(() => {
        setQueuedFiles([]);
        setIsProcessing(false);
        setProcessingProgress(0);
      }, 1500);
      
    } catch (error) {
      console.error('Batch processing error:', error);
      setIsProcessing(false);
    }
  };

  const formatFileSize = (bytes) => {
    if (bytes === 0) return '0 Bytes';
    const k = 1024;
    const sizes = ['Bytes', 'KB', 'MB', 'GB'];
    const i = Math.floor(Math.log(bytes) / Math.log(k));
    return parseFloat((bytes / Math.pow(k, i)).toFixed(2)) + ' ' + sizes[i];
  };

  const documentTypes = [
    { id: 'incident-report', name: 'Incident Report', color: 'error' },
    { id: 'voter-tally', name: 'Voter Tally', color: 'primary' },
    { id: 'official-form', name: 'Official Form', color: 'secondary' },
    { id: 'station-materials', name: 'Station Materials', color: 'warning' }
  ];

  return (
    <div className="card p-6">
      <div className="flex items-center justify-between mb-6">
        <h3 className="text-lg font-semibold text-text-primary">
          Batch Upload Queue
        </h3>
        
        {queuedFiles.length > 0 && (
          <div className="flex items-center space-x-2">
            <span className="text-sm text-text-secondary">
              {queuedFiles.length} file{queuedFiles.length > 1 ? 's' : ''} queued
            </span>
            <Button
              variant="outline"
              size="sm"
              iconName="Trash2"
              onClick={clearQueue}
              disabled={isProcessing}
            >
              Clear
            </Button>
          </div>
        )}
      </div>

      {/* Drop Zone */}
      <div
        className={`border-2 border-dashed rounded-lg p-8 text-center transition-all duration-200 cursor-pointer mb-6 ${
          dragOver
            ? 'border-primary bg-primary-50' :'border-border hover:border-primary-300 hover:bg-primary-50'
        }`}
        onDragOver={handleDragOver}
        onDragLeave={handleDragLeave}
        onDrop={handleDrop}
        onClick={() => fileInputRef.current?.click()}
      >
        <Icon name="Upload" size={48} className="text-text-tertiary mx-auto mb-4" />
        <h3 className="text-lg font-semibold text-text-primary mb-2">
          Drop Files Here or Click to Browse
        </h3>
        <p className="text-text-secondary mb-4">
          Upload multiple document images for batch processing
        </p>
        <Button variant="outline" iconName="Folder">
          Select Multiple Files
        </Button>
        
        <input
          ref={fileInputRef}
          type="file"
          accept="image/*"
          multiple
          onChange={handleFileSelect}
          className="hidden"
        />
      </div>

      {/* Processing Progress */}
      {isProcessing && (
        <div className="mb-6 p-4 bg-primary-50 border border-primary-200 rounded-lg">
          <div className="flex items-center justify-between mb-2">
            <span className="text-sm font-medium text-primary">
              Processing batch upload...
            </span>
            <span className="text-sm text-primary">
              {processingProgress}%
            </span>
          </div>
          <div className="w-full bg-primary-100 rounded-full h-2">
            <div 
              className="bg-primary h-2 rounded-full transition-all duration-300"
              style={{ width: `${processingProgress}%` }}
            />
          </div>
        </div>
      )}

      {/* Queue Items */}
      {queuedFiles.length > 0 && (
        <div className="space-y-4 mb-6">
          <h4 className="font-medium text-text-primary">
            Queued Files
          </h4>
          
          <div className="space-y-3 max-h-96 overflow-y-auto">
            {queuedFiles.map((item) => (
              <div key={item.id} className="flex items-center space-x-4 p-3 bg-surface-secondary rounded-lg">
                {/* Preview */}
                <div className="w-16 h-16 bg-surface rounded-lg overflow-hidden flex-shrink-0">
                  {item.preview ? (
                    <img
                      src={item.preview}
                      alt={item.name}
                      className="w-full h-full object-cover"
                    />
                  ) : (
                    <div className="w-full h-full flex items-center justify-center">
                      <Icon name="FileImage" size={20} className="text-text-tertiary" />
                    </div>
                  )}
                </div>
                
                {/* File info */}
                <div className="flex-1 min-w-0">
                  <div className="flex items-center justify-between mb-1">
                    <h5 className="font-medium text-text-primary truncate">
                      {item.name}
                    </h5>
                    
                    <div className={`px-2 py-1 rounded-full text-xs font-medium ${
                      item.status === 'completed' ? 'bg-success-50 text-success' :
                      item.status === 'processing'? 'bg-warning-50 text-warning' : 'bg-surface text-text-secondary'
                    }`}>
                      {item.status === 'completed' && <Icon name="Check" size={12} className="inline mr-1" />}
                      {item.status === 'processing' && <Icon name="Loader" size={12} className="inline mr-1 animate-spin" />}
                      {item.status}
                    </div>
                  </div>
                  
                  <div className="flex items-center justify-between">
                    <span className="text-sm text-text-secondary">
                      {formatFileSize(item.size)}
                    </span>
                    
                    {/* Document type selector */}
                    <select
                      value={item.documentType?.id || ''}
                      onChange={(e) => {
                        const selectedType = documentTypes.find(type => type.id === e.target.value);
                        updateDocumentType(item.id, selectedType);
                      }}
                      disabled={isProcessing || item.status === 'completed'}
                      className="text-xs border border-border rounded px-2 py-1 focus:ring-1 focus:ring-primary focus:border-transparent"
                    >
                      <option value="">Select type</option>
                      {documentTypes.map(type => (
                        <option key={type.id} value={type.id}>
                          {type.name}
                        </option>
                      ))}
                    </select>
                  </div>
                </div>
                
                {/* Remove button */}
                <button
                  onClick={() => removeFromQueue(item.id)}
                  disabled={isProcessing}
                  className="w-8 h-8 flex items-center justify-center text-text-secondary hover:text-error hover:bg-error-50 rounded-lg transition-colors"
                >
                  <Icon name="X" size={16} />
                </button>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Action Buttons */}
      {queuedFiles.length > 0 && (
        <div className="flex justify-between items-center">
          <div className="text-sm text-text-secondary">
            {queuedFiles.filter(item => item.documentType).length} of {queuedFiles.length} files have document types assigned
          </div>
          
          <Button
            variant="primary"
            iconName="Play"
            onClick={processBatchUpload}
            disabled={isProcessing || queuedFiles.length === 0 || queuedFiles.some(item => !item.documentType)}
            loading={isProcessing}
          >
            {isProcessing ? 'Processing...' : 'Start Batch Processing'}
          </Button>
        </div>
      )}

      {/* Instructions */}
      {queuedFiles.length === 0 && !isProcessing && (
        <div className="text-center py-8">
          <Icon name="Layers" size={48} className="text-text-tertiary mx-auto mb-4" />
          <h3 className="text-lg font-semibold text-text-primary mb-2">
            No Files in Queue
          </h3>
          <p className="text-text-secondary mb-4">
            Add multiple document images to process them efficiently in batch
          </p>
          
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4 max-w-md mx-auto text-left">
            <div className="flex items-start space-x-2">
              <Icon name="Check" size={16} className="text-success mt-0.5" />
              <span className="text-sm text-text-secondary">
                Faster processing for multiple documents
              </span>
            </div>
            <div className="flex items-start space-x-2">
              <Icon name="Check" size={16} className="text-success mt-0.5" />
              <span className="text-sm text-text-secondary">
                Queue management with preview
              </span>
            </div>
            <div className="flex items-start space-x-2">
              <Icon name="Check" size={16} className="text-success mt-0.5" />
              <span className="text-sm text-text-secondary">
                Document type assignment
              </span>
            </div>
            <div className="flex items-start space-x-2">
              <Icon name="Check" size={16} className="text-success mt-0.5" />
              <span className="text-sm text-text-secondary">
                Progress tracking and status
              </span>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default BatchUploadQueue;