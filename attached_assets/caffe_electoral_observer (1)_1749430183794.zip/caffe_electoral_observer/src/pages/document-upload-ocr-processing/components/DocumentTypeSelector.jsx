// src/pages/document-upload-ocr-processing/components/DocumentTypeSelector.jsx
import React from 'react';
import Icon from 'components/AppIcon';

const DocumentTypeSelector = ({ documentTypes, selectedType, onTypeSelect }) => {
  return (
    <div className="card p-6">
      <h3 className="text-lg font-semibold text-text-primary mb-4">
        Select Document Type
      </h3>
      
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        {documentTypes?.map((type) => (
          <button
            key={type.id}
            onClick={() => onTypeSelect(type)}
            className={`p-4 rounded-lg border-2 transition-all duration-200 text-left ${
              selectedType?.id === type.id
                ? `border-${type.color} bg-${type.color}-50`
                : 'border-border hover:border-primary-200 hover:bg-surface-secondary'
            }`}
          >
            <div className="flex items-start space-x-3">
              <div className={`w-10 h-10 bg-${type.color} text-white rounded-lg flex items-center justify-center flex-shrink-0`}>
                <Icon name={type.icon} size={20} />
              </div>
              
              <div className="flex-1 min-w-0">
                <h4 className="font-medium text-text-primary mb-1">
                  {type.name}
                </h4>
                <p className="text-sm text-text-secondary mb-2">
                  {type.description}
                </p>
                
                {/* Required fields preview */}
                <div className="flex flex-wrap gap-1">
                  {type.requiredFields?.slice(0, 3).map((field) => (
                    <span
                      key={field}
                      className="inline-block px-2 py-1 bg-surface-secondary text-xs text-text-secondary rounded"
                    >
                      {field.replace('_', ' ')}
                    </span>
                  ))}
                  {type.requiredFields?.length > 3 && (
                    <span className="inline-block px-2 py-1 bg-surface-secondary text-xs text-text-secondary rounded">
                      +{type.requiredFields.length - 3} more
                    </span>
                  )}
                </div>
              </div>
              
              {/* Selection indicator */}
              {selectedType?.id === type.id && (
                <div className={`w-6 h-6 bg-${type.color} text-white rounded-full flex items-center justify-center`}>
                  <Icon name="Check" size={14} />
                </div>
              )}
            </div>
          </button>
        ))}
      </div>
      
      {selectedType && (
        <div className="mt-4 p-4 bg-primary-50 border border-primary-200 rounded-lg">
          <div className="flex items-center space-x-2 mb-2">
            <Icon name="Info" size={16} className="text-primary" />
            <span className="font-medium text-primary">OCR Template: {selectedType.ocrTemplate}</span>
          </div>
          <p className="text-sm text-primary-700">
            This document type will use specialized field recognition for optimal text extraction.
          </p>
        </div>
      )}
    </div>
  );
};

export default DocumentTypeSelector;