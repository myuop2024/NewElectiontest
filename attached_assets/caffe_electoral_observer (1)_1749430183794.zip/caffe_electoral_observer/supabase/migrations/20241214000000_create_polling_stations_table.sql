-- Create polling_stations table for storing polling station information
CREATE TABLE IF NOT EXISTS public.polling_stations (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    name TEXT NOT NULL,
    address TEXT NOT NULL,
    parish TEXT NOT NULL,
    expected_voters INTEGER NOT NULL DEFAULT 0,
    status TEXT NOT NULL DEFAULT 'operational', -- 'operational', 'issue-reported', 'non-operational'
    gps_coordinates JSONB,
    additional_info JSONB,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP
);

-- Create indexes for better performance
CREATE INDEX IF NOT EXISTS idx_polling_stations_parish ON public.polling_stations(parish);
CREATE INDEX IF NOT EXISTS idx_polling_stations_status ON public.polling_stations(status);

-- Enable Row Level Security
ALTER TABLE public.polling_stations ENABLE ROW LEVEL SECURITY;

-- Create RLS policies
CREATE POLICY "Anyone can read polling stations"
ON public.polling_stations
FOR SELECT
TO public
USING (true);

CREATE POLICY "Authenticated users can insert polling stations"
ON public.polling_stations
FOR INSERT
TO authenticated
WITH CHECK (true);

CREATE POLICY "Authenticated users can update polling stations"
ON public.polling_stations
FOR UPDATE
TO authenticated
USING (true)
WITH CHECK (true);

CREATE POLICY "Authenticated users can delete polling stations"
ON public.polling_stations
FOR DELETE
TO authenticated
USING (true);

-- Update trigger for 'updated_at' timestamp
CREATE OR REPLACE FUNCTION update_polling_station_timestamp()
RETURNS TRIGGER AS $$
BEGIN
    NEW.updated_at = CURRENT_TIMESTAMP;
    RETURN NEW;
END;
$$ LANGUAGE plpgsql;

CREATE TRIGGER update_polling_stations_timestamp
BEFORE UPDATE ON public.polling_stations
FOR EACH ROW
EXECUTE FUNCTION update_polling_station_timestamp();

-- Insert some initial sample data
INSERT INTO public.polling_stations (id, name, address, parish, expected_voters, status, gps_coordinates)
VALUES 
('d81a60ef-90d4-4251-a43e-f5cf40040434', 'Kingston Primary School', '123 Main St, Kingston', 'Kingston', 1200, 'operational', '{"lat": 18.0179, "lng": -76.8099}'),
('f8c46742-98ee-4799-902a-4c0142b586ea', 'St. Andrew High School', '456 Park Ave, St. Andrew', 'St. Andrew', 1500, 'issue-reported', '{"lat": 18.0270, "lng": -76.7979}'),
('c5b4c7d8-9a8b-4c2d-8e3f-7a6b5c4d3a2b', 'St. Catherine Community Center', '789 Church St, Spanish Town', 'St. Catherine', 900, 'operational', '{"lat": 17.9991, "lng": -76.9674}')
ON CONFLICT (id) DO NOTHING;