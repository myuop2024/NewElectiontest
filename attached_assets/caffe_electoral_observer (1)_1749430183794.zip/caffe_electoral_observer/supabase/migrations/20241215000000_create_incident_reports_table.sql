-- supabase/migrations/20241215000000_create_incident_reports_table.sql

-- Create incident_reports table for storing incident report information
CREATE TABLE IF NOT EXISTS public.incident_reports (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    description TEXT NOT NULL,
    polling_station_id UUID REFERENCES public.polling_stations(id),
    reported_by UUID REFERENCES auth.users(id),
    category TEXT NOT NULL, -- 'voter-intimidation', 'logistics', 'equipment-failure', 'security-issue', 'other' severity TEXT NOT NULL DEFAULT'medium', -- 'low', 'medium', 'high', 'critical' status TEXT NOT NULL DEFAULT'pending', -- 'pending', 'in-progress', 'resolved', 'escalated'
    resolution TEXT,
    attachments JSONB DEFAULT '[]'::jsonb, -- Array of file URLs/paths
    additional_info JSONB DEFAULT '{}'::jsonb,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP
);

-- Create indexes for better performance
CREATE INDEX IF NOT EXISTS idx_incident_reports_polling_station ON public.incident_reports(polling_station_id);
CREATE INDEX IF NOT EXISTS idx_incident_reports_reported_by ON public.incident_reports(reported_by);
CREATE INDEX IF NOT EXISTS idx_incident_reports_category ON public.incident_reports(category);
CREATE INDEX IF NOT EXISTS idx_incident_reports_severity ON public.incident_reports(severity);
CREATE INDEX IF NOT EXISTS idx_incident_reports_status ON public.incident_reports(status);
CREATE INDEX IF NOT EXISTS idx_incident_reports_created_at ON public.incident_reports(created_at DESC);

-- Enable Row Level Security
ALTER TABLE public.incident_reports ENABLE ROW LEVEL SECURITY;

-- Create RLS policies
CREATE POLICY "Authenticated users can view incident reports"
ON public.incident_reports
FOR SELECT
TO authenticated
USING (true);

CREATE POLICY "Authenticated users can insert incident reports"
ON public.incident_reports
FOR INSERT
TO authenticated
WITH CHECK (auth.uid() = reported_by);

CREATE POLICY "Users can update their own incident reports"
ON public.incident_reports
FOR UPDATE
TO authenticated
USING (auth.uid() = reported_by)
WITH CHECK (auth.uid() = reported_by);

CREATE POLICY "Admin users can update all incident reports"
ON public.incident_reports
FOR UPDATE
TO authenticated
USING (
    auth.uid() IN (
        SELECT id FROM public.user_profiles 
        WHERE role IN ('admin', 'coordinator')
    )
)
WITH CHECK (
    auth.uid() IN (
        SELECT id FROM public.user_profiles 
        WHERE role IN ('admin', 'coordinator')
    )
);

CREATE POLICY "Users can delete their own incident reports"
ON public.incident_reports
FOR DELETE
TO authenticated
USING (auth.uid() = reported_by);

CREATE POLICY "Admin users can delete all incident reports"
ON public.incident_reports
FOR DELETE
TO authenticated
USING (
    auth.uid() IN (
        SELECT id FROM public.user_profiles 
        WHERE role IN ('admin', 'coordinator')
    )
);

-- Update trigger for 'updated_at' timestamp
CREATE OR REPLACE FUNCTION update_incident_report_timestamp()
RETURNS TRIGGER AS $$
BEGIN
    NEW.updated_at = CURRENT_TIMESTAMP;
    RETURN NEW;
END;
$$ LANGUAGE plpgsql;

CREATE TRIGGER update_incident_reports_timestamp
BEFORE UPDATE ON public.incident_reports
FOR EACH ROW
EXECUTE FUNCTION update_incident_report_timestamp();

-- Function to get incident reports with related information
CREATE OR REPLACE FUNCTION get_incident_reports_with_details()
RETURNS TABLE (
    id UUID,
    description TEXT,
    polling_station_id UUID,
    polling_station_name TEXT,
    polling_station_parish TEXT,
    reported_by UUID,
    reporter_name TEXT,
    reporter_role TEXT,
    category TEXT,
    severity TEXT,
    status TEXT,
    resolution TEXT,
    attachments JSONB,
    additional_info JSONB,
    created_at TIMESTAMP WITH TIME ZONE,
    updated_at TIMESTAMP WITH TIME ZONE
)
LANGUAGE plpgsql
SECURITY DEFINER
AS $$
BEGIN
    RETURN QUERY
    SELECT 
        ir.id,
        ir.description,
        ir.polling_station_id,
        COALESCE(ps.name, 'Unknown Station') as polling_station_name,
        COALESCE(ps.parish, 'Unknown Parish') as polling_station_parish,
        ir.reported_by,
        COALESCE(up.full_name, au.email) as reporter_name,
        COALESCE(up.role, 'observer') as reporter_role,
        ir.category,
        ir.severity,
        ir.status,
        ir.resolution,
        ir.attachments,
        ir.additional_info,
        ir.created_at,
        ir.updated_at
    FROM public.incident_reports ir
    LEFT JOIN public.polling_stations ps ON ir.polling_station_id = ps.id
    LEFT JOIN auth.users au ON ir.reported_by = au.id
    LEFT JOIN public.user_profiles up ON ir.reported_by = up.id
    ORDER BY ir.created_at DESC;
END;
$$;

-- Grant execute permission to authenticated users
GRANT EXECUTE ON FUNCTION get_incident_reports_with_details() TO authenticated;

-- Insert some initial sample data for testing
INSERT INTO public.incident_reports (
    id, 
    description, 
    polling_station_id, 
    reported_by, 
    category, 
    severity, 
    status, 
    resolution, 
    attachments
)
SELECT 
    gen_random_uuid(),
    'Voter intimidation reported outside polling station',
    ps.id,
    up.id,
    'voter-intimidation',
    'high',
    'in-progress',
    NULL,
    '["https://example.com/incident-photo-1.jpg"]'::jsonb
FROM public.polling_stations ps
CROSS JOIN public.user_profiles up
WHERE ps.name = 'St. Andrew High School'
AND up.role = 'observer'
LIMIT 1
ON CONFLICT DO NOTHING;

INSERT INTO public.incident_reports (
    id, 
    description, 
    polling_station_id, 
    reported_by, 
    category, 
    severity, 
    status, 
    resolution, 
    attachments
)
SELECT 
    gen_random_uuid(),
    'Long queues forming due to slow processing',
    ps.id,
    up.id,
    'logistics',
    'medium',
    'resolved',
    'Additional staff assigned to speed up processing',
    '[]'::jsonb
FROM public.polling_stations ps
CROSS JOIN public.user_profiles up
WHERE ps.name = 'Kingston Primary School'
AND up.role = 'observer'
LIMIT 1
ON CONFLICT DO NOTHING;

INSERT INTO public.incident_reports (
    id, 
    description, 
    polling_station_id, 
    reported_by, 
    category, 
    severity, 
    status, 
    resolution, 
    attachments
)
SELECT 
    gen_random_uuid(),
    'Equipment failure - ballot scanner not working',
    ps.id,
    up.id,
    'equipment-failure',
    'high',
    'escalated',
    NULL,
    '["https://example.com/incident-photo-2.jpg", "https://example.com/incident-photo-3.jpg"]'::jsonb
FROM public.polling_stations ps
CROSS JOIN public.user_profiles up
WHERE ps.name = 'St. Andrew High School'
AND up.role = 'observer'
LIMIT 1
ON CONFLICT DO NOTHING;