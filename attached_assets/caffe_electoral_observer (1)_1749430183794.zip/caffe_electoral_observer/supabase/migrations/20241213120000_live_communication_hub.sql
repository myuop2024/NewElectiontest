-- supabase/migrations/20241213120000_live_communication_hub.sql

-- Create channels table for communication groups/rooms
CREATE TABLE IF NOT EXISTS public.channels (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    name TEXT NOT NULL,
    description TEXT,
    type TEXT NOT NULL DEFAULT 'team', -- 'team', 'parish', 'emergency', 'general'
    parish TEXT,
    is_private BOOLEAN DEFAULT false,
    created_by UUID REFERENCES auth.users(id),
    created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP
);

-- Create channel_members table for managing who has access to which channels
CREATE TABLE IF NOT EXISTS public.channel_members (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    channel_id UUID REFERENCES public.channels(id) ON DELETE CASCADE,
    user_id UUID REFERENCES auth.users(id) ON DELETE CASCADE,
    role TEXT DEFAULT 'member', -- 'admin', 'moderator', 'member'
    joined_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
    last_seen TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
    UNIQUE(channel_id, user_id)
);

-- Create messages table for storing chat messages
CREATE TABLE IF NOT EXISTS public.messages (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    channel_id UUID REFERENCES public.channels(id) ON DELETE CASCADE,
    user_id UUID REFERENCES auth.users(id) ON DELETE CASCADE,
    content TEXT NOT NULL,
    message_type TEXT DEFAULT 'text', -- 'text', 'image', 'file', 'system', 'emergency'
    file_url TEXT,
    file_name TEXT,
    reply_to UUID REFERENCES public.messages(id),
    is_edited BOOLEAN DEFAULT false,
    is_pinned BOOLEAN DEFAULT false,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP
);

-- Create user_profiles table for extended user information
CREATE TABLE IF NOT EXISTS public.user_profiles (
    id UUID PRIMARY KEY REFERENCES auth.users(id) ON DELETE CASCADE,
    username TEXT UNIQUE,
    full_name TEXT,
    avatar_url TEXT,
    role TEXT DEFAULT 'observer', -- 'observer', 'coordinator', 'admin'
    parish TEXT,
    station_assignment TEXT,
    phone TEXT,
    is_online BOOLEAN DEFAULT false,
    last_seen TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP
);

-- Create message_reactions table for emoji reactions
CREATE TABLE IF NOT EXISTS public.message_reactions (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    message_id UUID REFERENCES public.messages(id) ON DELETE CASCADE,
    user_id UUID REFERENCES auth.users(id) ON DELETE CASCADE,
    emoji TEXT NOT NULL,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
    UNIQUE(message_id, user_id, emoji)
);

-- Create indexes for better performance
CREATE INDEX IF NOT EXISTS idx_channels_type ON public.channels(type);
CREATE INDEX IF NOT EXISTS idx_channels_parish ON public.channels(parish);
CREATE INDEX IF NOT EXISTS idx_channel_members_channel_id ON public.channel_members(channel_id);
CREATE INDEX IF NOT EXISTS idx_channel_members_user_id ON public.channel_members(user_id);
CREATE INDEX IF NOT EXISTS idx_messages_channel_id ON public.messages(channel_id);
CREATE INDEX IF NOT EXISTS idx_messages_user_id ON public.messages(user_id);
CREATE INDEX IF NOT EXISTS idx_messages_created_at ON public.messages(created_at DESC);
CREATE INDEX IF NOT EXISTS idx_user_profiles_role ON public.user_profiles(role);
CREATE INDEX IF NOT EXISTS idx_user_profiles_parish ON public.user_profiles(parish);
CREATE INDEX IF NOT EXISTS idx_message_reactions_message_id ON public.message_reactions(message_id);

-- Enable Row Level Security
ALTER TABLE public.channels ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.channel_members ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.messages ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.user_profiles ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.message_reactions ENABLE ROW LEVEL SECURITY;

-- RLS Policies for channels
CREATE POLICY "Users can view channels they are members of"
ON public.channels
FOR SELECT
TO authenticated
USING (
    id IN (
        SELECT channel_id 
        FROM public.channel_members 
        WHERE user_id = auth.uid()
    )
    OR NOT is_private
);

CREATE POLICY "Users can create channels"
ON public.channels
FOR INSERT
TO authenticated
WITH CHECK (auth.uid() = created_by);

CREATE POLICY "Channel creators and admins can update channels"
ON public.channels
FOR UPDATE
TO authenticated
USING (
    auth.uid() = created_by
    OR auth.uid() IN (
        SELECT user_id 
        FROM public.channel_members 
        WHERE channel_id = id AND role IN ('admin', 'moderator')
    )
)
WITH CHECK (
    auth.uid() = created_by
    OR auth.uid() IN (
        SELECT user_id 
        FROM public.channel_members 
        WHERE channel_id = id AND role IN ('admin', 'moderator')
    )
);

-- RLS Policies for channel_members
CREATE POLICY "Users can view channel members for channels they belong to"
ON public.channel_members
FOR SELECT
TO authenticated
USING (
    channel_id IN (
        SELECT channel_id 
        FROM public.channel_members 
        WHERE user_id = auth.uid()
    )
);

CREATE POLICY "Users can join public channels"
ON public.channel_members
FOR INSERT
TO authenticated
WITH CHECK (
    auth.uid() = user_id
    AND (
        channel_id IN (
            SELECT id 
            FROM public.channels 
            WHERE NOT is_private
        )
        OR channel_id IN (
            SELECT channel_id 
            FROM public.channel_members 
            WHERE user_id = auth.uid() AND role IN ('admin', 'moderator')
        )
    )
);

CREATE POLICY "Users can update their own membership info"
ON public.channel_members
FOR UPDATE
TO authenticated
USING (auth.uid() = user_id)
WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Users can leave channels or admins can remove members"
ON public.channel_members
FOR DELETE
TO authenticated
USING (
    auth.uid() = user_id
    OR auth.uid() IN (
        SELECT user_id 
        FROM public.channel_members 
        WHERE channel_id = channel_members.channel_id AND role IN ('admin', 'moderator')
    )
);

-- RLS Policies for messages
CREATE POLICY "Users can view messages in channels they belong to"
ON public.messages
FOR SELECT
TO authenticated
USING (
    channel_id IN (
        SELECT channel_id 
        FROM public.channel_members 
        WHERE user_id = auth.uid()
    )
);

CREATE POLICY "Users can send messages to channels they belong to"
ON public.messages
FOR INSERT
TO authenticated
WITH CHECK (
    auth.uid() = user_id
    AND channel_id IN (
        SELECT channel_id 
        FROM public.channel_members 
        WHERE user_id = auth.uid()
    )
);

CREATE POLICY "Users can update their own messages"
ON public.messages
FOR UPDATE
TO authenticated
USING (auth.uid() = user_id)
WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Users can delete their own messages or moderators can delete any"
ON public.messages
FOR DELETE
TO authenticated
USING (
    auth.uid() = user_id
    OR auth.uid() IN (
        SELECT user_id 
        FROM public.channel_members 
        WHERE channel_id = messages.channel_id AND role IN ('admin', 'moderator')
    )
);

-- RLS Policies for user_profiles
CREATE POLICY "Users can view all profiles"
ON public.user_profiles
FOR SELECT
TO authenticated
USING (true);

CREATE POLICY "Users can insert their own profile"
ON public.user_profiles
FOR INSERT
TO authenticated
WITH CHECK (auth.uid() = id);

CREATE POLICY "Users can update their own profile"
ON public.user_profiles
FOR UPDATE
TO authenticated
USING (auth.uid() = id)
WITH CHECK (auth.uid() = id);

-- RLS Policies for message_reactions
CREATE POLICY "Users can view reactions on messages in their channels"
ON public.message_reactions
FOR SELECT
TO authenticated
USING (
    message_id IN (
        SELECT id 
        FROM public.messages 
        WHERE channel_id IN (
            SELECT channel_id 
            FROM public.channel_members 
            WHERE user_id = auth.uid()
        )
    )
);

CREATE POLICY "Users can add reactions to messages in their channels"
ON public.message_reactions
FOR INSERT
TO authenticated
WITH CHECK (
    auth.uid() = user_id
    AND message_id IN (
        SELECT id 
        FROM public.messages 
        WHERE channel_id IN (
            SELECT channel_id 
            FROM public.channel_members 
            WHERE user_id = auth.uid()
        )
    )
);

CREATE POLICY "Users can remove their own reactions"
ON public.message_reactions
FOR DELETE
TO authenticated
USING (auth.uid() = user_id);

-- Function to handle new user signup
CREATE OR REPLACE FUNCTION public.handle_new_user()
RETURNS trigger
LANGUAGE plpgsql
SECURITY DEFINER
AS $$
BEGIN
    INSERT INTO public.user_profiles (id, username, full_name, role)
    VALUES (
        NEW.id,
        COALESCE(NEW.raw_user_meta_data->>'username', SPLIT_PART(NEW.email, '@', 1)),
        COALESCE(NEW.raw_user_meta_data->>'full_name', NEW.email),
        COALESCE(NEW.raw_user_meta_data->>'role', 'observer')
    );
    RETURN NEW;
END;
$$;

-- Trigger to automatically create user profile on signup
DROP TRIGGER IF EXISTS on_auth_user_created ON auth.users;
CREATE TRIGGER on_auth_user_created
    AFTER INSERT ON auth.users
    FOR EACH ROW
    EXECUTE FUNCTION public.handle_new_user();

-- Insert some default channels
INSERT INTO public.channels (id, name, description, type, is_private) VALUES
('11111111-1111-1111-1111-111111111111', 'General Discussion', 'General communication for all observers', 'general', false),
('22222222-2222-2222-2222-222222222222', 'Emergency Alerts', 'Emergency communications and alerts', 'emergency', false),
('33333333-3333-3333-3333-333333333333', 'Training & Support', 'Training resources and technical support', 'general', false)
ON CONFLICT (id) DO NOTHING;

-- Function to update last_seen timestamp
CREATE OR REPLACE FUNCTION update_user_last_seen()
RETURNS trigger
LANGUAGE plpgsql
AS $$
BEGIN
    UPDATE public.user_profiles
    SET last_seen = CURRENT_TIMESTAMP
    WHERE id = NEW.user_id;
    RETURN NEW;
END;
$$;

-- Trigger to update last_seen when user sends a message
CREATE TRIGGER update_last_seen_on_message
    AFTER INSERT ON public.messages
    FOR EACH ROW
    EXECUTE FUNCTION update_user_last_seen();