-- supabase/migrations/20241213120001_fix_message_user_relationship.sql

-- Update the existing get_messages_with_user_info function to properly handle the relationship
DROP FUNCTION IF EXISTS get_messages_with_user_info(UUID);

CREATE OR REPLACE FUNCTION get_messages_with_user_info(channel_uuid UUID)
RETURNS TABLE (
    id UUID,
    content TEXT,
    message_type TEXT,
    file_url TEXT,
    file_name TEXT,
    reply_to UUID,
    is_edited BOOLEAN,
    is_pinned BOOLEAN,
    created_at TIMESTAMP WITH TIME ZONE,
    updated_at TIMESTAMP WITH TIME ZONE,
    user_id UUID,
    username TEXT,
    full_name TEXT,
    avatar_url TEXT,
    role TEXT,
    parish TEXT,
    station_assignment TEXT
)
LANGUAGE plpgsql
SECURITY DEFINER
AS $$
BEGIN
    RETURN QUERY
    SELECT 
        m.id,
        m.content,
        m.message_type,
        m.file_url,
        m.file_name,
        m.reply_to,
        m.is_edited,
        m.is_pinned,
        m.created_at,
        m.updated_at,
        m.user_id,
        COALESCE(up.username, au.email) as username,
        COALESCE(up.full_name, au.email) as full_name,
        up.avatar_url,
        COALESCE(up.role, 'observer') as role,
        up.parish,
        up.station_assignment
    FROM public.messages m
    LEFT JOIN auth.users au ON m.user_id = au.id
    LEFT JOIN public.user_profiles up ON m.user_id = up.id
    WHERE m.channel_id = channel_uuid
    ORDER BY m.created_at ASC;
END;
$$;

-- Grant execute permission to authenticated users
GRANT EXECUTE ON FUNCTION get_messages_with_user_info(UUID) TO authenticated;

-- Create an additional function to get channel messages with pagination
CREATE OR REPLACE FUNCTION get_channel_messages_paginated(
    channel_uuid UUID,
    page_limit INTEGER DEFAULT 50,
    page_offset INTEGER DEFAULT 0
)
RETURNS TABLE (
    id UUID,
    content TEXT,
    message_type TEXT,
    file_url TEXT,
    file_name TEXT,
    reply_to UUID,
    is_edited BOOLEAN,
    is_pinned BOOLEAN,
    created_at TIMESTAMP WITH TIME ZONE,
    updated_at TIMESTAMP WITH TIME ZONE,
    user_id UUID,
    username TEXT,
    full_name TEXT,
    avatar_url TEXT,
    role TEXT,
    parish TEXT,
    station_assignment TEXT
)
LANGUAGE plpgsql
SECURITY DEFINER
AS $$
BEGIN
    RETURN QUERY
    SELECT 
        m.id,
        m.content,
        m.message_type,
        m.file_url,
        m.file_name,
        m.reply_to,
        m.is_edited,
        m.is_pinned,
        m.created_at,
        m.updated_at,
        m.user_id,
        COALESCE(up.username, au.email) as username,
        COALESCE(up.full_name, au.email) as full_name,
        up.avatar_url,
        COALESCE(up.role, 'observer') as role,
        up.parish,
        up.station_assignment
    FROM public.messages m
    LEFT JOIN auth.users au ON m.user_id = au.id
    LEFT JOIN public.user_profiles up ON m.user_id = up.id
    WHERE m.channel_id = channel_uuid
    ORDER BY m.created_at DESC
    LIMIT page_limit
    OFFSET page_offset;
END;
$$;

-- Grant execute permission to authenticated users
GRANT EXECUTE ON FUNCTION get_channel_messages_paginated(UUID, INTEGER, INTEGER) TO authenticated;